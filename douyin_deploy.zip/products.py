"""Products blueprint."""
from flask import Blueprint, request
from services.fetcher import _request, _fetch_products_from_api, cache, CACHE_KEYS
from config import Config
from utils.responses import success_response

products_bp = Blueprint('products', __name__, url_prefix='/api/v1')


@products_bp.route('/products', methods=['GET'])
def get_products():
    """Get products list (from cache with external fallback).
    
    Query params:
        start_date: Filter products fetched on or after this date (YYYY-MM-DD)
        end_date: Filter products fetched on or before this date (YYYY-MM-DD)
    """
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        # Try cache first
        cached = cache.get(CACHE_KEYS['products'])
        if cached:
            products = cached.get('items', [])
            
            # Apply date filter if provided
            if start_date or end_date:
                products = _filter_products_by_date(products, start_date, end_date)
            
            return success_response({
                'items': products,
                'total': len(products),
                'data_source': 'cache'
            })
        
        # Fallback to external API
        products = _fetch_products_from_api()
        
        # Apply date filter if provided
        if start_date or end_date:
            products = _filter_products_by_date(products, start_date, end_date)
        
        return success_response({
            'items': products,
            'total': len(products),
            'data_source': 'external'
        })
    except Exception as e:
        from flask import current_app
        current_app.logger.error("Failed to fetch products: %s", e)
        return success_response({
            'items': [],
            'total': 0,
            'data_source': 'error'
        }, 'Failed to fetch products', 502)


def _filter_products_by_date(products: list, start_date: str = None, end_date: str = None) -> list:
    """Filter products by fetched_at date range."""
    if not start_date and not end_date:
        return products
    
    from datetime import datetime
    
    filtered = []
    for product in products:
        fetched_at = product.get('fetched_at')
        if not fetched_at:
            continue
        
        try:
            # Parse the fetched_at timestamp (ISO format)
            product_date = datetime.fromisoformat(fetched_at.replace('Z', '+00:00')).date()
            
            if start_date:
                start = datetime.strptime(start_date, '%Y-%m-%d').date()
                if product_date < start:
                    continue
            
            if end_date:
                end = datetime.strptime(end_date, '%Y-%m-%d').date()
                if product_date > end:
                    continue
            
            filtered.append(product)
        except (ValueError, TypeError):
            # Skip products with invalid date format
            continue
    
    return filtered


@products_bp.route('/products/<product_id>', methods=['GET'])
def get_product_detail(product_id):
    """Get single product detail."""
    try:
        # Try cache first
        cached = cache.get(CACHE_KEYS['products'])
        if cached:
            products = cached.get('items', [])
            product = next((p for p in products if str(p.get('product_id') or p.get('id')) == str(product_id)), None)
            if product:
                return success_response(product, 'Product found in cache')
        
        # Fallback to external API - fetch all and find the one
        products = _fetch_products_from_api()
        product = next((p for p in products if str(p.get('product_id') or p.get('id')) == str(product_id)), None)
        if product:
            return success_response(product, 'Product found from external API')
        
        return success_response(None, 'Product not found', 404)
    except Exception as e:
        from flask import current_app
        current_app.logger.error("Failed to fetch product detail: %s", e)
        return success_response(None, 'Failed to fetch product detail', 502)


@products_bp.route('/products/external', methods=['GET'])
def get_products_external():
    """Get products from external FXG API only (no fallback)."""
    try:
        products = _fetch_products_from_api()
        return success_response({
            'items': products,
            'total': len(products),
            'data_source': 'external'
        })
    except Exception as e:
        from flask import current_app
        current_app.logger.error("Failed to fetch products from external API: %s", e)
        return success_response({
            'items': [],
            'total': 0,
            'data_source': 'external_error'
        }, 'Failed to fetch from external API', 502)


@products_bp.route('/products/stats', methods=['GET'])
def product_stats():
    """Fetch product statistics from external FXG API.
    
    Forward to external endpoint: GET /product/tproduct/aggsProductCount
    Parameters:
    - tab: onSale (在售), stock (库存), violation (违规)
    - appid: 应用 ID
    """
    tab = request.args.get('tab', 'onSale')
    appid = request.args.get('appid', 1, type=int)
    
    endpoint = f"{Config.FXG_BASE_URL}/product/tproduct/aggsProductCount"
    params = {
        'tab': tab,
        'appid': appid,
    }
    headers = Config.COMMON_HEADERS.copy()
    cookies = {}
    if Config.FXG_COOKIES:
        for pair in Config.FXG_COOKIES.split(';'):
            if '=' in pair:
                k, v = pair.strip().split('=', 1)
                cookies[k] = v
    
    result = _request(endpoint, params=params, headers=headers, cookies=cookies)
    return success_response(result.get('data', {}), 'Product stats fetched from external service')