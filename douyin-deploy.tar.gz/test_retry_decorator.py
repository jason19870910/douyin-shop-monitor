import os, requests, json, time, random
from functools import wraps

def _http_retry(max_retries=3, base_delay=5.0, max_delay=30.0, timeout=30):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except (requests.ConnectionError, requests.Timeout, requests.RequestException) as e:
                    last_exception = e
                    if attempt < max_retries - 1:
                        delay = min(base_delay * (2 ** attempt) + random.uniform(0, 1), max_delay)
                        print(f"Retry {attempt+1}/{max_retries}: {e}, waiting {delay:.2f}s")
                        time.sleep(delay)
                    else:
                        print(f"Final failure after {max_retries} retries: {e}")
            raise last_exception
        return wrapper
    return decorator

endpoint = "https://fxg.jinritemai.com/api/order/searchlist"
params = {
    "page": 0, "pageSize": 10, "order_by": "create_time", "order": "desc",
    "tab": "all", "appid": 1, "_bid": "ffa_order", "aid": 4272,
    "_lid": "606316310312",
    "__token": os.getenv("TOKEN"),
    "verifyFp": open("/run/secrets/verify_fp").read().strip(),
    "fp": open("/run/secrets/fp").read().strip(),
}

cookie_str = os.getenv('FXG_COOKIES', '')
cookies = {}
for pair in cookie_str.split(';'):
    if '=' in pair:
        k, v = pair.strip().split('=', 1)
        cookies[k] = v

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Referer": "https://fxg.jinritemai.com/ffa/order",
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Sec-Fetch-Dest": "empty", "Sec-Fetch-Mode": "cors", "Sec-Fetch-Site": "same-origin",
    "Sec-Ch-Ua": "Chromium;v=134, Not:A-Brand;v=24, Google Chrome;v=134",
    "Sec-Ch-Ua-Mobile": "?0", "Sec-Ch-Ua-Platform": "Windows"
}

@_http_retry(max_retries=3, base_delay=5.0, max_delay=30.0)
def test_with_retry():
    session = requests.Session()
    session.headers.update(headers)
    resp = session.get(endpoint, params=params, cookies=cookies, timeout=30)
    resp.raise_for_status()
    return resp.json()

print("Testing with retry decorator...")
try:
    result = test_with_retry()
    print(f"Success! Data count: {len(result.get('data', []))}")
except Exception as e:
    print(f"Failed: {e}")