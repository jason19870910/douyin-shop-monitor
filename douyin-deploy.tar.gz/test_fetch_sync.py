import os, json
os.chdir('/app')
import sys
sys.path.insert(0, '/app')

from services.fetcher import _fetch_orders_from_api

print("Calling _fetch_orders_from_api()...")
try:
    orders = _fetch_orders_from_api()
    print(f"Success! Got {len(orders)} orders")
    if orders:
        o = orders[0]
        print(f"First order: shop_order_id={o.get('shop_order_id')}, product={o.get('product_item', [{}])[0].get('product_name')}")
except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()