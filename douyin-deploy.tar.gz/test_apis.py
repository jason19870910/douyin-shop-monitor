import sys
sys.path.insert(0, '/app')

from services.fetcher import (
    _fetch_products_from_api,
    _fetch_orders_from_api,
    _fetch_creators_from_api,
    _fetch_creator_overview_from_api,
    _fetch_creator_works_from_api,
)

apis = [
    ('商品列表', _fetch_products_from_api),
    ('订单列表', _fetch_orders_from_api),
    ('创作者概览', _fetch_creators_from_api),
    ('创作者作品', _fetch_creator_works_from_api),
    ('创作者统计', _fetch_creator_overview_from_api),
]

for name, func in apis:
    try:
        data = func()
        if data:
            cnt = len(data) if isinstance(data, list) else 'dict'
            print(f'OK {name}: {cnt}')
        else:
            print(f'EMPTY {name}')
    except Exception as e:
        print(f'ERR {name}: {e}')
