import sys
sys.path.insert(0, '/opt/douyin-platform/src/backend')

from config import Config
from services.fetcher import _request, _read_secret, parse_cookies

print("=" * 70)
print("Testing 6 External APIs")
print("=" * 70)

# Common headers and cookies
fxg_cookie_str = _read_secret('fxg_cookies', 'FXG_COOKIES')
fxg_cookies = parse_cookies(fxg_cookie_str)
fxg_headers = {
    'User-Agent': Config.USER_AGENT,
    'Referer': 'https://fxg.jinritemai.com/product/tproduct/list',
    'Origin': 'https://fxg.jinritemai.com',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
}

creator_cookie_str = _read_secret('creator_cookies', 'CREATOR_COOKIES')
creator_cookies = parse_cookies(creator_cookie_str)
creator_headers = {
    'User-Agent': Config.USER_AGENT,
    'Referer': 'https://creator.douyin.com/',
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': 'application/json',
}

# Test 1: 商品统计
print("\n1. 商品统计 - GET /product/tproduct/aggsProductCount")
endpoint = f"{Config.FXG_BASE_URL}/product/tproduct/aggsProductCount"
params = {'tab': 'onSale', 'appid': '1'}
result = _request(endpoint, params=params, headers=fxg_headers, cookies=fxg_cookies)
print(f"   Code: {result.get('code')}, Category: {result.get('error_category', 'N/A')}")
if result.get('data'):
    print(f"   Data keys: {list(result['data'].keys())}")

# Test 2: 商品列表
print("\n2. 商品列表 - GET /product/tproduct/list")
endpoint = f"{Config.FXG_BASE_URL}/product/tproduct/list"
params = {
    'page': 1, 'pageSize': 20, 'appid': 1,
    '_bid': 'ffa_product', 'aid': Config.FXG_ORDER_AID, '_lid': Config.FXG_PRODUCT_LID,
}
result = _request(endpoint, params=params, headers=fxg_headers, cookies=fxg_cookies)
print(f"   Code: {result.get('code')}, Category: {result.get('error_category', 'N/A')}")
if isinstance(result.get('data'), list):
    print(f"   Items: {len(result['data'])}")
elif isinstance(result.get('data'), dict):
    print(f"   Data keys: {list(result['data'].keys())}")

# Test 3: 订单统计
print("\n3. 订单统计 - GET /api/order/tabcnt")
endpoint = f"{Config.FXG_BASE_URL}/api/order/tabcnt"
params = {}
result = _request(endpoint, params=params, headers=fxg_headers, cookies=fxg_cookies)
print(f"   Code: {result.get('code')}, Category: {result.get('error_category', 'N/A')}")
if result.get('data'):
    print(f"   Data: {result['data']}")

# Test 4: 订单列表
print("\n4. 订单列表 - GET /api/order/searchlist")
endpoint = f"{Config.FXG_BASE_URL}/api/order/searchlist"
from datetime import datetime, timedelta
now = datetime.now()
start_time = int((now - timedelta(days=30)).timestamp())
end_time = int(now.timestamp())
params = {
    'page': 0, 'pageSize': 20, 'order_by': 'create_time', 'order': 'desc',
    'tab': 'all', 'appid': 1, '_bid': 'ffa_order',
    'aid': Config.FXG_ORDER_AID, '_lid': Config.FXG_ORDER_LID,
    'compact_time[select]': 'create_time_start,create_time_end',
    'create_time_start': start_time, 'create_time_end': end_time,
}
fxg_headers_order = fxg_headers.copy()
fxg_headers_order['Referer'] = 'https://fxg.jinritemai.com/order/order/list'
result = _request(endpoint, params=params, headers=fxg_headers_order, cookies=fxg_cookies)
print(f"   Code: {result.get('code')}, Category: {result.get('error_category', 'N/A')}")

# Test 5: 创作者概览
print("\n5. 创作者概览 - POST /janus/douyin/creator/data/overview/dashboard")
endpoint = f"{Config.CREATOR_BASE_URL}/janus/douyin/creator/data/overview/dashboard"
payload = {"recent_days": 7}
result = _request(endpoint, headers=creator_headers, method='POST', json=payload, cookies=creator_cookies)
print(f"   Code: {result.get('code')}, Category: {result.get('error_category', 'N/A')}")
if result.get('data'):
    print(f"   Data keys: {list(result['data'].keys())}")

# Test 6: 创作者作品
print("\n6. 创作者作品 - GET /janus/douyin/creator/pc/work_list")
endpoint = Config.CREATOR_WORK_LIST_URL
params = {
    'status': '0', 'count': '12', 'max_cursor': '0',
    'scene': 'star_atlas', 'device_platform': 'android', 'aid': Config.CREATOR_WORK_AID,
}
creator_headers_work = creator_headers.copy()
creator_headers_work['Referer'] = 'https://creator.douyin.com/creator-micro/content/manage'
result = _request(endpoint, params=params, headers=creator_headers_work, cookies=creator_cookies, method='GET')
print(f"   Code: {result.get('code')}, Category: {result.get('error_category', 'N/A')}")
if isinstance(result.get('data'), dict):
    aweme_list = result['data'].get('aweme_list') or result['data'].get('items') or []
    print(f"   Works count: {len(aweme_list)}")

print("\n" + "=" * 70)
print("Done")
print("=" * 70)