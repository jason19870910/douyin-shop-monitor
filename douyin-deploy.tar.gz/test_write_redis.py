import sys
sys.path.insert(0, "/app")
from services.fetcher import cache, CACHE_KEYS
cache.set(CACHE_KEYS['creators'], [{'test': 'data'}])
print('Set:', cache.get(CACHE_KEYS['creators']))