from config import Config
c = Config()
print('COMMON_HEADERS:', c.COMMON_HEADERS)