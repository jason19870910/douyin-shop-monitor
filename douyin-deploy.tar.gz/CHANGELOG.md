# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial project setup
- Frontend dashboard with 3 metric cards
- CreatorDataCard component
- Unified page layouts using PageContainer, PageHeader, TableCard
- Backend service documentation (src/backend/README.md)
- Backend changelog (src/backend/CHANGELOG.md)
- Updated project documentation with architecture decisions
- Fixed all broken documentation links
- Cleaned up deprecated and outdated documents

### Changed
- Dashboard layout: reduced metric cards from 6 to 3
- Added spacing and minimum heights to metric cards for readability
- Updated environment variable documentation
- Updated local development instructions

### Fixed
- Fixed 500 API error: FXG_SHOP_ID set to correct numeric value
- Fixed environment variable loading: ensure correct .env file path
- Fixed backend service authentication configuration
- Fixed documentation link references
- Fixed replica scaling rules in docker-compose.yml
- 2026-09-21 Fixed Nginx 502 Bad Gateway: corrected /etc/nginx/conf.d/cci-monitor.conf proxy_set_header, redirecting upstream to 127.0.0.1:3000/5000
- 2026-09-21 Fixed API 401 Unauthorized: unified backend API_KEY with frontend VITE_API_KEY to wlkj_douyin_api_20260921_abc123, removed SKIP_AUTH, configured VITE_API_KEY in frontend/.env and rebuilt vite
- 2026-09-21 Fixed frontend build pipeline, avoiding nested build directories and stale asset updates
- 2026-10-07 Fixed creator works API cookie handling: changed from Cookie header to direct cookie dict parameter (fetcher.py _fetch_creator_works_from_api)
- 2026-10-07 Fixed Nginx 502 Bad Gateway after backend restart: added resolver 127.0.0.11 valid=10s and variable-based proxy_pass to force DNS re-resolution on each request

## [v1.0.0] - 2026-09-05
### Added
- First formal version release