import sys
sys.path.insert(0, '/app')
sys.path.insert(0, 'src/backend')
from redis_cache import get_cache
c = get_cache()
print('products:', len(c.get('products', [])))
print('orders:', len(c.get('orders', [])))
print('creators:', len(c.get('creators', [])))
print('last_update:', c.get('last_update'))
print('sync_status:', c.get('sync_status'))