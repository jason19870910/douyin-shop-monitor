import os
cookie_str = os.getenv('FXG_COOKIES', '')
print('Length:', len(cookie_str))
print('First 100:', cookie_str[:100])
cookies = {}
for pair in cookie_str.split(';'):
    if '=' in pair:
        k, v = pair.strip().split('=', 1)
        cookies[k] = v
print('Parsed count:', len(cookies))
print('Keys:', list(cookies.keys())[:5])