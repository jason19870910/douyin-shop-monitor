import sys
sys.path.insert(0, "/app")
from services.fetcher import _fetch_creator_overview_from_api
print(_fetch_creator_overview_from_api())