import sys
sys.path.insert(0, "/app")
from services.fetcher import _fetch_creators_from_api

creators = _fetch_creators_from_api()
print('Creators raw:', creators)