import sys
sys.path.insert(0, '/opt/douyin-platform/src/backend')

from config import Config
from services.fetcher import _read_secret, parse_cookies
from douyin_sign import sign_request
from datetime import datetime, timedelta

fxg_cookie_str = _read_secret('fxg_cookies', 'FXG_COOKIES')

now = datetime.now()
start_time = int((now - timedelta(days=30)).timestamp())
end_time = int(now.timestamp())

params = {
    'page': 0,
    'pageSize': 10,
    'order_by': 'create_time',
    'order': 'desc',
    'tab': 'all',
    'appid': 1,
    '_bid': 'ffa_order',
    'aid': Config.FXG_ORDER_AID,
    '_lid': Config.FXG_ORDER_LID,
    '__token': _read_secret('token', '__TOKEN'),
    'compact_time[select]': 'create_time_start,create_time_end',
    'create_time_start': start_time,
    'create_time_end': end_time,
}

print("=== Before signature injection ===")
print("Params keys: " + str(list(params.keys())))
print("__token in params: " + params.get('__token')[:20] + "...")

# Check what sign_request would add
existing_tokens = {
    '__token': _read_secret('token', '__TOKEN'),
    'msToken': _read_secret('ms_token', 'MS_TOKEN'),
    'a_bogus': _read_secret('a_bogus', 'A_BOGUS'),
    'verifyFp': _read_secret('verify_fp', 'verifyFp'),
    'fp': _read_secret('fp', 'fp'),
}
print("\nExisting tokens from .env:")
for k, v in existing_tokens.items():
    val = v[:30] if v else 'EMPTY'
    print("  " + k + ": " + val + "...")

sign_params = sign_request(Config.FXG_BASE_URL + '/api/order/searchlist', params, existing_tokens, Config.USER_AGENT)
print("\nSignature params to be added:")
for k, v in sign_params.items():
    val = v[:50] if v else 'EMPTY'
    print("  " + k + ": " + val + "...")

# Final merged params
final_params = {**params, **sign_params}
print("\n=== Final params to send ===")
for k, v in sorted(final_params.items()):
    val = v[:60] if isinstance(v, str) else v
    print("  " + k + "=" + str(val))

# Check for duplicates
dup_keys = set(params.keys()) & set(sign_params.keys())
if dup_keys:
    print("\nDUPLICATE KEYS (will be overwritten by sign_params): " + str(dup_keys))