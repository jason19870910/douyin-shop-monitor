import sys
sys.path.insert(0, '/app')

from services.fetcher import _fetch_orders_from_api, get_fxg_cookies, _read_secret
from config import Config
import requests

# Direct request to order list API to see raw response
endpoint = f'{Config.FXG_BASE_URL}/api/order/searchlist'
token = _read_secret('token', '__TOKEN')
verify_fp = _read_secret('verify_fp', 'verifyFp')
fp = _read_secret('fp', 'fp')

base_params = {
    'page': 0,
    'pageSize': 10,
    'order_by': 'create_time',
    'order': 'desc',
    'tab': 'all',
    'appid': 1,
    '_bid': 'ffa_order',
    'aid': Config.FXG_ORDER_AID,
    '_lid': '606316310312',
}
if token:
    base_params['__token'] = token
if verify_fp:
    base_params['verifyFp'] = verify_fp
if fp:
    base_params['fp'] = fp

cookies = get_fxg_cookies()
headers = {
    **Config.COMMON_HEADERS,
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'zh-CN,zh;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br, zstd',
    'Referer': 'https://fxg.jinritemai.com/ffa/order',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Ch-Ua': '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
    'Sec-Ch-Ua-Mobile': '?0',
    'Sec-Ch-Ua-Platform': '"Windows"',
}

resp = requests.get(endpoint, params=base_params, headers=headers, cookies=cookies, timeout=30)
print(f'Status: {resp.status_code}')
print(f'Headers: {dict(resp.headers)}')
print(f'Content (first 2000 chars): {resp.text[:2000]}')
