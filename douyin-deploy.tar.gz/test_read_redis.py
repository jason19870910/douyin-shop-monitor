import sys
sys.path.insert(0, "/app")
from services.fetcher import cache, CACHE_KEYS
print('Flask read:', cache.get(CACHE_KEYS['creators']))