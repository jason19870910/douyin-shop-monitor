import sys
sys.path.insert(0, "/app")
from config import Config
from services.fetcher import _read_secret, parse_cookies
import requests

cookie_str = _read_secret('creator_cookies', 'CREATOR_COOKIES')
cookies = parse_cookies(cookie_str)
headers = {'User-Agent': Config.USER_AGENT, 'Referer': 'https://creator.douyin.com/', 'Accept': 'application/json, text/plain, */*', 'Content-Type': 'application/json'}
endpoint = f'{Config.CREATOR_BASE_URL}/janus/douyin/creator/data/overview/dashboard'
r = requests.post(endpoint, headers=headers, json={'recent_days': 7}, cookies=cookies, timeout=15)
print('Status:', r.status_code)
data = r.json()
print('Keys:', data.keys())
metrics = data.get('metrics', [])
print('Metrics count:', len(metrics))
for m in metrics:
    en = m.get('english_metric_name')
    val = m.get('metric_value')
    cn = m.get('metric_name')
    print('  {}: {} ({})'.format(en, val, cn))