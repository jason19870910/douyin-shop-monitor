import os, json
from services.fetcher import _request

endpoint = "https://fxg.jinritemai.com/api/order/searchlist"
params = {
    "page": 0,
    "pageSize": 10,
    "order_by": "create_time",
    "order": "desc",
    "tab": "all",
    "appid": 1,
    "_bid": "ffa_order",
    "aid": 4272,
    "_lid": "606316310312",
    "__token": os.getenv("TOKEN"),
    "verifyFp": open("/run/secrets/verify_fp").read().strip(),
    "fp": open("/run/secrets/fp").read().strip(),
}

cookie_str = os.getenv('FXG_COOKIES', '')
cookies = {}
for pair in cookie_str.split(';'):
    if '=' in pair:
        k, v = pair.strip().split('=', 1)
        cookies[k] = v

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Referer": "https://fxg.jinritemai.com/ffa/order",
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-origin",
    "Sec-Ch-Ua": "Chromium;v=134, Not:A-Brand;v=24, Google Chrome;v=134",
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Ch-Ua-Platform": "Windows"
}

print("Testing _request with skip_sign=True...")
result = _request(endpoint, params=params, headers=headers, cookies=cookies, skip_sign=True)
print(f"Result type: {type(result)}")
print(f"Result keys: {list(result.keys()) if isinstance(result, dict) else 'N/A'}")
if isinstance(result, dict) and result.get('error'):
    print(f"ERROR: {result.get('error')}")
else:
    print(f"Success! Data count: {len(result.get('data', [])) if isinstance(result, dict) else 'N/A'}")