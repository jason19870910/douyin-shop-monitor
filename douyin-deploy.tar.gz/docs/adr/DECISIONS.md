---
title: 架构决策记录
version: 1.0.0
status: Published
last_updated: 2026-10-07
owner: Tech Lead
reviewers: [架构师, PM]
approvers: [Tech Lead]
classification: Internal
doc_id: ADR-INDEX
tags: [ADR, 架构决策, 技术选型, 决策记录]
related_docs:
  - '../governance/PROJECT_CHARTER.md'
  - '../architecture/ARCHITECTURE.md'
  - '../api/API_SPEC.md'
changelog: |
  v1.0 (2026-10-07): 合并 001/002/003 三个 ADR 文件为统一决策记录 - Tech Lead
---

# 架构决策记录 (Architecture Decision Records)

> 本文档汇总项目所有重要架构决策，采用轻量级 ADR 格式。每个决策包含背景、决策内容、备选方案对比、后果分析及执行清单。

---

## 目录
1. [ADR-001: 使用 React + Vite 作为前端技术栈](#adr-001-使用-react--vite-作为前端技术栈)
2. [ADR-002: 采用 Celery + Redis 作为异步任务编排方案](#adr-002-采用-celery--redis-作为异步任务编排方案)
3. [ADR-003: 采用 Design Tokens 实现统一深色主题](#adr-003-采用-design-tokens-实现统一深色主题)

---

## ADR-001: 使用 React + Vite 作为前端技术栈

**状态**: Accepted
**日期**: 2026-08-22
**决策者**: Frontend Lead
**评审**: Tech Lead, 架构师
**批准**: Tech Lead
**标签**: ADR, 前端, React, Vite, 技术选型

### 背景
项目需要构建一个现代化的数据监控前端应用，要求：
- 组件化开发，便于维护和复用
- 支持 TypeScript 严格模式
- 快速的开发服务器热更新
- 优秀的生产构建性能
- 团队熟悉度高，学习成本低

### 决策
采用 **React 18 + Vite 5 + TypeScript** 作为前端技术栈。

#### 核心选型理由
| 维度 | 选择 | 理由 |
|------|------|------|
| 框架 | React 18 | 生态成熟、组件化强、团队熟悉、支持并发特性 |
| 构建工具 | Vite 5 | 基于 esbuild，冷启动极快、HMR 毫秒级、Rollup 生产构建 |
| 语言 | TypeScript 5.x | 严格类型检查、IDE 支持好、重构安全 |
| UI 库 | Ant Design 5.x | 企业级组件库、深色主题原生支持、设计规范完善 |
| 状态管理 | React Hooks + Context | 避免额外依赖、轻量、符合 React 哲学 |
| 图表库 | Recharts 2.x | React 原生、声明式 API、组合性好 |
| 样式方案 | CSS Modules + CSS Variables | 作用域隔离、Design Tokens 支持、零运行时 |

### 备选方案
| 方案 | 优点 | 缺点 | 未选择原因 |
|------|------|------|------------|
| Vue 3 + Vite | 响应式系统优秀、单文件组件 | 团队 React 经验更丰富 | 团队技能栈不匹配 |
| Next.js | SSR/SSG 支持、路由内置 | 过重、服务端渲染非必需 | 纯 SPA 场景，无 SEO 需求 |
| Webpack 5 | 生态成熟、插件多 | 启动慢、配置复杂 | Vite 在现代浏览器下完全够用 |
| Zustand/Redux | 状态管理强大 | 增加学习成本、样板代码 | 业务复杂度不高，Context 足够 |

### 后果
#### 正面影响
- 开发体验极佳：Vite 冷启动 < 500ms，HMR < 100ms
- 类型安全：TypeScript 严格模式捕获 90%+ 编译期错误
- 组件复用：Ant Design + 自定义组件库，开发效率提升 40%
- 深色主题：CSS Variables + Design Tokens 实现零侵入式切换

#### 负面影响/风险
- Bundle 体积：Ant Design 全量引入较大，需配置按需加载
- 学习曲线：新成员需熟悉 React Hooks、Context 模式
- 兼容性：需确保目标浏览器支持 ES2020+（已确认）

#### 需要的后续工作
- [x] 配置 Vite + TypeScript + ESLint + Prettier
- [x] 集成 Ant Design 5.x 并配置深色主题
- [x] 建立组件库规范和 Storybook
- [x] 配置 CSS Modules + Design Tokens 体系
- [x] 设置路径别名 (@/src 等)

### 相关链接
- Vite 官方文档: https://vitejs.dev/
- React 18 发布说明: https://react.dev/blog/2022/03/29/react-v18
- Ant Design 5.x 迁移指南: https://ant.design/docs/react/migration-v5

---

## ADR-002: 采用 Celery + Redis 作为异步任务编排方案

**状态**: Accepted
**日期**: 2026-08-12
**决策者**: Backend Lead
**评审**: Tech Lead, 架构师, DevOps Lead
**批准**: Tech Lead
**标签**: ADR, 后端, Celery, Redis, 异步任务, 架构决策

### 背景
项目需要处理以下异步场景：
- 定时任务：每日自动抓取抖店/抖音数据（Celery Beat）
- 长耗时操作：数据同步、报表生成、导出 CSV
- 重试机制：外部 API 调用失败自动重试
- 任务编排：多步骤流水线（抓取 -> 清洗 -> 存储 -> 告警检查）

原方案使用 Flask 内置的简单线程池，存在以下问题：
- 无持久化，重启丢失任务
- 无重试、死信队列
- 无法横向扩展 Worker
- 无监控和可视化

### 决策
采用 **Celery 5.x + Redis 7.x** 作为异步任务队列方案，包含：
- **Celery Beat**: 定时调度器（替代 crontab）
- **Celery Worker**: 4 个专用 Worker 服务
  - `worker_sync`: 数据同步任务（高优先级）
  - `worker_report`: 报表生成任务（低优先级）
  - `worker_alert`: 告警检查任务（高优先级）
  - `worker_default`: 通用任务
- **Redis**: 消息代理 + 结果后端

#### 核心配置
```python
# celery_config.py
CELERY_BROKER_URL = "redis://localhost:6379/0"
CELERY_RESULT_BACKEND = "redis://localhost:6379/1"
CELERY_TASK_SERIALIZER = "json"
CELERY_RESULT_SERIALIZER = "json"
CELERY_ACCEPT_CONTENT = ["json"]
CELERY_TIMEZONE = "Asia/Shanghai"
CELERY_TASK_TRACK_STARTED = True
CELERY_TASK_TIME_LIMIT = 3600
CELERY_WORKER_PREFETCH_MULTIPLIER = 4
CELERY_BEAT_SCHEDULE = {
    "daily-full-sync": {
        "task": "tasks.sync_all_data",
        "schedule": crontab(hour=2, minute=0),
        "options": {"queue": "sync"},
    },
    "hourly-incremental-sync": {
        "task": "tasks.sync_incremental",
        "schedule": crontab(minute=0),
        "options": {"queue": "sync"},
    },
}
```

### 备选方案
| 方案 | 优点 | 缺点 | 未选择原因 |
|------|------|------|------------|
| RQ (Redis Queue) | 简单轻量、Pythonic | 功能较弱、无 Beat、监控差 | 缺乏定时调度和优先级队列 |
| APScheduler | 内嵌调度、无需额外服务 | 单进程、无分布式、无重试 | 生产环境不够健壮 |
| Dramatiq | 性能好、Actor 模型 | 生态较小、无内置 Beat | 团队不熟悉，Celery 更成熟 |
| 自建 Go 任务系统 | 高性能、完全可控 | 开发维护成本极高 | 重复造轮子，ROI 低 |

### 后果
#### 正面影响
- 任务持久化：Redis 存储，重启不丢失
- 自动重试：指数退避策略，配置 `autoretry_for=(Exception,)`
- 优先级队列：4 个队列隔离，关键任务不被阻塞
- 横向扩展：Worker 无状态，可随时增加实例
- 监控可视化：Flower 集成，实时查看任务状态
- 死信处理：失败任务进入 DLQ，支持人工重试

#### 负面影响/风险
- 架构复杂度增加：新增 Redis、Celery 组件
- 运维成本：需监控 Redis 内存、Worker 存活、队列积压
- 结果后端压力：大量任务结果写入 Redis，需配置 TTL 清理
- 单点故障：Redis 单实例（后续可升级集群/哨兵）

#### 需要的后续工作
- [x] 部署 Redis 7.x（配置 maxmemory、eviction policy）
- [x] 编写 4 类 Worker 启动脚本（Systemd 管理）
- [x] 集成 Flower 监控（端口 5555，内网访问）
- [x] 配置任务路由（task_routes 按队列分发）
- [x] 设置结果过期（CELERY_RESULT_EXPIRES=86400）
- [ ] 实现死信队列监控告警
- [ ] 压测验证 1000+ 并发任务处理能力

### 相关链接
- Celery 官方文档: https://docs.celeryq.dev/
- Redis 最佳实践: https://redis.io/docs/management/optimization/
- Flower 监控: https://flower.readthedocs.io/

---

## ADR-003: 采用 Design Tokens 实现统一深色主题

**状态**: Accepted
**日期**: 2026-08-22
**决策者**: Frontend Lead
**评审**: Tech Lead, UI/UX 设计师
**批准**: Tech Lead
**标签**: ADR, 前端, Design Tokens, 深色主题, CSS Variables, 主题系统

### 背景
项目早期仅支持浅色主题，后期需求增加深色模式。直接覆盖 Ant Design 样式存在问题：
- 维护成本高：需覆盖 200+ 组件样式
- 一致性差：颜色值分散在各处，难以统一管理
- 切换闪烁：CSS-in-JS 方案首屏渲染闪烁
- 扩展性弱：新增主题（如高对比度、品牌色）需重写大量代码

### 决策
采用 **Design Tokens + CSS Variables** 方案实现主题系统：

#### 架构设计
```
src/
├── design-tokens/
│   ├── tokens.json          # 单一事实来源
│   ├── themes/
│   │   ├── light.css        # 浅色主题变量
│   │   ├── dark.css         # 深色主题变量
│   │   └── high-contrast.css # 高对比度主题（预留）
│   └── index.ts             # TypeScript 类型导出
├── styles/
│   ├── variables.css        # 全局 CSS Variables 注入
│   └── global.css           # 全局基础样式
└── hooks/
    └── useTheme.ts          # 主题切换 Hook
```

#### tokens.json 结构
```json
{
  "color": {
    "primary": { "value": "{blue.6}", "description": "品牌主色" },
    "background": { "value": "{gray.0}", "description": "页面背景" },
    "surface": { "value": "{white}", "description": "卡片/容器背景" },
    "text": { "value": "{gray.900}", "description": "主文本色" },
    "textSecondary": { "value": "{gray.500}", "description": "次要文本" },
    "border": { "value": "{gray.200}", "description": "边框色" },
    "success": { "value": "{green.6}", "description": "成功状态" },
    "warning": { "value": "{gold.6}", "description": "警告状态" },
    "error": { "value": "{red.6}", "description": "错误状态" }
  },
  "spacing": { "xs": "4px", "sm": "8px", "md": "16px", "lg": "24px", "xl": "32px" },
  "borderRadius": { "sm": "2px", "md": "6px", "lg": "8px" },
  "shadow": { "sm": "0 1px 2px rgba(0,0,0,0.05)", "md": "0 4px 12px rgba(0,0,0,0.1)" },
  "fontSize": { "xs": "12px", "sm": "14px", "md": "16px", "lg": "20px", "xl": "24px" }
}
```

#### 主题切换实现
```typescript
// useTheme.ts
export const useTheme = () => {
  const [theme, setTheme] = useState<'light' | 'dark'>('dark');

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
  }, [theme]);

  return { theme, toggleTheme: () => setTheme(t => t === 'light' ? 'dark' : 'light') };
};
```

```css
/* variables.css - 自动生成 */
:root[data-theme="light"] {
  --color-primary: #1677ff;
  --color-background: #ffffff;
  --color-surface: #fafafa;
  --color-text: #1a1a1a;
  /* ... */
}
:root[data-theme="dark"] {
  --color-primary: #177ddc;
  --color-background: #141414;
  --color-surface: #1f1f1f;
  --color-text: #ffffff;
  /* ... */
}
```

#### Ant Design 5.x 集成
```tsx
// App.tsx
import { ConfigProvider, theme } from 'antd';

const darkAlgorithm = theme.darkAlgorithm;

export default function App() {
  const { theme: currentTheme } = useTheme();
  return (
    <ConfigProvider
      theme={{
        algorithm: currentTheme === 'dark' ? darkAlgorithm : undefined,
        token: {
          colorPrimary: 'var(--color-primary)',
          colorBgContainer: 'var(--color-surface)',
          colorText: 'var(--color-text)',
          borderRadius: 6,
        },
      }}
    >
      <AppContent />
    </ConfigProvider>
  );
}
```

### 备选方案
| 方案 | 优点 | 缺点 | 未选择原因 |
|------|------|------|------------|
| Ant Design ConfigProvider 仅用 token | 简单、原生支持 | 无法覆盖非 AntD 组件、无全局一致性 | 项目有大量自定义组件和图表 |
| CSS-in-JS (styled-components/emotion) | 动态主题强、TS 支持好 | 运行时开销、SSR 复杂、包体积大 | 性能敏感，首屏加载需优化 |
| Less 变量覆盖 | AntD 传统方案 | 仅构建时生效、无运行时切换 | 需支持运行时动态切换 |
| Tailwind CSS dark: | 原子化、暗色类名简单 | 需重写所有样式、学习成本高 | 现有代码基于 CSS Modules |

### 后果
#### 正面影响
- **单一事实来源**：tokens.json 管理所有设计决策，修改一处全局生效
- **零闪烁切换**：CSS Variables 原生支持，首屏无 FOUC
- **全覆盖**：AntD 组件 + 自定义组件 + Recharts 图表 + 原生 HTML 均受控
- **类型安全**：tokens.json 自动生成 TypeScript 类型，IDE 智能提示
- **扩展性**：新增主题只需添加 CSS 文件，无需改业务代码
- **构建时优化**：Style Dictionary 生成 CSS，运行时零开销

#### 负面影响/风险
- 构建链路增加：需集成 Style Dictionary 或自定义脚本生成 CSS
- 设计师协作：需要设计师理解 Tokens 概念，配合输出标准化设计稿
- 旧代码迁移：存量硬编码颜色需逐步替换为变量引用

#### 需要的后续工作
- [x] 建立 tokens.json 规范和校验脚本
- [x] 配置 Style Dictionary 生成 light.css/dark.css
- [x] 实现 useTheme Hook 和 ConfigProvider 集成
- [x] 替换全项目硬编码颜色为 CSS Variables
- [x] 适配 Recharts 图表主题色（通过 CSS Variables 传递）
- [x] E2E 测试验证主题切换无闪烁、无布局抖动
- [ ] 设计师建立 Figma Tokens 同步流程
- [ ] 预留高对比度无障碍主题扩展

### 相关链接
- Design Tokens 规范: https://designtokens.org/
- Style Dictionary: https://amzn.github.io/style-dictionary/
- Ant Design 5.x 主题定制: https://ant.design/docs/react/customize-theme
- W3C Design Tokens Community Group: https://www.w3.org/community/design-tokens/

---

## 附录：ADR 模板参考

新增架构决策时，请使用以下模板：

```markdown
# ADR-[NNN]: [标题]

**状态**: Proposed / Accepted / Superseded / Deprecated
**日期**: YYYY-MM-DD
**决策者**: @techlead, @dev1, @devops
**咨询对象**: @pm, @security

## 背景
[问题陈述、约束、假设]

## 决策
[决定内容及理由]

## 备选方案
| 选项 | 优点 | 缺点 | 未选择原因 |
|------|------|------|------------|
| A    | ...  | ...  | ...        |
| B    | ...  | ...  | ...        |

## 后果
### 正面
- ...
### 负面
- ...
### 风险
- ...

## 实现备注
[PR 链接、Ticket、配置变更]

## 关联 ADR
- ADR-[NNN]: [标题]
```