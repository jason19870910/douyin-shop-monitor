# API 规范文档

> Douyin 监控平台统一 API 规范，包含内部后端 RESTful 接口与外部抖音电商后台接口。
> **版本**: 2.2.0
> **最后更新**: 2026-10-08
> **维护**: 项目核心团队

---

## 目录

1. [公共返回结构](#公共返回结构)
2. [内部 API 概览](#内部-api-概览)
3. [内部 API 详细](#内部-api-详细)
4. [外部 API 概览](#外部-api-概览)
5. [外部 API 详细](#外部-api-详细)
6. [认证与请求头](#认证与请求头)
7. [错误码](#错误码)

---

## 公共返回结构

### 内部 API 成功

```json
{ "success": true, "data": {}, "message": "可选" }
```

### 内部 API 错误

```json
{ "success": false, "error": "错误描述", "code": 400 }
```

### 外部 API 成功

```json
{ "code": 0, "message": "success", "data": {} }
```

### 外部 API 错误

```json
{ "code": 40001, "message": "错误描述", "data": null }
```

---

## 内部 API 概览

Base URL: `http://localhost:5000/api/v1` 开发 / 生产域名 `/api/v1`

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/v1/health` | 健康检查 |
| GET | `/api/v1/dashboard/stats` | 仪表盘聚合统计 |
| GET | `/api/v1/products` | 商品列表缓存 |
| GET | `/api/v1/products/stats` | 商品统计转发 |
| GET | `/api/v1/products/external` | 外部商品列表透传 |
| GET | `/api/v1/products/:id` | 商品详情 |
| GET | `/api/v1/orders` | 订单列表 |
| GET | `/api/v1/orders/stats` | 订单统计转发 |
| GET | `/api/v1/creators` | 创作者列表 |
| GET | `/api/v1/creators/works` | 创作者作品缓存 |
| GET | `/api/v1/creators/works/external` | 外部创作者作品透传 |
| GET | `/api/v1/creators/overview` | **创作者概览转发**（已统一为 GET） |
| GET | `/api/v1/compliance` | 合规列表 |
| GET | `/api/v1/compliance/stats` | 合规统计 |
| GET | `/api/v1/compliance/rules` | 合规规则列表 |
| POST | `/api/v1/compliance/rules` | 创建合规规则 |
| PUT | `/api/v1/compliance/rules/:id` | 更新合规规则 |
| DELETE | `/api/v1/compliance/rules/:id` | 删除合规规则 |
| POST | `/api/v1/compliance/check` | 触发合规检测 |
| GET | `/api/v1/compliance/export` | 导出合规报告 |
| GET | `/api/v1/alerts/config` | 获取通用告警配置 |
| POST | `/api/v1/alerts/config` | 更新通用告警配置 |
| GET | `/api/v1/alerts/history` | 获取告警历史（支持分页、类型过滤） |
| DELETE | `/api/v1/alerts/history` | 清空告警历史 |
| GET | `/api/v1/alerts/history/stats` | 获取告警统计汇总 |
| GET | `/api/v1/alerts/dian/config` | 获取抖店告警配置 |
| POST | `/api/v1/alerts/dian/config` | 更新抖店告警配置 |
| GET | `/api/v1/alerts/douyin/config` | 获取抖音告警配置 |
| POST | `/api/v1/alerts/douyin/config` | 更新抖音告警配置 |
| POST | `/api/v1/sync` | 手动触发同步（支持 `?async=true` 异步模式） |
| GET | `/api/v1/sync/history` | 同步历史 |
| GET | `/api/v1/mock/status` | Mock 状态 |
| GET | `/api/v1/videos` | 视频列表 |
| GET | `/api/v1/videos/:id` | 视频详情 |
| POST | `/api/v1/videos` | 创建视频 |
| PUT | `/api/v1/videos/:id` | 更新视频 |
| DELETE | `/api/v1/videos/:id` | 删除视频 |
| GET | `/api/v1/auth/qr-code` | 获取二维码 |
| GET | `/api/v1/auth/login` | 登录 |
| POST | `/api/v1/auth/logout` | 登出 |
| GET | `/api/v1/auth/status` | 授权状态 |
| GET | `/api/v1/accounts` | 账号列表 |
| GET | `/api/v1/accounts/:id` | 账号详情 |
| POST | `/api/v1/accounts` | 创建账号 |
| PUT | `/api/v1/accounts/:id` | 更新账号 |
| DELETE | `/api/v1/accounts/:id` | 删除账号 |
| GET | `/api/v1/media/video-edit` | 视频编辑列表 |
| GET | `/api/v1/media/image-edit` | 图片编辑列表 |

---

## 首页数据需求

| 区块 | 使用的 API | 说明 |
|------|------------|------|
| 整体概览（今日销售额、今日订单数、今日收入、转化率） | `GET /api/v1/dashboard/stats` | 提供 total_sales_today/yesterday, total_revenue_today/yesterday, total_orders_today/yesterday, avg_conversion_rate, sales_trend, top_products |
| 商品统计（在售/库存/违规） | `GET /api/v1/products/stats?tab=...` | 根据 tab 返回对应统计指标（销量、库存、违规数等） |
| 订单统计（全部/支付/取消） | `GET /api/v1/orders/stats` | 返回 all/pay/cancel 的 count 和 amount |
| 创作者中心概览 | `GET /api/v1/creators/overview?recent_days=7` | 返回 total_followers, total_videos, recent_view, recent_like |
| 系统健康 | `GET /api/v1/health` | 返回 status、last_update、timestamp；数据来源从 dashboard/stats 的 data_source 字段获取 |
| 立即同步触发 | `POST /api/v1/sync` | 手动触发同步（支持 `?async=true` 异步模式），成功后刷新健康状态 |
| 合规告警（可选） | `GET /api/v1/compliance/stats` + `GET /api/v1/compliance?status=pending&size=5` | 未处理高危违规数量与最近 5 条记录 |
| 告警配置开关 | `GET /api/v1/alerts/config`、`GET /api/v1/alerts/dian/config`、`GET /api/v1/alerts/douyin/config` | 是否启用各类预警 |
| Mock / 降级开关 | `GET /api/v1/mock/status` | 前端根据此决定是否展示占位数据 |
## 内部 API 详细

### 健康检查

`GET /api/v1/health`

**无需认证**（在 `PUBLIC_ENDPOINTS` 白名单中）。

```json
{ "status": "healthy", "timestamp": "...", "last_update": "..." }
```

- `status`: 固定为 `healthy`
- `timestamp`: 当前服务器时间（ISO 8601）
- `last_update`: 最近一次定时同步完成时间（来自 Redis `last_update` 键）

### 仪表盘统计

`GET /api/v1/dashboard/stats`

返回：`total_sales_today/yesterday`、`total_revenue_today/yesterday`、`total_orders_today/yesterday`、`avg_conversion_rate`、`sales_trend`、`top_products`。

### 商品列表

`GET /api/v1/products?page=1&size=20&keyword=`

分页返回商品缓存数据。

### 商品统计

`GET /api/v1/products/stats?tab=onSale&appid=1`

转发至外部 `fxg.jinritemai.com/product/tproduct/aggsProductCount`，自动注入 Cookie 与签名。

**参数**：
- `tab`: `onSale` (在售) / `stock` (库存) / `violation` (违规)
- `appid`: 应用 ID

**返回字段**（外部透传）：
- `total_count`: 总数
- `on_sale_count`: 在售数
- `stock_count`: 库存预警数
- `violation_count`: 违规数

### 外部商品列表

`GET /api/v1/products/external`

透传所有查询参数至外部 `/product/tproduct/list`。

**外部 API 实际参数**（从 `/product/tproduct/list` 映射而来）：

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `page` | int | `0` | 0-based 页码索引 |
| `pageSize` | int | `20` | 每页数量，建议 10-20 |

**参数说明**：
- `page`: 从 0 开始，`page=0` 为第一页
- `pageSize`: 每页返回的产品数，当前默认 20（实际 API 返回可能因数据量而异，测试中 `pageSize=10` 返回 9 条，`pageSize=1` 返回 1 条）

**返回字段**（`data.list`）：
- `product_id` / `product_name` / `name`
- `sales_today` / `sales_yesterday`
- `conversion_rate` / `conversion_rate_yesterday`
- `inventory` / `status`
- `market_price` / `discount_price` / `price`
- `img` / `product_url`
- `shop_id`

> **已修复问题**：原代码使用 `pageSize=1` 导致每次仅获取 1 个产品，现已改为 `pageSize=20` 以获取完整列表。页码使用 0-based 索引，`page=0` 为第一页。

### 订单统计

`GET /api/v1/orders/stats`

转发至外部 `fxg.jinritemai.com/api/order/tabcnt`。

**返回字段**（外部透传）：
```json
{
  "all": { "count": 100, "amount": 50000 },
  "pay": { "count": 80, "amount": 45000 },
  "cancel": { "count": 20, "amount": 5000 }
}
```

### 创作者概览

`GET /api/v1/creators/overview?recent_days=7`

**内部已统一为 GET**（外部为 `POST /janus/douyin/creator/data/overview/dashboard`）。

转发至外部创作者中心，自动注入 Cookie 与签名。

**⚠️ 重要发现（2026-10-08 验证）**：外部 API 实际返回格式为 `metrics` 数组，而非旧文档中的 `data` 对象。内部 `_fetch_creator_overview_from_api()` 已修复解析逻辑，兼容两种格式。

**外部 API 实际返回格式**：
```json
{
  "status_code": 0,
  "metrics": [
    {"english_metric_name": "total_fans_cnt", "metric_value": 1166, "metric_name": "粉丝"},
    {"english_metric_name": "publish_cnt", "metric_value": 0, "metric_name": "投稿量"},
    {"english_metric_name": "play_cnt", "metric_value": 47, "metric_name": "播放量"},
    {"english_metric_name": "digg_cnt", "metric_value": 2, "metric_name": "作品点赞"},
    {"english_metric_name": "share_count", "metric_value": 0, "metric_name": "作品分享"},
    {"english_metric_name": "comment_cnt", "metric_value": 0, "metric_name": "作品评论"},
    {"english_metric_name": "net_fans_cnt", "metric_value": -3, "metric_name": "净增粉丝"},
    {"english_metric_name": "cancel_fans_cnt", "metric_value": 3, "metric_name": "取关粉丝"},
    {"english_metric_name": "homepage_view_cnt", "metric_value": 10, "metric_name": "主页访问"},
    {"english_metric_name": "avg_view_second", "metric_value": 3.23, "metric_name": "平均播放时长"},
    {"english_metric_name": "completion_rate_5s", "metric_value": 0.1, "metric_name": "5秒完播率"},
    {"english_metric_name": "bounce_rate_2s", "metric_value": 0.67, "metric_name": "2秒跳出率"}
  ]
}
```

**字段映射表（内部实现 `_fetch_creator_overview_from_api` / `_fetch_creators_from_api`）**：
| 内部返回字段 | 外部 metrics 英文名 | 中文含义 | 备注 |
|-------------|-------------------|----------|------|
| `total_followers` | `total_fans_cnt` | 总粉丝数 | 兼容旧 `follow_cnt` |
| `total_videos` | `publish_cnt` | 总视频数/投稿量 | 兼容旧 `aweme_cnt` |
| `total_views` | `play_cnt` | 总播放量 | 新增字段 |
| `total_likes` | `digg_cnt` | 总点赞数 | 兼容旧 `like_cnt` |
| `total_comments` | `comment_cnt` | 总评论数 | 新增字段 |
| `total_shares` | `share_count` | 总分享数 | 兼容旧 `share_cnt` |
| `recent_followers_gain` | `net_fans_cnt` | 近期净增粉 | 兼容旧 `net_followers_gain` |
| `recent_view` | `play_cnt` | 近期播放量 | 兼容旧字段名 |
| `recent_like` | `digg_cnt` | 近期点赞数 | 兼容旧字段名 |

**内部返回示例**：
```json
{
  "success": true,
  "data": {
    "recent_days": 7,
    "total_followers": 1166,
    "total_videos": 0,
    "total_views": 47,
    "total_likes": 2,
    "total_comments": 0,
    "total_shares": 0,
    "recent_view": 47,
    "recent_like": 2,
    "recent_followers_gain": -3,
    "data_source": "external"
  }
}
```

### 创作者作品外部列表

`GET /api/v1/creators/works/external`

透传至外部 `/janus/douyin/creator/pc/work_list`，前端做字段归一化映射。

**归一化映射**：
| 前端字段 | 外部字段回退 |
|---------|-------------|
| `title` | `title` → `name` |
| `creator_name` | `creator_name` → `author_name` → `nickname` → `user_nickname` |
| `cover_url` | `cover_url` → `cover` → `cover_img` |
| `play_count` | `play_count` → `play` |
| `like_count` | `like_count` → `favorite_count` |
| `comment_count` | `comment_count` → `comment` |
| `share_count` | `share_count` → `share` |

---

### 手动触发同步

`POST /api/v1/sync`

**查询参数**：
- `async` (可选): `true` / `false` - 是否异步执行（默认 `false`）

**同步模式返回**：
```json
{
  "status": "completed",
  "mode": "sync",
  "last_update": "2026-09-23T10:00:00",
  "results": {
    "products": "success",
    "orders": "success",
    "creators": "success",
    "creator_works": "success",
    "compliance": "success",
    "alerts": "success"
  }
}
```

**异步模式返回**：
```json
{
  "status": "started",
  "mode": "async",
  "task_id": "celery-task-id",
  "message": "Full sync task queued"
}
```

---

## 外部 API 概览

域名: `fxg.jinritemai.com`, `creator.douyin.com`

| 接口 | 方法 | 路径 | 说明 |
|------|------|------|------|
| 商品统计 | GET | `/product/tproduct/aggsProductCount` | 商品聚合计数 |
| 商品列表 | GET | `/product/tproduct/list` | 商品分页列表 |
| 订单统计 | GET | `/api/order/tabcnt` | 订单状态汇总 |
| 订单列表 | GET | `/api/order/searchlist` | 订单明细 |
| 创作者概览 | POST | `/janus/douyin/creator/data/overview/dashboard` | 创作者仪表盘 |
| 创作者作品 | GET/POST | `/janus/douyin/creator/pc/work_list` | 作品列表 |

---

## 外部 API 详细

### 商品统计 `/product/tproduct/aggsProductCount`

**方法**：GET

**完整 URL**：`https://fxg.jinritemai.com/product/tproduct/aggsProductCount`

**Query 参数**：
| 参数 | 类型 | 必填 | 示例值 | 说明 |
|------|------|------|--------|------|
| `tab` | string | 是 | `onSale` | 筛选标签：`onSale`(在售)/`draft`(草稿)/`audit`(审核中)/`violation`(违规) |
| `appid` | int | 是 | `1` | 应用 ID |

**签名参数**（自动注入，需有效）：
- `__token` (TOKEN)
- `msToken` (MS_TOKEN)
- `a_bogus` (实时计算)
- `verifyFp` (VERIFY_FP)
- `fp` (FP)

**固定参数**：
- `_bid=ffa_product`
- `aid=FXG_SHOP_ID` (4272)

**请求头**：
```
User-Agent: Config.USER_AGENT
Referer: https://fxg.jinritemai.com/product/tproduct/list
Origin: https://fxg.jinritemai.com
Cookie: FXG_COOKIES
Accept: application/json, text/plain, */*
Accept-Language: zh-CN,zh;q=0.9,en;q=0.8
Accept-Encoding: gzip, deflate, br, zstd
Connection: keep-alive
X-Requested-With: XMLHttpRequest
Sec-Fetch-Site: same-origin
Sec-Fetch-Mode: cors
Sec-Fetch-Dest: empty
Cache-Control: no-cache
Pragma: no-cache
Priority: u=1, i
Sec-Ch-Ua: "Google Chrome";v="153", "Not_A Brand";v="8", "Chromium";v="153"
Sec-Ch-Ua-Mobile: ?0
Sec-Ch-Ua-Platform: "Windows"
```

**返回示例**：
```json
{
  "code": 0,
  "data": {
    "audit": 0,
    "draft": 0,
    "forbidden": 0,
    "onsale": 6,
    "sell_out_new": 0,
    "unpass": 0,
    "unpass_new": 0
  }
}
```

**字段详细说明**：
| 字段 | 类型 | 说明 | 示例值 |
|------|------|------|--------|
| `code` | int | 成功标识，0 表示成功 | 0 |
| `data.audit` | int | 审核中商品数 | 0 |
| `data.draft` | int | 草稿箱商品数 | 0 |
| `data.forbidden` | int | 违规/禁售商品数 | 0 |
| `data.onsale` | int | **在售商品数（核心指标）** | 6 |
| `data.sell_out_new` | int | 售罄商品数 | 0 |
| `data.unpass` | int | 审核不通过数 | 0 |
| `data.unpass_new` | int | 新版审核不通过数 | 0 |

---

### 商品列表 `/product/tproduct/list`

**方法**：GET

**完整 URL**：`https://fxg.jinritemai.com/product/tproduct/list`

**Query 参数**：
| 参数 | 类型 | 必填 | 示例值 | 说明 |
|------|------|------|--------|------|
| `page` | int | 是 | `1` | 页码 |
| `pageSize` | int | 是 | `20` | 每页数量 |
| `tab` | string | 是 | `onSale` | 筛选标签 |
| `appid` | int | 是 | `1` | 应用 ID |

**签名参数**（自动注入，需有效）：
- `__token` (TOKEN)
- `msToken` (MS_TOKEN)
- `a_bogus` (实时计算)
- `verifyFp` (VERIFY_FP)
- `fp` (FP)

**固定参数**：
- `_bid=ffa_product`
- `aid=FXG_ORDER_AID` (4272)
- `_lid=FXG_PRODUCT_LID` (829906029528)

**请求头**：同上（商品统计）

**返回示例**：
```json
{
  "code": 0,
  "data": []
}
```

**⚠️ 实际结构差异（2026-10-08 验证）**：
- 响应顶层 `data` 直接是**数组**，而非旧文档的对象 `{ list: [], total: 0 }`
- 当前无商品数据，返回空数组 `[]`

**预期商品对象字段（基于接口规范）**：
| 字段 | 类型 | 说明 |
|------|------|------|
| `product_id` | string | 商品 ID |
| `name` / `product_name` | string | 商品名称 |
| `sales_today` | int | 今日销量 |
| `market_price` | float | 市场价（元） |
| `discount_price` | float | 折扣价/售价（元） |
| `img` | string | 主图 URL |
| `product_url` | string | 商品详情页 URL |
| `shop_id` | string | 店铺 ID |
| `status` | int | 商品状态 |
| `create_time` | int | 创建时间戳 |

**分页信息**：当前响应无 `page`、`size`、`total` 字段，需通过 `pageSize` 和返回数组长度推断

---

### 订单统计 `/api/order/tabcnt`

**方法**：GET

**完整 URL**：`https://fxg.jinritemai.com/api/order/tabcnt`

**Query 参数**：
| 参数 | 类型 | 必填 | 示例值 | 说明 |
|------|------|------|--------|------|
| `tabcnt_version` | string | 是 | `v1` | 版本参数 |
| `tab` | string | 是 | `all` | 标签：`all`/`pay`/`cancel` 等 |
| `appid` | int | 是 | `1` | 应用 ID |

**签名参数**（自动注入，需有效）：
- `__token` (TOKEN)
- `msToken` (MS_TOKEN)
- `a_bogus` (实时计算)
- `verifyFp` (VERIFY_FP)
- `fp` (FP)

**固定参数**：
- `_bid=ffa_order`
- `aid=FXG_ORDER_AID` (4272)
- `_lid=FXG_ORDER_LID` (550078945638)

**请求头**：
```
User-Agent: Config.USER_AGENT
Referer: https://fxg.jinritemai.com/ffa/morder/order/list
Origin: https://fxg.jinritemai.com
Cookie: FXG_COOKIES
Accept: application/json, text/plain, */*
Accept-Language: zh-CN,zh;q=0.9
Accept-Encoding: gzip, deflate, br, zstd
Connection: keep-alive
X-Requested-With: XMLHttpRequest
Sec-Fetch-Site: same-origin
Sec-Fetch-Mode: cors
Sec-Fetch-Dest: empty
Cache-Control: no-cache
Pragma: no-cache
Priority: u=1, i
Sec-Ch-Ua: "Google Chrome";v="153", "Not_A Brand";v="8", "Chromium";v="153"
Sec-Ch-Ua-Mobile: ?0
Sec-Ch-Ua-Platform: "Windows"
```

**返回示例**：
```json
{
  "code": 0,
  "data": {
    "all": 1,
    "closed": 1,
    "unpaid": 0,
    "on_delivery": 0,
    "received": 0,
    "handling": 0,
    "stock_up": 0,
    "exp_ship": 0,
    "ship_delay": 0,
    "in_aftersale": 0,
    "have_aftersale": 0,
    "cnt_report": {
      "warning": "0",
      "ship_exception": "0"
    },
    "sub_tab_count_map": {
      "all": {"count": "1", "text": "全部"},
      "exp_ship": {"count": "0", "text": "待发货"},
      "ship_delay": {"count": "0", "text": "发货延迟"},
      "handling": {"count": "0", "text": "处理中"},
      "stock_up": {"count": "0", "text": "备货中"},
      "on_delivery": {"count": "0", "text": "配送中"},
      "received": {"count": "0", "text": "已收货"},
      "unpaid": {"count": "0", "text": "待付款"},
      "closed": {"count": "1", "text": "已完成"},
      "cancel": {"count": "0", "text": "已取消"},
      "refund": {"count": "0", "text": "退款中"},
      "aftersale": {"count": "0", "text": "售后中"}
    }
  }
}
```

**字段详细说明**：
| 字段 | 类型 | 说明 | 示例值 |
|------|------|------|--------|
| `code` | int | 成功标识 | 0 |
| `data.all` | int | **全部订单总数（核心指标）** | 1 |
| `data.closed` | int | 已完成/关闭订单数 | 1 |
| `data.unpaid` | int | 待付款订单数 | 0 |
| `data.on_delivery` | int | 配送中订单数 | 0 |
| `data.received` | int | 已收货订单数 | 0 |
| `data.handling` | int | 处理中订单数 | 0 |
| `data.stock_up` | int | 备货中订单数 | 0 |
| `data.exp_ship` | int | 待发货订单数 | 0 |
| `data.ship_delay` | int | 发货延迟订单数 | 0 |
| `data.in_aftersale` | int | 售后中订单数 | 0 |
| `data.have_aftersale` | int | 有售后记录的订单数 | 0 |
| `data.cnt_report.warning` | string | 预警单数 | "0" |
| `data.cnt_report.ship_exception` | string | 物流异常单数 | "0" |
| `data.sub_tab_count_map` | object | 子标签详细计数映射（含 count 文本） | 见上方示例 |

---

### 订单列表 `/api/order/searchlist` ⚠️ **关键修复**

**方法**：GET

**完整 URL**：`https://fxg.jinritemai.com/api/order/searchlist`

**⚠️ 重要发现**：该端点**不需要** `a_bogus`、`msToken` 签名参数！仅需 Cookie 认证即可。
- **带过期签名请求** → 返回 `10001010A` (SIGNATURE_ERROR)
- **去掉 a_bogus/msToken** → 返回 `code: 0` 成功
- **代码实现**：`_request()` 新增 `skip_sign: bool = False` 参数，`_fetch_orders_from_api()` 调用时传 `skip_sign=True`

**Query 参数（仅保留有效参数）**：
| 参数 | 类型 | 必填 | 示例值 | 说明 |
|------|------|------|--------|------|
| `page` | int | 是 | `0` | 页码（从 0 开始） |
| `pageSize` | int | 是 | `10` | 每页数量 |
| `order_by` | string | 是 | `create_time` | 排序字段 |
| `order` | string | 是 | `desc` | 排序方向 |
| `tab` | string | 是 | `all` | 订单标签 |
| `appid` | int | 是 | `1` | 应用 ID |
| `__token` | string | 是 | `3b2d8e84e606...` | 稳定 Token (TOKEN，长效) |
| `verifyFp` | string | 是 | `verify_muxpd4sm_...` | 设备指纹 (VERIFY_FP，长效) |
| `fp` | string | 是 | `verify_muxpd4sm_...` | 设备指纹 (FP，长效) |
| `compact_time[select]` | string | 否 | `create_time_start,create_time_end` | 时间筛选模式 |
| `create_time_start` | int | 否 | `1788763712` | 开始时间戳 |
| `create_time_end` | int | 否 | `1791355712` | 结束时间戳 |

**固定参数**：
- `_bid=ffa_order`
- `aid=FXG_ORDER_AID` (4272)
- `_lid=606316310312` （实测有效值，不同于配置默认值 550078945638）

**参数策略说明**：
- **长效参数（显式传递）**：`__token`、`verifyFp`、`fp` —— 从配置读取，有效期长（天级），直接加入请求
- **强时效参数（跳过注入）**：`msToken`、`a_bogus` —— 有效期极短（分钟级），通过 `skip_sign=True` 禁止 `_request` 自动注入，避免导致 `10001010A` 签名错误
- **实测有效 `_lid`**：使用 `606316310312`（用户浏览器抓包值），而非配置默认值

**❌ 不需要的参数**（会导致失败）：
- `msToken` (MS_TOKEN) — 时效性极强，几分钟失效
- `a_bogus` (A_BOGUS) — 时效性极强，几分钟失效

**优化后请求头（2026-10-07 更新，模拟浏览器指纹以获取丰富数据）**：
```
Accept: application/json, text/plain, /*
Accept-Language: zh-CN,zh;q=0.9
Accept-Encoding: gzip, deflate, br, zstd
Priority: u=1, i
User-Agent: Config.USER_AGENT (Chrome 150)
Referer: https://fxg.jinritemai.com/ffa/order
Sec-Fetch-Dest: empty
Sec-Fetch-Mode: cors
Sec-Fetch-Site: same-origin
Sec-Ch-Ua: "Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"
Sec-Ch-Ua-Mobile: ?0
Sec-Ch-Ua-Platform: "Windows"
Cache-Control: no-cache
Pragma: no-cache
Cookie: FXG_COOKIES
```

**关键差异说明**：
- `Referer` 指向具体订单页面 (`/ffa/order`) 而非首页
- 完整的 `Sec-Fetch-*` 与 `Sec-Ch-Ua-*` 指纹头，通过浏览器反爬检测
- `Priority: u=1, i` 表示高优先级资源请求
- `Accept-Encoding` 包含 `zstd` 支持现代压缩

**返回示例（浏览器实测返回丰富字段）**：
```json
{
  "st": 0,
  "code": 0,
  "msg": "",
  "data": [
    {
      "shop_order_id": "6952528259545240685",
      "order_status": 3,
      "create_time": 1744624277862,
      "update_time": 1744624277862,
      "pay_time": 1744624277862,
      "product_item": [
        {
          "product_id": "123456",
          "product_name": "海盐嘭润保湿沐浴露",
          "spec_name": "默认规格",
          "count": 1,
          "price": 29.9,
          "img": "https://..."
        }
      ],
      "receiver_info": {
        "name": "张三",
        "phone": "138****8888",
        "province": "广东省",
        "city": "深圳市",
        "district": "南山区",
        "address": "科技园路1号",
        "full_address": "广东省深圳市南山区科技园路1号"
      },
      "operation_actions": [
        {"name": "发货", "action_id": "ship"},
        {"name": "退款", "action_id": "refund"}
      ],
      "total_amount": 29.9,
      "pay_amount": 29.9,
      "freight_amount": 0,
      "buyer_memo": "",
      "shop_id": "257675707"
    }
  ],
  "page": 0,
  "size": 10,
  "total": 1,
  "order": "desc",
  "order_by": "create_time"
}
```

**⚠️ 实测完整字段列表（97 字段，2026-10-08 验证）**：
单个订单对象包含以下关键字段分组：

**基础标识与状态**：
| 字段 | 类型 | 说明 |
|------|------|------|
| `shop_order_id` | string | 店铺订单号（主键，如 `"6952528259545240685"`） |
| `order_id` | string | 平台订单号（有时为空字符串） |
| `order_status` | int | 订单状态码（3=待发货，4=已完成等） |
| `order_status_info` | object | 状态描述对象（含文本、颜色等 UI 信息） |
| `order_status_desc` | string | 状态文本描述 |

**金额信息（单位：分）**：
| 字段 | 类型 | 说明 |
|------|------|------|
| `pay_amount` | int | 实付金额（如 `6202` = ¥62.02） |
| `actual_receive_amount` | string | 商家实收金额（格式化，如 `"¥62.02"`） |
| `actual_receive_amount_int` | int | 商家实收金额（分） |
| `total_post_amount` | int | 邮费 |
| `promotion_amount` | int | 优惠金额 |
| `total_amount` | float | 订单总金额（元） |
| `product_amount` | float | 商品金额（元） |

**时间戳（毫秒/秒混合）**：
| 字段 | 类型 | 说明 |
|------|------|------|
| `create_time` | int | 下单时间（毫秒，如 `1777760073000`） |
| `pay_time` | int | 支付时间 |
| `update_time` | int | 更新时间 |
| `exp_ship_time` | int | 预期发货时间 |
| `create_time_str` | string | 格式化下单时间 |
| `pay_time_str` | string | 格式化支付时间 |

**商品明细**：
| 字段 | 类型 | 说明 |
|------|------|------|
| `product_item` | array | **核心：商品列表数组** |
| `product_count` | int | 商品种类数 |
| `product_item[].product_id` | string | 商品 ID |
| `product_item[].product_name` | string | 商品名称 |
| `product_item[].spec_name` | string | 规格名称 |
| `product_item[].count` | int | 购买数量 |
| `product_item[].price` | float | 单价（元） |
| `product_item[].img` | string | 商品主图 URL |

**买家信息**：
| 字段 | 类型 | 说明 |
|------|------|------|
| `user_nickname` | string | 脱敏买家昵称（如 `"东*"`） |
| `user_id` | string | 脱敏用户 ID |
| `buyer_memo` | string | 买家备注 |
| `buyer_words` | string | 买家留言 |

**收货信息（详细）**：
| 字段 | 类型 | 说明 |
|------|------|------|
| `receiver_info` | object | **详细收货人信息对象** |
| `receiver_info.post_receiver` | string | 收货人姓名（脱敏，如 `"郭*"`） |
| `receiver_info.post_tel` | string | 电话（脱敏，如 `"1**********"`） |
| `receiver_info.post_addr` | object | 省/市/区/街道完整地址对象 |
| `receiver_info.post_addr.province_name` | string | 省份 |
| `receiver_info.post_addr.city_name` | string | 城市 |
| `receiver_info.post_addr.district_name` | string | 区县 |
| `receiver_info.post_addr.street_name` | string | 街道 |
| `receiver_info.post_addr.detail` | string | 详细地址 |

**操作动作（后台可用操作）**：
| 字段 | 类型 | 说明 |
|------|------|------|
| `operation_actions` | array | 可用操作列表（发货、退款、改价等） |
| `operation_actions[].name` | string | 操作名称（如 "发货"、"退款"） |
| `operation_actions[].action_id` | string | 操作标识（如 "ship"、"refund"） |
| `action_map` | object | 操作映射表（联系买家、备注、修改地址等） |

**物流信息**：
| 字段 | 类型 | 说明 |
|------|------|------|
| `way_bill_url` | string | 运单链接 |
| `latest_logistic_info` | object | 最新物流轨迹对象 |
| `logistics_company` | string | 物流公司名称 |
| `tracking_no` | string | 快递单号 |

**其他**：
| 字段 | 类型 | 说明 |
|------|------|------|
| `remark` | string | 商家备注 |
| `shop_id` | string | 店铺 ID |
| `service_info` | object | 售后服务信息 |
| `promotion_info` | array | 优惠详情数组 |

**分页信息（顶层）**：
| 字段 | 类型 | 说明 |
|------|------|------|
| `page` | int | 当前页码（从 0 开始） |
| `size` | int | 每页数量 |
| `total` | int | 总记录数 |
| `order` | string | 排序方向 (`desc`/`asc`) |
| `order_by` | string | 排序字段 (`create_time`) |

---

### 创作者概览 `/janus/douyin/creator/data/overview/dashboard`

**方法**：POST

**完整 URL**：`https://creator.douyin.com/janus/douyin/creator/data/overview/dashboard`

**Body 参数 (JSON)**：
| 参数 | 类型 | 必填 | 示例值 | 说明 |
|------|------|------|--------|------|
| `recent_days` | int | 是 | `7` | 统计天数 |

**签名参数**：创作者中心暂**不自动注入签名**，依赖 Cookie 中的 `x_tt_token` 等字段。

**请求头**：
```
User-Agent: Config.USER_AGENT
Referer: https://creator.douyin.com/
Cookie: CREATOR_COOKIES (字符串)
Accept: application/json, text/plain, */*
Content-Type: application/json
```

**⚠️ 实际返回格式（2026-10-08 验证）**：`metrics` 数组，非旧文档的 `data` 对象。每个 metric 含 `trends` 字段（7 天每日趋势数据）。

**返回示例**：
```json
{
  "status_code": 0,
  "metrics": [
    {"english_metric_name": "total_fans_cnt", "metric_value": 1166, "metric_name": "粉丝", "trends": [...]},
    {"english_metric_name": "publish_cnt", "metric_value": 0, "metric_name": "投稿量", "trends": [...]},
    {"english_metric_name": "play_cnt", "metric_value": 47, "metric_name": "播放量", "trends": [...]},
    {"english_metric_name": "digg_cnt", "metric_value": 2, "metric_name": "作品点赞", "trends": [...]},
    {"english_metric_name": "share_count", "metric_value": 0, "metric_name": "作品分享", "trends": [...]},
    {"english_metric_name": "comment_cnt", "metric_value": 0, "metric_name": "作品评论", "trends": [...]},
    {"english_metric_name": "net_fans_cnt", "metric_value": -3, "metric_name": "净增粉丝", "trends": [...]},
    {"english_metric_name": "cancel_fans_cnt", "metric_value": 3, "metric_name": "取关粉丝", "trends": [...]},
    {"english_metric_name": "homepage_view_cnt", "metric_value": 10, "metric_name": "主页访问", "trends": [...]},
    {"english_metric_name": "avg_view_second", "metric_value": 3.23, "metric_name": "平均播放时长", "trends": [...]},
    {"english_metric_name": "completion_rate_5s", "metric_value": 0.1, "metric_name": "5秒完播率", "trends": [...]},
    {"english_metric_name": "bounce_rate_2s", "metric_value": 0.67, "metric_name": "2秒跳出率", "trends": [...]},
    {"english_metric_name": "cover_click_ratio", "metric_value": null, "metric_name": "封面点击率", "trends": [...]}
  ],
  "status_msg": ""
}
```

**Metrics 完整字段表（13 项）**：
| # | `english_metric_name` | `metric_name` | `metric_value` | 类型 | 说明 |
|---|----------------------|---------------|----------------|------|------|
| 1 | `total_fans_cnt` | 粉丝 | **1166** | int | **总粉丝数（核心指标）** |
| 2 | `publish_cnt` | 投稿量 | **0** | int | 总视频/投稿数 |
| 3 | `play_cnt` | 播放量 | **47** | int | 总播放量 |
| 4 | `digg_cnt` | 作品点赞 | **2** | int | 总点赞数 |
| 5 | `share_count` | 作品分享 | **0** | int | 总分享数 |
| 6 | `comment_cnt` | 作品评论 | **0** | int | 总评论数 |
| 7 | `net_fans_cnt` | 净增粉丝 | **-3** | int | 近期净增粉（负数=掉粉） |
| 8 | `cancel_fans_cnt` | 取关粉丝 | **3** | int | 取关数 |
| 9 | `homepage_view_cnt` | 主页访问 | **10** | int | 主页访问量 |
| 10 | `avg_view_second` | 平均播放时长 | **3.23** | float | 平均播放秒数 |
| 11 | `completion_rate_5s` | 5秒完播率 | **0.1** | float | 10%（0-1 之间） |
| 12 | `bounce_rate_2s` | 2秒跳出率 | **0.67** | float | 67%（0-1 之间） |
| 13 | `cover_click_ratio` | 封面点击率 | `null` | float/null | 无数据时为 null |

**Trends 每日趋势结构**（每个 metric 含 7 天数据）：
| 字段 | 类型 | 说明 |
|------|------|------|
| `date` | string | 日期 (YYYY-MM-DD) |
| `douyin_value` | int/float | 抖音端数值 |
| `xigua_value` | int/float | 西瓜视频端数值 |
| `yumme_value` | int/float | 火山/皮皮虾端数值 |
| `change_rate` | float | 环比变化率 |
| `change_value` | int/float | 环比变化绝对值 |

**字段映射（内部 `_fetch_creator_overview_from_api()` 实现）**：
| 内部标准字段 | 外部 `english_metric_name` | 备注 |
|-------------|---------------------------|------|
| `total_followers` | `total_fans_cnt` | 兼容旧 `follow_cnt` |
| `total_videos` | `publish_cnt` | 兼容旧 `aweme_cnt` |
| `total_views` | `play_cnt` | 新增字段 |
| `total_likes` | `digg_cnt` | 兼容旧 `like_cnt` |
| `total_comments` | `comment_cnt` | 新增字段 |
| `total_shares` | `share_count` | 兼容旧 `share_cnt` |
| `recent_followers_gain` | `net_fans_cnt` | 兼容旧 `net_followers_gain` |
| `recent_view` | `play_cnt` | 兼容旧字段名 |
| `recent_like` | `digg_cnt` | 兼容旧字段名 |

---

### 创作者作品 `/janus/douyin/creator/pc/work_list`

**方法**：GET

**完整 URL**：`https://creator.douyin.com/janus/douyin/creator/pc/work_list`

**Query 参数**：
| 参数 | 类型 | 必填 | 示例值 | 说明 |
|------|------|------|--------|------|
| `status` | string | 是 | `0` | 状态：`0`(全部)/`1`(已发布) |
| `count` | string | 是 | `12` | 每页数量 |
| `max_cursor` | string | 是 | `0` | 分页游标 |
| `scene` | string | 是 | `star_atlas` | 场景 |
| `device_platform` | string | 是 | `android` | 设备平台 |
| `aid` | int | 是 | `1128` | 应用 ID (CREATOR_WORK_AID) |

**签名参数**：暂不自动注入，依赖 Cookie。

**请求头**：
```
User-Agent: Config.USER_AGENT
Referer: https://creator.douyin.com/creator-micro/content/manage
Accept: application/json, text/plain, */*
Cookie: CREATOR_COOKIES (字符串)
```

**⚠️ 关键差异**：创作者中心作品列表**必须使用 `cookies` 参数传递字典**（`requests` 的 `cookies=`），而非 `Cookie` Header 字符串。

**⚠️ 实际返回格式（2026-10-08 验证）**：`aweme_list` 数组，包含完整的视频详情（`statistics`、`video`、`author`、`create_time` 等）。

**返回示例**：
```json
{
  "status_code": 0,
  "aweme_list": [
    {
      "aweme_id": "7622892105911864616",
      "desc": "",
      "statistics": {"play_count": 283, "digg_count": 20, "comment_count": 2, "share_count": 0},
      "author": {"uid": "...", "nickname": "创作者名"},
      "create_time": 1791355712,
      "video": {"cover": {"url_list": ["https://..."]}, "play_addr": {"url_list": ["https://..."]}}
    }
  ],
  "total": 12
}
```

**⚠️ 实测完整字段列表（aweme_list 单元素 40+ 字段，2026-10-08 验证）**：
| 分组 | 关键字段 | 类型/示例 | 说明 |
|------|----------|-----------|------|
| **基础标识** | `aweme_id` | string | 作品唯一 ID |
| | `item_id` | string | 同 aweme_id |
| | `group_id` | string | 分组 ID |
| | `desc` | string | 视频标题/描述 |
| | `create_time` | int | 发布时间戳（秒） |
| | `duration` | int | 时长（毫秒，如 `4064`） |
| **统计数据** | `statistics.play_count` | int | 播放数（如 `283`） |
| | `statistics.digg_count` | int | 点赞数（如 `20`） |
| | `statistics.comment_count` | int | 评论数（如 `2`） |
| | `statistics.share_count` | int | 分享数（如 `0`） |
| | `statistics.collect_count` | int | 收藏数 |
| | `statistics.forward_count` | int | 转发数 |
| **作者信息** | `author.nickname` | string | 创作者昵称 |
| | `author.uid` | string | 用户 ID |
| | `author.follower_count` | int | 粉丝数 |
| | `author.aweme_count` | int | 总作品数 |
| **视频详情** | `video.cover.url_list` | array | 封面图 URL 列表 |
| | `video.play_addr.url_list` | array | 播放地址 URL 列表 |
| | `video.width/height` | int | 分辨率（1280×720） |
| | `video.duration` | int | 时长毫秒 |
| | `video.has_watermark` | bool | 是否有水印 |
| | `video.ratio` | string | 清晰度标识（如 `"720p"`） |
| | `video.bit_rate` | int | 码率 |
| **状态与权限** | `status_value` | int | 状态值（如 `102`） |
| | `status.allow_comment` | bool | 允许评论 |
| | `status.is_private` | bool | 是否私密 |
| | `status.is_delete` | bool | 是否删除 |
| **风控/标签** | `risk_infos` | array | 风控提示（如 `"作品含 AI 生成内容"`） |
| | `video_labels` | array | 视频标签 |
| | `commerce_info` | object | 电商带货信息（如有） |
| **其他** | `region` | string | 地区标识 |
| | `music_info` | object | 背景音乐信息 |
| | `challenge_info_list` | array | 话题挑战信息 |

**顶层字段**：
| 字段 | 类型 | 说明 |
|------|------|------|
| `status_code` | int | 成功标识 (0) |
| `total` | int | 总作品数（如 42） |
| `aweme_list` | array | 当前页作品列表（默认 12 条） |
| `has_more` | bool | 是否有更多 |
| `max_cursor` | string | 下一页游标 |

---

## 外部 API 字段跨接口映射速查表（内部标准化字段对照）

| 内部标准字段 | 抖店商品统计 | 抖店商品列表 | 抖店订单统计 | 抖店订单列表 | 创作者概览 | 创作者作品 |
|-------------|-------------|-------------|-------------|-------------|-----------|-----------|
| **总数/计数** | `data.onsale` | `len(data)` | `data.all` | `data[].product_count` | `total_fans_cnt` (粉丝) | `total` (总作品数) |
| **金额(分)** | - | `discount_price`*100 | - | `pay_amount` | - | - |
| **播放量** | - | - | - | - | `play_cnt` | `statistics.play_count` |
| **点赞数** | - | - | - | - | `digg_cnt` | `statistics.digg_count` |
| **评论数** | - | - | - | - | `comment_cnt` | `statistics.comment_count` |
| **分享数** | - | - | - | - | `share_count` | `statistics.share_count` |
| **粉丝数** | - | - | - | - | `total_fans_cnt` | `author.follower_count` |
| **作品数** | - | - | - | - | `publish_cnt` | `author.aweme_count` |
| **收货信息** | - | - | - | `receiver_info` | - | - |
| **商品明细** | - | `data[]` | - | `product_item[]` | - | `aweme_list[]` |
| **操作动作** | - | - | - | `operation_actions` | - | - |

> `*` 商品列表价格字段为元单位，内部转换为分存储

---

详见归档历史文档 `archive_cleanup_20260923/legacy_docs/api_old/`.

---

### 通用告警配置

`GET /api/v1/alerts/config` / `POST /api/v1/alerts/config`

**GET 返回字段**：
```json
{
  "sales_drop_threshold": 0.3,
  "conversion_drop_threshold": 0.2,
  "inventory_low_threshold": 10,
  "notification_email": "admin@example.com",
  "enabled": true
}
```

**POST 请求体**（所有字段可选）：
```json
{
  "sales_drop_threshold": 0.3,
  "conversion_drop_threshold": 0.2,
  "inventory_low_threshold": 10,
  "notification_email": "admin@example.com",
  "enabled": true
}
```

---

### 抖店告警配置

`GET /api/v1/alerts/dian/config` / `POST /api/v1/alerts/dian/config`

**GET 返回字段**：
```json
{
  "product_sales_drop_threshold": 0.3,
  "order_refund_rate_threshold": 0.15,
  "compliance_risk_threshold": "medium",
  "notification_email": "admin@example.com",
  "enabled": true
}
```

**POST 请求体**（所有字段可选）：
```json
{
  "product_sales_drop_threshold": 0.3,
  "order_refund_rate_threshold": 0.15,
  "compliance_risk_threshold": "medium",
  "notification_email": "admin@example.com",
  "enabled": true
}
```

---

### 抖音告警配置

`GET /api/v1/alerts/douyin/config` / `POST /api/v1/alerts/douyin/config`

**GET 返回字段**：
```json
{
  "video_view_drop_threshold": 0.3,
  "video_like_drop_threshold": 0.2,
  "creator_follower_drop_threshold": 0.1,
  "notification_email": "admin@example.com",
  "enabled": true
}
```

**POST 请求体**（所有字段可选）：
```json
{
  "video_view_drop_threshold": 0.3,
  "video_like_drop_threshold": 0.2,
  "creator_follower_drop_threshold": 0.1,
  "notification_email": "admin@example.com",
  "enabled": true
}
```

---

### 告警历史

`GET /api/v1/alerts/history`

**查询参数**：
- `limit` (可选): 每页数量，默认 50，最大 200
- `offset` (可选): 偏移量，默认 0
- `type` (可选): 告警类型过滤（`sales_drop`、`low_inventory`、`conversion_drop`）

**返回**：
```json
{
  "list": [
    {
      "type": "sales_drop",
      "product_id": "xxx",
      "product_name": "商品名",
      "message": "Product xxx sales dropped by 50%",
      "drop_rate": 0.5,
      "threshold": 0.3,
      "timestamp": "2026-09-23T10:00:00"
    }
  ],
  "total": 100,
  "limit": 50,
  "offset": 0
}
```

`DELETE /api/v1/alerts/history`

**返回**：
```json
{
  "cleared": 100
}
```

---

### 告警统计汇总

`GET /api/v1/alerts/history/stats`

**返回**：
```json
{
  "total": 100,
  "by_type": {
    "sales_drop": 50,
    "low_inventory": 30,
    "conversion_drop": 20
  }
}
```

---

## 关键修复记录（2026-10-07/08 验证）

### 1. 订单列表签名策略修复 (`/api/order/searchlist`)

**问题**：带过期签名请求返回 `10001010A` (SIGNATURE_ERROR/RISK_CONTROL)

**根因**：该端点**不需要** `a_bogus`、`msToken` 时效性签名参数。仅需长效 Cookie 认证（`__token`、`verifyFp`、`fp`）。

**修复**：
- `_request()` 新增 `skip_sign: bool = False` 参数
- `_fetch_orders_from_api()` 调用时显式传 `skip_sign=True`
- 仅保留长效参数：`__token`、`verifyFp`、`fp`、`_lid=606316310312`（实测有效值）

**参数策略**：
| 类型 | 参数 | 处理方式 |
|------|------|----------|
| 长效 | `__token`、`verifyFp`、`fp` | 显式传递（配置读取） |
| 强时效 | `msToken`、`a_bogus` | `skip_sign=True` 禁止自动注入 |
| 固定 | `_lid` | 使用实测值 `606316310312` |

### 2. Redis 缓存共享问题

**现象**：Flask 容器 (`douyin_monitor`) 和 Celery Worker (`douyin_celery_worker`) 各自独立内存缓存，Redis 连接失败时回退到内存字典 (`redis_cache.py:104-107`)，导致同步任务写入 Redis 但 Flask 读不到。

**解决**：
- 重启两个容器确保 Redis 连接建立：`docker restart douyin_monitor douyin_celery_worker`
- 验证：`docker exec douyin_redis redis-cli GET 'douyin:monitor:creators'`

### 3. 创作者概览字段解析修复

**问题**：外部 API 返回 `metrics` 数组，内部代码按旧格式 `data.creators`/`data.total_followers` 解析，导致全 0。

**修复**：`_fetch_creator_overview_from_api()` 和 `_fetch_creators_from_api()` 兼容解析 `metrics` 数组，按 `english_metric_name` 映射标准字段。

### 4. 内部 API 验证结果（2026-10-08 同步后）

| 接口 | 状态 | data_source | 关键字段 |
|------|------|-------------|----------|
| `GET /api/v1/creators/overview` | ✅ | external | total_followers: 1166, total_views: 47, recent_like: 2 |
| `GET /api/v1/creators/works` | ✅ | external | 12 个作品完整详情 |
| `GET /api/v1/creators` | ✅ | real | 1 个创作者聚合统计 |
| `GET /api/v1/orders/stats` | ✅ | real | all: 1 单 62.02元 |
| `GET /api/v1/orders` | ✅ | real | 1 个订单完整详情 |
| `GET /api/v1/products` | ✅ | real | 商品列表 |
| `POST /api/v1/sync` | ✅ | - | 6/6 任务全成功 |

---

## 认证与请求头

### 内部 API 认证（Flask + axios）

**后端鉴权中间件**（`app.py:check_auth`）：
- **Header 校验**：同时检查 `Authorization: Bearer <API_KEY>` 和 `X-API-Key: <API_KEY>`
- **通过条件**：任一 Header 校验通过即可（建议前后端双发）
- **白名单端点**（`PUBLIC_ENDPOINTS`）：
  - `/api/v1/health` - 健康检查
  - `/api/v1/auth/login` - OAuth 登录入口
  - `/api/v1/auth/callback` - OAuth 回调
  - `/api/v1/auth/qr-code` - 获取登录二维码
  - `/api/v1/auth/status` - 授权状态查询
- **API_KEY 来源**：`Config.API_KEY`（优先读取 Docker secret `api_key`，回退环境变量 `API_KEY`）
- **默认值**：`wlkj_douyin_api_20260921_abc123`
- **SKIP_AUTH 开关**：`SKIP_AUTH=true` 环境变量可完全跳过鉴权（调试用）

**前端 axios 封装**（`src/frontend/src/utils/apiClient.ts`）：
```typescript
// 同时发送双 Header
instance.defaults.headers.common['X-API-Key'] = token
instance.defaults.headers.common['Authorization'] = `Bearer ${token}`

// Token 来源优先级：VITE_API_KEY > localStorage.authToken
```
- 401 响应时自动清空 token，由调用方决定是否跳转登录
- 非 401 错误自动弹出 `message.error` 提示

### 外部 API 认证（抖店/创作者中心）

**统一请求转发器**（`services.fetcher._request`）：

| 项目 | 抖店 (`fxg.jinritemai.com`) | 创作者中心 (`creator.douyin.com`) |
|------|---------------------------|-------------------------------|
| **Base URL** | `Config.FXG_BASE_URL` | `Config.CREATOR_BASE_URL` |
| **Cookie 来源** | `FXG_COOKIES` (完整域名 Cookie 字符串) | `CREATOR_COOKIES` (完整域名 Cookie 字符串) |
| **Cookie 传递方式** | `headers['Cookie']` 字符串 | `cookies=` 字典参数（`requests` 的 `cookies=`） |
| **Cookie 预处理** | 直接使用字符串 | `parse_cookies(cookie_str)` 转字典 |
| **动态签名** | `a_bogus`, `msToken`, `verifyFp`, `fp`, `__TOKEN` | 同上（仅 fxg 域名由 `_request` 自动签名） |
| **固定参数** | `_bid=ffa_product`, `aid=FXG_SHOP_ID`, `_lid=FXG_PRODUCT_LID` | `aid=CREATOR_WORK_AID` (无 `_bid`/`_lid`) |
| **Referer** | `https://fxg.jinritemai.com/` | `https://creator.douyin.com/creator-micro/content/manage` |
| **User-Agent** | `Config.USER_AGENT` (Chrome 150) | 同上 |
| **签名实现** | `douyin_sign.sign_request` (V8 实时计算 `a_bogus`) | 同上（仅 fxg 域名触发） |
| **典型端点** | `/product/tproduct/list`, `/api/order/searchlist` | `/janus/douyin/creator/pc/work_list` |

**Cookie 传递差异**（关键点，已在 fetcher.py 实现）：
- **抖店接口**：通过 `headers['Cookie']` 传递字符串
- **创作者中心作品列表** (`/janus/douyin/creator/pc/work_list`)：**必须**使用 `cookies` 参数传递字典（`requests` 库的 `cookies=`），而非 `Cookie` Header

**请求参数差异**：
- **抖店商品/订单**：需 `_bid`、`aid`、`_lid`、`_token` 等签名参数（由 `_request` 自动注入）
- **创作者作品列表**：`status=0`, `count=12`, `max_cursor=0`, `scene=star_atlas`, `device_platform=android`, `aid=CREATOR_WORK_AID`（无签名参数自动注入）

**错误码分类与指引**（`_classify_external_error` + `_get_auth_error_guidance`）：
| 类别 | 包含码 | 处理指引 |
|------|--------|----------|
| `COOKIE_EXPIRED` | `40101`, `10008` | 重新登录抓取完整 Cookie 更新 `.env` |
| `SIGNATURE_ERROR` | `40301` | 重新抓取 `a_bogus`/`msToken`/`verifyFp`/`fp`/`__token` |
| `RATE_LIMITED` | `429` | 降低频率、增加间隔、稍后重试 |
| `RISK_CONTROL` | `10001010A` | 检查账号状态，降低请求频率 |
| `HTTP_ERROR` | 非 2xx 状态码 | 检查网络/目标服务状态 |
| `TIMEOUT` | 请求超时 | 检查网络或增加超时 |
| `CONNECTION_ERROR` | 连接失败 | 检查域名可达性 |
| `EXCEPTION` | 其他异常 | 查看详细日志 |

---

## 环境变量配置（基于 `config/settings.py` Settings 类）

后端配置优先级：**Docker Secret (`/run/secrets/...`) > 环境变量 > `.env` > 默认值**。

```env
# =========================================================================
# 基础配置
# =========================================================================
DATA_DIR=./data                    # 数据存储目录（容器内映射为 /data）
SCHEDULE_INTERVAL_MINUTES=60       # 定时任务间隔（分钟）
ALERT_EMAIL=                       # 告警通知邮箱
API_AUTH_TOKEN=                    # API 认证 Token（内部服务间调用，可选）
API_KEY=wlkj_douyin_api_20260921_abc123  # API 密钥（前后端统一，也可通过 secret `api_key` 注入）
KEEP_ALIVE_TIMEOUT=30              # Keep-alive 超时（秒）
TIMEOUT=30                         # 请求超时（秒）
EXTERNAL_DATA_BASE_URL=            # 外部数据服务基础 URL（预留扩展）

# =========================================================================
# 抖音开放平台 OAuth 2.0（如需）
# =========================================================================
DOUYIN_APP_ID=                     # 抖音开放平台 App ID
DOUYIN_APP_SECRET=                 # 抖音开放平台 App Secret
DOUYIN_ACCESS_TOKEN=               # 抖音访问令牌

# =========================================================================
# 双域名基础 URL
# =========================================================================
FXG_BASE_URL=https://fxg.jinritemai.com
CREATOR_BASE_URL=https://creator.douyin.com

# =========================================================================
# 公共请求头
# =========================================================================
USER_AGENT=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36

# =========================================================================
# 认证与签名参数（强时效性，需定期手动更新，通常 2h-7 天失效）
# 获取方式：浏览器登录目标网站 -> F12 Network -> 任意请求 -> Request Headers
# =========================================================================
# 抖店签名参数
TOKEN=                             # 抖店 __TOKEN 参数
MS_TOKEN=                          # 抖店 MS_TOKEN 参数
A_BOGUS=                           # 抖店 a_bogus 参数
VERIFY_FP=                         # 抖店 verifyFp 参数
FP=                                # 抖店 fp 参数

# =========================================================================
# Cookie 配置（完整 Cookie 字符串，分号分隔）
# 获取方法：浏览器登录 -> F12 -> Network -> 任意请求 -> Request Headers -> Cookie
# =========================================================================
FXG_COOKIES=                       # 抖店 Cookie (fxg.jinritemai.com)
CREATOR_COOKIES=                   # 创作者中心 Cookie (creator.douyin.com)

# =========================================================================
# 抖店 Shop ID 与 Log ID（多店铺场景需配置）
# =========================================================================
FXG_SHOP_ID=4272                   # 抖店 Shop ID
FXG_LOG_ID=104476165896            # 抖店 Log ID
FXG_PRODUCT_LID=829906029528       # 抖店商品列表 _lid
FXG_ORDER_LID=646601599070         # 抖店订单列表 _lid
FXG_ORDER_AID=4272                 # 抖店订单列表 aid
CREATOR_WORK_AID=1128              # 创作者作品列表 aid

# =========================================================================
# Celery / Redis 配置
# =========================================================================
CELERY_BROKER_URL=redis://redis:6379/0
CELERY_RESULT_BACKEND=redis://redis:6379/0

# =========================================================================
# 创作者中心内容管理 API
# =========================================================================
CREATOR_WORK_LIST_URL=https://creator.douyin.com/janus/douyin/creator/pc/work_list

# =========================================================================
# 告警配置
# =========================================================================
ALERT_WECOM_WEBHOOK=               # 企业微信告警 Webhook
ALERT_DINGTALK_WEBHOOK=            # 钉钉告警 Webhook
ALERT_SMTP_HOST=                   # SMTP 服务器地址
ALERT_SMTP_PORT=587                # SMTP 端口
ALERT_SMTP_USER=                   # SMTP 用户名
ALERT_SMTP_PASSWORD=               # SMTP 密码
ALERT_SMTP_FROM=                   # SMTP 发件人邮箱

# =========================================================================
# 日志配置
# =========================================================================
LOG_LEVEL=INFO
LOG_FILE=logs/app.log
LOG_MAX_BYTES=10485760             # 10MB
LOG_BACKUP_COUNT=5

# =========================================================================
# 监控配置
# =========================================================================
ENABLE_METRICS=true
METRICS_PORT=9090

# =========================================================================
# Docker Secrets 对应关系（用于生产环境）
# =========================================================================
# /run/secrets/api_key              -> API_KEY
# /run/secrets/douyin_app_id        -> DOUYIN_APP_ID
# /run/secrets/douyin_app_secret    -> DOUYIN_APP_SECRET
# /run/secrets/douyin_access_token  -> DOUYIN_ACCESS_TOKEN
# /run/secrets/fxg_cookies          -> FXG_COOKIES
# /run/secrets/creator_cookies      -> CREATOR_COOKIES
# /run/secrets/token                -> TOKEN (__TOKEN)
# /run/secrets/ms_token             -> MS_TOKEN
# /run/secrets/a_bogus              -> A_BOGUS
# /run/secrets/verify_fp            -> VERIFY_FP
# /run/secrets/fp                   -> FP
# /run/secrets/fxg_shop_id          -> FXG_SHOP_ID
# /run/secrets/fxg_log_id           -> FXG_LOG_ID
```

**前端环境变量**（`.env` 或 `.env.production`）：
```env
VITE_API_KEY=wlkj_douyin_api_20260921_abc123  # 必须与后端 API_KEY 一致
VITE_API_BASE_URL=http://localhost:5000       # 开发环境后端地址
```

---

## 签名机制

所有转发至抖店/创作者中心的请求，后端 `services.fetcher._request` 自动完成（仅对 `fxg.jinritemai.com` 域名）：

1. **读取长效参数**：从 `Config` 读取 `TOKEN`、`MS_TOKEN`、`A_BOGUS`、`VERIFY_FP`、`FP`（优先 Docker Secret，回退环境变量）
2. **动态生成 `a_bogus`**：调用 `douyin_sign.sign_request(endpoint, params, existing_tokens, USER_AGENT)`，使用 `py_mini_racer` (V8) 实时计算
3. **合并参数**：将签名参数合并到请求 `params` 中
4. **注入 Cookie**：抖店用 `headers['Cookie']`，创作者中心作品列表用 `cookies=` 字典参数
5. **统一请求头**：`User-Agent` 使用 `Config.USER_AGENT`，`Accept: application/json, text/plain, */*`

**签名实现细节**（`douyin_sign.py`）：
- 加载本地 JS 签名算法文件（通常为混淆后的字节码）
- 通过 V8 运行时执行签名函数，输入：URL、参数、现有 Token、User-Agent
- 输出：更新后的 `a_bogus`、`msToken` 等动态参数
- 失败时记录警告并继续发送无签名请求（由外部 API 返回错误码触发重试/告警）

**动态参数获取来源**：
| 参数 | 获取方式 | 更新频率 |
|------|----------|----------|
| `a_bogus` | V8 实时计算 (`douyin_sign`) | 每次请求 |
| `msToken` | 浏览器页面 `window.__INIT_DATA__` 或 Cookie | 定期手动更新 |
| `verifyFp` / `fp` | 页面加载时的指纹参数 | 定期手动更新 |
| `__TOKEN` | 登录后 Cookie `passport_csrf_token` 或请求头 | 定期手动更新 |
| Cookie | 浏览器插件/开发者工具导出完整域名 Cookie | 定期手动更新（通常 2h-7 天失效） |

**生产环境建议**：
- 使用 Docker Secrets 管理所有敏感参数（`/run/secrets/...`）
- 配置监控告警：外部 API 返回 `COOKIE_EXPIRED`/`SIGNATURE_ERROR` 时自动通知
- 定期轮换 Cookie 和长效 Token（建议每日或每半日）

---

## 外部 API 概览

域名：`fxg.jinritemai.com`、`creator.douyin.com`

| 接口 | 方法 | 路径 | 说明 |
|------|------|------|------|
| 商品统计 | GET | `/product/tproduct/aggsProductCount` | 商品聚合计数 |
| 商品列表 | GET | `/product/tproduct/list` | 商品分页列表 |
| 订单统计 | GET | `/api/order/tabcnt` | 订单状态汇总 |
| 订单列表 | GET | `/api/order/searchlist` | 订单明细 |
| 创作者概览 | POST | `/janus/douyin/creator/data/overview/dashboard` | 创作者仪表盘 |
| 创作者作品 | GET/POST | `/janus/douyin/creator/pc/work_list` | 作品列表 |

---

## 错误码

### 内部 API

| 码 | 说明 |
|----|------|
| 400 | 请求参数错误 |
| 401 | 未授权 / API_KEY 无效 |
| 403 | 禁止访问 |
| 404 | 资源不存在 |
| 500 | 服务器内部错误 |
| 502 | 上游服务异常 |
| 503 | 服务不可用（熔断/限流） |

### 外部 API (抖店/创作者中心)

- `40101` / `40301`：Cookie 失效或缺失
- `10008`：登录失效
- `10001010A`：订单风控

---

## 变更记录

- **2026-10-08 v2.2.0**：
  - 全面更新 6 个外部 API 实测返回字段完整文档（基于 2026-10-08 容器环境实测）：
    - 商品统计：7 个字段详细表（`onsale`、`audit`、`draft`、`forbidden`、`sell_out_new`、`unpass`、`unpass_new`）
    - 商品列表：修正响应结构为数组 `data[]`，列出预期商品对象 10 字段
    - 订单统计：完整 15 字段表，含 `cnt_report`、`sub_tab_count_map` 13 子标签映射
    - 订单列表：新增 97 字段完整分组表（基础标识、金额、时间、商品明细、买家、收货、操作、物流、分页）
    - 创作者概览：13 项 metrics 完整表 + trends 每日趋势结构 + 9 字段内部映射表
    - 创作者作品：aweme_list 40+ 字段分组表（基础、统计、作者、视频、状态、风控、其他）+ 顶层 5 字段
  - 新增「外部 API 字段跨接口映射速查表」：6 接口核心字段对照，便于内部标准化字段开发
- **2026-10-08 v2.1.0**：
  - 修复创作者概览字段解析：外部 API 实际返回 `metrics` 数组，内部 `_fetch_creator_overview_from_api()` / `_fetch_creators_from_api()` 兼容解析并按 `english_metric_name` 映射标准字段（新增字段映射表）
  - 修复订单列表签名策略：`_request()` 新增 `skip_sign` 参数，`_fetch_orders_from_api()` 显式传 `skip_sign=True`，仅保留长效参数（`__token`/`verifyFp`/`fp`），禁止过期 `msToken`/`a_bogus` 注入
  - 解决 Redis 缓存共享问题：Flask 与 Celery Worker 需重启建立 Redis 连接，避免内存 fallback 导致数据不一致
  - 更新创作者概览/作品外部 API 实际返回格式文档（`metrics` 数组、`aweme_list` 完整结构）
  - 补充内部 API 验证结果表（7 个接口全部通过）
- **2026-10-07 v2.0.2**：
  - 优化 `searchlist` 订单列表请求头：补充完整浏览器指纹头（`Sec-Fetch-*`、`Sec-Ch-Ua-*`、`Priority`、`Accept-Encoding: zstd`、`Referer: /ffa/order`），配合 `skip_sign=True` 跳过过期签名注入，复现浏览器丰富响应字段（`product_item`、`receiver_info`、`operation_actions` 等）
  - `_request()` 新增 `skip_sign` 参数，`_fetch_orders_from_api()` 显式传 `skip_sign=True`
- **2026-10-07 v2.0.1**：根据实际代码完善「认证与请求头」「环境变量配置」「签名机制」三节，补充：
  - 内部 API 双 Header 鉴权细节、白名单端点、SKIP_AUTH 开关、前端 axios 拦截器行为
  - 外部 API 双域名认证差异、Cookie 传递方式差异、错误码分类与修复指引表
  - 环境变量完整清单（基于 `config/settings.py` Settings 类，含 Docker Secrets 映射）
  - 签名机制实现细节（V8 实时计算 `a_bogus`、参数来源表、生产环境建议）
- **2026-10-07 v1.2.2**：
  - 更新 FXG_COOKIES / CREATOR_COOKIES：修复抖店 Cookie 过期 (10008) 导致的 `/api/v1/products/stats`、`/api/v1/orders/stats` 返回空数据
  - 修复前端 nginx 502 Bad Gateway：重启 douyin_frontend 清理 upstream 缓存的旧 monitor 容器 IP
  - 统一环境变量配置源：建立 `/opt/douyin-platform/.env -> config/.env` 软链接，docker-compose.yml 读取 `./config/.env`

- **2026-10-08 v2.3.0**（3容器架构精简版）:
  - 精简架构：从 5 容器（monitor + celery_worker + celery_beat + redis + frontend）降至 3 容器（app + redis + frontend）
  - 合并职责：`app` 容器同时包含 Flask REST API + 嵌入式 sync scheduler（使用 `schedule` + `threading`），不再需要独立 `celery_worker` 和 `celery_beat` 进程
  - 分布式锁：在 `app.py` 中实现 Redis `SET NX EX`（5分钟 TTL），防止并发同步任务重复执行
  - 强制 Redis 连接：`redis_cache.py` P0 修复，移除内存 fallback，启动时若 Redis 不可用将直接报错退出
  - creator works 语法修复：`blueprints/creators.py` 添加缺失的 `get_creator_works()` 函数，修复原 `GET /creators/works/external` 500 错误
  - Dockerfile 权限修复：使用 `CMD` 直接运行 gunicorn 替代 `ENTRYPOINT`，避免 `entrypoint.sh` 权限被拦截问题
  - 数据流验证：所有 6 个外部 API 抓取正常，同步间隔配置为 60 分钟（可通过 `SCHEDULE_INTERVAL_MINUTES` 环境变量配置）

- **2026-09-26 v1.2.1**：
  - 修正同步 API：`POST /api/v1/sync` 支持 `?async=true` 异步模式（Celery 任务队列）
  - 新增通用告警配置端点：`GET/POST /api/v1/alerts/config`
  - 修正告警历史与统计端点：`GET/DELETE /api/v1/alerts/history`、`GET /api/v1/alerts/history/stats`
  - 明确健康检查端点无需认证（`PUBLIC_ENDPOINTS` 白名单）
  - 补充告警配置、告警历史、同步 API 的详细请求/返回字段文档

- **2026-09-23 v1.2.0**：
  - 内部 API 前缀统一为 `/api/v1`
  - `GET /api/v1/creators/overview` 替代原 `POST /creators/overview/dashboard`
  - 所有相对路径不带前导 `/`，配合 `baseURL: '/api/v1'`
  - 前端鉴权头同时发送 `Authorization: Bearer` + `X-API-Key`

*历史版本已归档至 `archive_cleanup_20260923/legacy_docs/api_old/`*