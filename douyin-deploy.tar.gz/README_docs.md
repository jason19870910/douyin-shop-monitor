---
title: 项目文档索引
version: 2.0.0
status: Published
last_updated: 2026-10-07
owner: PM
reviewers: ['Tech Lead']
approvers: ['PM']
classification: Public
doc_id: DOC-REF-001
tags: ['索引', 'README', '文档导航']
related_docs: []
changelog: |
  v2.0.0 (2026-10-07): 文档精简重构，更新导航索引映射新结构 - PM
  v1.2.0 (2026-10-05): 更新统一 Docker Compose 部署 - DevOps Lead
---

# 抖音电商数据监控平台 - 文档索引

> 本文档为项目文档的统一导航入口，按功能分类组织所有核心文档。

---

## 1. 项目概览

| 文档 | 说明 | 维护者 |
|------|------|--------|
| [README.md](README.md) | 项目总览、架构、部署、常用命令 | PM |
| [CHANGELOG.md](../CHANGELOG.md) | 版本变更记录 | PM |

---

## 2. 架构设计

| 文档 | 说明 | 维护者 |
|------|------|--------|
| [ARCHITECTURE.md](architecture/ARCHITECTURE.md) | 系统架构概览：组件、数据流、网络、部署 | Tech Lead |
| [DESIGN.md](architecture/DESIGN.md) | 详细设计：数据模型、API、前端组件、部署架构 | Tech Lead |
| [FRONTEND_DESIGN.md](architecture/FRONTEND_DESIGN.md) | 前端设计：技术栈、组件库、API、样式方案 | Frontend Lead |
| [DEPLOYMENT_ARCHITECTURE.md](architecture/DEPLOYMENT_ARCHITECTURE.md) | 部署架构设计 | DevOps Lead |

---

## 3. API 规范

| 文档 | 说明 | 维护者 |
|------|------|--------|
| [API_SPEC.md](api/API_SPEC.md) | **统一 API 规范**（内部/外部端点、认证、错误码、环境变量、签名机制） | Backend Lead |

---

## 4. 运维操作

| 文档 | 说明 | 维护者 |
|------|------|--------|
| [RUNBOOK.md](operations/RUNBOOK.md) | 运维手册：部署、监控、故障排查、应急操作、Nginx DNS 缓存修复记录 | DevOps Lead |
| [SECURITY_HARDENING.md](operations/SECURITY_HARDENING.md) | 安全加固指南 | DevOps Lead |

---

## 5. 需求管理

| 文档 | 说明 | 维护者 |
|------|------|--------|
| [REQUIREMENTS.md](requirements/REQUIREMENTS.md) | 需求规格说明书 | PM |

---

## 6. 开发规范

| 文档 | 说明 | 维护者 |
|------|------|--------|
| [GIT_WORKFLOW.md](development/GIT_WORKFLOW.md) | **Git 工作流**：分支策略、提交规范、PR 流程、代码审查指南 | Tech Lead |

---

## 7. 质量保障

| 文档 | 说明 | 维护者 |
|------|------|--------|
| [TESTING.md](quality/TESTING.md) | **测试与质量**：测试策略、质量计划、测试报告模板、代码审查清单 | QA Lead |

---

## 8. 风险管理

| 文档 | 说明 | 维护者 |
|------|------|--------|
| [RISK_REGISTER.md](risk/RISK_REGISTER.md) | **风险登记册**：事件管理、根因分析、威胁建模(STRIDE)、合规清单、变更管理 | PM |

---

## 9. 项目治理

| 文档 | 说明 | 维护者 |
|------|------|--------|
| [PROJECT_CHARTER.md](governance/PROJECT_CHARTER.md) | **项目章程**：背景、目标、范围、治理结构、沟通计划、会议结构、报告模板、危机沟通、入职/离职、工具配置、度量指标 | PM |

---

## 10. 架构决策记录

| 文档 | 说明 | 维护者 |
|------|------|--------|
| [DECISIONS.md](adr/DECISIONS.md) | **ADR 汇总**：ADR-001 React+Vite、ADR-002 Celery+Redis、ADR-003 Design Tokens 深色主题 | Tech Lead |

---

## 11. 参考资料

| 文档 | 说明 | 维护者 |
|------|------|--------|
| [FAQ.md](reference/FAQ.md) | 常见问题解答：环境搭建、开发规范、数据同步、权限、性能、监控、报错、发布 | PM/Tech Lead |
| [TROUBLESHOOTING.md](reference/TROUBLESHOOTING.md) | 故障排查指南：快速诊断、常见场景、日志位置、性能定位、应急操作 | DevOps Lead |
| [GLOSSARY.md](reference/GLOSSARY.md) | 术语表：业务/技术/架构/运维/安全/管理术语、缩略语对照 | PM |
| [permission.md](reference/permission.md) | 抖音权限能力文档：权限分类、已获/未获权限、授权二维码流程 | PM |

---

## 12. 前端项目

| 文档 | 说明 | 维护者 |
|------|------|--------|
| [src/frontend/README.md](../src/frontend/README.md) | 前端项目文档：快速开始、项目结构、5S管理、Storybook、开发工作流 | Frontend Lead |

---

## 13. 配置与部署文件

| 路径 | 说明 |
|------|------|
| [../config/.env.example](../config/.env.example) | 环境变量模板 |
| [../docker-compose.yml](../docker-compose.yml) | 统一 Docker Compose (5 服务、统一网络) |
| [../docker-compose.prod.yml](../docker-compose.prod.yml) | 生产环境覆盖配置 |
| [../src/backend/Dockerfile](../src/backend/Dockerfile) | 后端镜像构建 |
| [../src/frontend/Dockerfile](../src/frontend/Dockerfile) | 前端镜像构建 |
| [../src/frontend/nginx.conf](../src/frontend/nginx.conf) | 前端 Nginx 配置 |
| [../.github/workflows/ci.yml](../.github/workflows/ci.yml) | CI/CD 流水线 |

---

## 14. 后端核心代码

| 路径 | 说明 |
|------|------|
| [../src/backend/app.py](../src/backend/app.py) | Flask 应用入口 |
| [../src/backend/celery_config.py](../src/backend/celery_config.py) | Celery 配置 |
| [../src/backend/tasks.py](../src/backend/tasks.py) | Celery 任务实现 |
| [../src/backend/services/fetcher.py](../src/backend/services/fetcher.py) | 外部 API 数据抓取 (Cookie 修复) |
| [../src/backend/services/rule_engine.py](../src/backend/services/rule_engine.py) | 合规规则引擎 |

---

## 15. 快速链接

### 按角色查找
- **产品经理**：[REQUIREMENTS.md](requirements/REQUIREMENTS.md) → [PROJECT_CHARTER.md](governance/PROJECT_CHARTER.md) → [RISK_REGISTER.md](risk/RISK_REGISTER.md)
- **后端开发**：[API_SPEC.md](api/API_SPEC.md) → [GIT_WORKFLOW.md](development/GIT_WORKFLOW.md) → [TESTING.md](quality/TESTING.md)
- **前端开发**：[src/frontend/README.md](../src/frontend/README.md) → [FRONTEND_DESIGN.md](architecture/FRONTEND_DESIGN.md) → [DESIGN.md](architecture/DESIGN.md)
- **运维/DevOps**：[RUNBOOK.md](operations/RUNBOOK.md) → [SECURITY_HARDENING.md](operations/SECURITY_HARDENING.md) → [docker-compose.yml](../docker-compose.yml)
- **QA/测试**：[TESTING.md](quality/TESTING.md) → [API_SPEC.md](api/API_SPEC.md) → [GIT_WORKFLOW.md](development/GIT_WORKFLOW.md)
- **新成员入职**：[README.md](README.md) → [GIT_WORKFLOW.md](development/GIT_WORKFLOW.md) → [src/frontend/README.md](../src/frontend/README.md) → [FAQ.md](reference/FAQ.md)

### 按场景查找
- **新功能开发**：[GIT_WORKFLOW.md](development/GIT_WORKFLOW.md) → [API_SPEC.md](api/API_SPEC.md) → [DECISIONS.md](adr/DECISIONS.md)
- **生产故障排查**：[RUNBOOK.md](operations/RUNBOOK.md) → [TROUBLESHOOTING.md](reference/TROUBLESHOOTING.md) → [FAQ.md](reference/FAQ.md)
- **架构决策记录**：[DECISIONS.md](adr/DECISIONS.md) → [ARCHITECTURE.md](architecture/ARCHITECTURE.md)
- **发布部署**：[RUNBOOK.md](operations/RUNBOOK.md) → [docker-compose.yml](../docker-compose.yml) → [CHANGELOG.md](../CHANGELOG.md)
- **安全合规**：[SECURITY_HARDENING.md](operations/SECURITY_HARDENING.md) → [RISK_REGISTER.md](risk/RISK_REGISTER.md) → [permission.md](reference/permission.md)

---

## 16. 文档统计

| 分类 | 文档数 | 核心文档 |
|------|--------|----------|
| 架构设计 | 4 | ARCHITECTURE.md, DESIGN.md, FRONTEND_DESIGN.md, DEPLOYMENT_ARCHITECTURE.md |
| API 规范 | 1 | API_SPEC.md (合并自 3 个文件) |
| 运维操作 | 2 | RUNBOOK.md, SECURITY_HARDENING.md |
| 需求管理 | 1 | REQUIREMENTS.md |
| 开发规范 | 1 | GIT_WORKFLOW.md (合并自 3 个文件) |
| 质量保障 | 1 | TESTING.md (合并自 4 个文件) |
| 风险管理 | 1 | RISK_REGISTER.md (合并自 5 个文件) |
| 项目治理 | 1 | PROJECT_CHARTER.md (合并自 2 个文件) |
| 架构决策 | 1 | DECISIONS.md (合并自 3 个 ADR) |
| 参考资料 | 4 | FAQ.md, TROUBLESHOOTING.md, GLOSSARY.md, permission.md |
| 前端项目 | 1 | src/frontend/README.md (合并自 2 个文件) |
| **总计** | **~18** | **精简前 72 个文档** |

---

> **维护提示**：新增/变更核心文档时，请同步更新本索引表格。
> **文档精简记录**：2026-10-07 执行文档精简，从 72 个 Markdown 文件合并精简为 ~18 个核心文档，删除了重复 CHANGELOG、模板文件、缓存目录、归档文件、敏感 Secrets 文档、无关 AST/EXAMPLES/MIGRATION 等杂项。
EOF