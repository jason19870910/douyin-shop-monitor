from services.fetcher import _fetch_orders_from_api
orders = _fetch_orders_from_api()
print('orders type:', type(orders))
print('orders len:', len(orders) if isinstance(orders, list) else 'N/A')
if orders:
    o = orders[0]
    print('first order keys:', list(o.keys()) if isinstance(o, dict) else type(o))
    print('shop_order_id:', o.get('shop_order_id'))
    print('product_item:', o.get('product_item', [{}])[0].get('product_name') if o.get('product_item') else 'empty')