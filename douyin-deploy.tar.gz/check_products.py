import sys, json
data = json.loads(sys.stdin.read())
print('products count:', len(data) if isinstance(data, list) else 'not list')
if isinstance(data, list) and data:
    print('first item keys:', list(data[0].keys()))