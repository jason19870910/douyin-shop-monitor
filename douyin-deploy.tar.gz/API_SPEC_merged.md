---
title: API 规范文档
version: 2.0.1
status: Published
last_updated: 2026-10-07
owner: Backend Lead
reviewers: ['Frontend Lead', 'Tech Lead']
approvers: ['Backend Lead']
classification: Internal
doc_id: DOC-API-003
tags: ['API', '规范', '内部', '外部']
related_docs: []
changelog: |
  v2.0.0 (2026-10-07): 合并 INTERNAL-API-SPEC.md、EXTERNAL-API-SPEC.md、API_DOC.md 为统一规范文档 - DevOps Lead
  v1.2.1 (2026-09-26): 修正同步 API、新增告警配置端点、明确健康检查无需认证 - Backend Lead
  v1.2.0 (2026-09-23): 内部 API 前缀统一为 /api/v1、创作者概览改为 GET - Backend Lead
---

# API 规范文档

> Douyin 监控平台统一 API 规范，包含**内部后端 RESTful 接口**与**外部抖音电商/创作者中心接口**。

**版本**: 2.0.0
**最后更新**: 2026-10-07
**维护**: 项目核心团队

---

## 目录

1. [公共返回结构](#公共返回结构)
2. [内部 API 概览](#内部-api-概览)
3. [内部 API 详细](#内部-api-详细)
4. [外部 API 概览](#外部-api-概览)
5. [外部 API 详细](#外部-api-详细)
6. [认证与请求头](#认证与请求头)
7. [错误码](#错误码)
8. [环境变量配置](#环境变量配置)
9. [签名机制](#签名机制)

---

## 公共返回结构

### 内部 API 成功

```json
{ "success": true, "data": {}, "message": "可选" }
```

### 内部 API 错误

```json
{ "success": false, "error": "错误描述", "code": 400 }
```

### 外部 API 成功

```json
{ "code": 0, "message": "success", "data": {} }
```

### 外部 API 错误

```json
{ "code": 40001, "message": "错误描述", "data": null }
```

---

## 内部 API 概览

Base URL: `http://localhost:5000/api/v1` 开发 / 生产域名 `/api/v1`

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/v1/health` | 健康检查 |
| GET | `/api/v1/dashboard/stats` | 仪表盘聚合统计 |
| GET | `/api/v1/products` | 商品列表缓存 |
| GET | `/api/v1/products/stats` | 商品统计转发 |
| GET | `/api/v1/products/external` | 外部商品列表透传 |
| GET | `/api/v1/products/:id` | 商品详情 |
| GET | `/api/v1/orders` | 订单列表 |
| GET | `/api/v1/orders/stats` | 订单统计转发 |
| GET | `/api/v1/creators` | 创作者列表 |
| GET | `/api/v1/creators/works` | 创作者作品缓存 |
| GET | `/api/v1/creators/works/external` | 外部创作者作品透传 |
| GET | `/api/v1/creators/overview` | **创作者概览转发**（已统一为 GET） |
| GET | `/api/v1/compliance` | 合规列表 |
| GET | `/api/v1/compliance/stats` | 合规统计 |
| GET | `/api/v1/compliance/rules` | 合规规则列表 |
| POST | `/api/v1/compliance/rules` | 创建合规规则 |
| PUT | `/api/v1/compliance/rules/:id` | 更新合规规则 |
| DELETE | `/api/v1/compliance/rules/:id` | 删除合规规则 |
| POST | `/api/v1/compliance/check` | 触发合规检测 |
| GET | `/api/v1/compliance/export` | 导出合规报告 |
| GET | `/api/v1/alerts/config` | 获取通用告警配置 |
| POST | `/api/v1/alerts/config` | 更新通用告警配置 |
| GET | `/api/v1/alerts/history` | 获取告警历史（支持分页、类型过滤） |
| DELETE | `/api/v1/alerts/history` | 清空告警历史 |
| GET | `/api/v1/alerts/history/stats` | 获取告警统计汇总 |
| GET | `/api/v1/alerts/dian/config` | 获取抖店告警配置 |
| POST | `/api/v1/alerts/dian/config` | 更新抖店告警配置 |
| GET | `/api/v1/alerts/douyin/config` | 获取抖音告警配置 |
| POST | `/api/v1/alerts/douyin/config` | 更新抖音告警配置 |
| POST | `/api/v1/sync` | 手动触发同步（支持 `?async=true` 异步模式） |
| GET | `/api/v1/sync/history` | 同步历史 |
| GET | `/api/v1/mock/status` | Mock 状态 |
| GET | `/api/v1/videos` | 视频列表 |
| GET | `/api/v1/videos/:id` | 视频详情 |
| POST | `/api/v1/videos` | 创建视频 |
| PUT | `/api/v1/videos/:id` | 更新视频 |
| DELETE | `/api/v1/videos/:id` | 删除视频 |
| GET | `/api/v1/auth/qr-code` | 获取二维码 |
| GET | `/api/v1/auth/login` | 登录 |
| POST | `/api/v1/auth/logout` | 登出 |
| GET | `/api/v1/auth/status` | 授权状态 |
| GET | `/api/v1/accounts` | 账号列表 |
| GET | `/api/v1/accounts/:id` | 账号详情 |
| POST | `/api/v1/accounts` | 创建账号 |
| PUT | `/api/v1/accounts/:id` | 更新账号 |
| DELETE | `/api/v1/accounts/:id` | 删除账号 |
| GET | `/api/v1/media/video-edit` | 视频编辑列表 |
| GET | `/api/v1/media/image-edit` | 图片编辑列表 |

---

## 首页数据需求

| 区块 | 使用的 API | 说明 |
|------|------------|------|
| 整体概览（今日销售额、今日订单数、今日收入、转化率） | `GET /api/v1/dashboard/stats` | 提供 total_sales_today/yesterday, total_revenue_today/yesterday, total_orders_today/yesterday, avg_conversion_rate, sales_trend, top_products |
| 商品统计（在售/库存/违规） | `GET /api/v1/products/stats?tab=...` | 根据 tab 返回对应统计指标（销量、库存、违规数等） |
| 订单统计（全部/支付/取消） | `GET /api/v1/orders/stats` | 返回 all/pay/cancel 的 count 和 amount |
| 创作者中心概览 | `GET /api/v1/creators/overview?recent_days=7` | 返回 total_followers, total_videos, recent_view, recent_like |
| 系统健康 | `GET /api/v1/health` | 返回 status、last_update、timestamp；数据来源从 dashboard/stats 的 data_source 字段获取 |
| 立即同步触发 | `POST /api/v1/sync` | 手动触发同步（支持 `?async=true` 异步模式），成功后刷新健康状态 |
| 合规告警（可选） | `GET /api/v1/compliance/stats` + `GET /api/v1/compliance?status=pending&size=5` | 未处理高危违规数量与最近 5 条记录 |
| 告警配置开关 | `GET /api/v1/alerts/config`、`GET /api/v1/alerts/dian/config`、`GET /api/v1/alerts/douyin/config` | 是否启用各类预警 |
| Mock / 降级开关 | `GET /api/v1/mock/status` | 前端根据此决定是否展示占位数据 |

## 内部 API 详细

### 健康检查

`GET /api/v1/health`

**无需认证**（在 `PUBLIC_ENDPOINTS` 白名单中）。

```json
{ "status": "healthy", "timestamp": "...", "last_update": "..." }
```

- `status`: 固定为 `healthy`
- `timestamp`: 当前服务器时间（ISO 8601）
- `last_update`: 最近一次定时同步完成时间（来自 Redis `last_update` 键）

### 仪表盘统计

`GET /api/v1/dashboard/stats`

返回：`total_sales_today/yesterday`、`total_revenue_today/yesterday`、`total_orders_today/yesterday`、`avg_conversion_rate`、`sales_trend`、`top_products`。

**示例响应**：
```json
{
  "data": {
    "total_sales_today": 1234,
    "total_sales_yesterday": 1100,
    "total_revenue_today": 56789.00,
    "total_revenue_yesterday": 52000.00,
    "total_orders_today": 456,
    "total_orders_yesterday": 420,
    "avg_conversion_rate": 0.032,
    "avg_conversion_rate_yesterday": 0.028,
    "sales_trend": [
      {"date": "2026-08-10", "sales": 100},
      {"date": "2026-08-11", "sales": 120}
    ],
    "top_products": [
      {"product_id": "123", "product_name": "商品A", "sales_today": 50}
    ]
  }
}
```

### 商品列表

`GET /api/v1/products?page=1&size=20&keyword=`

分页返回商品缓存数据。

**查询参数**：
| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| page | int | 1 | 页码 |
| size | int | 20 | 每页数量 |
| keyword | string | - | 搜索关键词 |

**响应结构**：
```json
{
  "data": [
    {
      "product_id": "p123",
      "product_name": "商品A",
      "sales_today": 120,
      "sales_yesterday": 100,
      "inventory": 30,
      "conversion_rate": 0.12,
      "conversion_rate_today": 0.12,
      "conversion_rate_yesterday": 0.10,
      "fetched_at": "2026-08-12T10:38:30.123456"
    }
  ],
  "total": 57,
  "page": 1,
  "size": 20
}
```

### 商品详情

`GET /api/v1/products/<product_id>`

返回单个商品详情，结构同列表项。

### 商品统计

`GET /api/v1/products/stats?tab=onSale&appid=1`

转发至外部 `fxg.jinritemai.com/product/tproduct/aggsProductCount`，自动注入 Cookie 与签名。

**参数**：
| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| tab | string | onSale | `onSale`(在售) / `stock`(库存) / `violation`(违规) |
| appid | string | 1 | 应用 ID |

**返回字段**（外部透传）：
- `total_count`: 总数
- `on_sale_count`: 在售数
- `stock_count`: 库存预警数
- `violation_count`: 违规数

**外部完整响应示例**：
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "total_products": 57,
    "sales_today": 1200,
    "sales_yesterday": 1150,
    "inventory_total": 3400,
    "conversion_rate": 0.1243
  }
}
```

### 外部商品列表

`GET /api/v1/products/external`

透传所有查询参数至外部 `/product/tproduct/list`。

**外部参数**：`page`, `pageSize`, `keyword`, `appid`, `__token`, `msToken`, `a_bogus`, `verifyFp`, `fp`, `_bid`, `aid`, `_lid`

**返回字段**（`data.list`）：
- `product_id` / `product_name` / `name`
- `sales_today` / `sales_yesterday`
- `conversion_rate` / `conversion_rate_yesterday`
- `inventory` / `status`
- `market_price` / `discount_price` / `price`
- `img` / `product_url`
- `shop_id`

### 订单列表

`GET /api/v1/orders`

**查询参数**：
| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| page | int | 1 | 页码 |
| size | int | 20 | 每页数量 |
| keyword | string | - | 搜索关键词 |
| start_date | string | - | 开始日期 YYYY-MM-DD |
| end_date | string | - | 结束日期 YYYY-MM-DD |
| status | string | - | 订单状态过滤 |

**响应结构**：
```json
{
  "success": true,
  "data": {
    "abnormal": {"amount": 0, "count": 0},
    "after_sale": {"amount": 0, "count": 0},
    "all": {"amount": 12345, "count": 57}
  },
  "list": [
    {
      "order_id": "o987",
      "amount": 199,
      "status": "completed",
      "create_time": "2026-08-11",
      "fetched_at": "2026-08-12T10:38:31.456789"
    }
  ],
  "total": 57,
  "page": 1,
  "size": 20
}
```

### 订单统计

`GET /api/v1/orders/stats`

转发至外部 `fxg.jinritemai.com/api/order/tabcnt`。

**返回字段**（外部透传）：
```json
{
  "all": { "count": 100, "amount": 50000 },
  "pay": { "count": 80, "amount": 45000 },
  "cancel": { "count": 20, "amount": 5000 }
}
```

### 创作者列表

`GET /api/v1/creators?page=1&size=20&keyword=`

**响应结构**：
```json
{
  "data": [
    {
      "creator_id": "c001",
      "name": "创作者A",
      "followers": 5000,
      "total_sales": 300,
      "avg_conversion_rate": 0.15,
      "fetched_at": "2026-08-12T10:38:32.987654"
    }
  ],
  "total": 3
}
```

### 创作者详情

`GET /api/v1/creators/<creator_id>`

返回单个创作者详情，结构同列表项。

### 创作者概览

`GET /api/v1/creators/overview?recent_days=7`

**内部已统一为 GET**（外部为 `POST /janus/douyin/creator/data/overview/dashboard`）。

转发至外部创作者中心，自动注入 Cookie 与签名。

**参数**：
| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| recent_days | int | 7 | 近期天数 |

**返回字段**：
- `total_followers`: 总粉丝数
- `total_videos`: 总视频数
- `recent_view`: 近期播放量
- `recent_like`: 近期点赞数

**外部完整响应示例**：
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "total_followers": 5000,
    "total_videos": 120,
    "recent_view": 3400,
    "recent_like": 800
  }
}
```

### 创作者作品外部列表

`GET /api/v1/creators/works/external`

透传至外部 `/janus/douyin/creator/pc/work_list`，前端做字段归一化映射。

**归一化映射**：
| 前端字段 | 外部字段回退 |
|---------|-------------|
| `title` | `title` → `name` |
| `creator_name` | `creator_name` → `author_name` → `nickname` → `user_nickname` |
| `cover_url` | `cover_url` → `cover` → `cover_img` |
| `play_count` | `play_count` → `play` |
| `like_count` | `like_count` → `favorite_count` |
| `comment_count` | `comment_count` → `comment` |
| `share_count` | `share_count` → `share` |

### 告警配置 - 通用

`GET /api/v1/alerts/config` / `POST /api/v1/alerts/config`

**GET 返回字段**：
```json
{
  "sales_drop_threshold": 0.3,
  "conversion_drop_threshold": 0.2,
  "inventory_low_threshold": 10,
  "notification_email": "admin@example.com",
  "enabled": true
}
```

**POST 请求体**（所有字段可选）：
```json
{
  "sales_drop_threshold": 0.3,
  "conversion_drop_threshold": 0.2,
  "inventory_low_threshold": 10,
  "notification_email": "admin@example.com",
  "enabled": true
}
```

### 告警配置 - 抖店

`GET /api/v1/alerts/dian/config` / `POST /api/v1/alerts/dian/config`

**GET 返回字段**：
```json
{
  "product_sales_drop_threshold": 0.3,
  "order_refund_rate_threshold": 0.15,
  "compliance_risk_threshold": "medium",
  "notification_email": "admin@example.com",
  "enabled": true
}
```

**POST 请求体**（所有字段可选）：同 GET 返回字段。

### 告警配置 - 抖音

`GET /api/v1/alerts/douyin/config` / `POST /api/v1/alerts/douyin/config`

**GET 返回字段**：
```json
{
  "video_view_drop_threshold": 0.3,
  "video_like_drop_threshold": 0.2,
  "creator_follower_drop_threshold": 0.1,
  "notification_email": "admin@example.com",
  "enabled": true
}
```

**POST 请求体**（所有字段可选）：同 GET 返回字段。

### 告警历史

`GET /api/v1/alerts/history`

**查询参数**：
| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| limit | int | 50 | 每页数量，最大 200 |
| offset | int | 0 | 偏移量 |
| type | string | - | 告警类型过滤：`sales_drop`、`low_inventory`、`conversion_drop` |

**返回**：
```json
{
  "list": [
    {
      "type": "sales_drop",
      "product_id": "xxx",
      "product_name": "商品名",
      "message": "Product xxx sales dropped by 50%",
      "drop_rate": 0.5,
      "threshold": 0.3,
      "timestamp": "2026-09-23T10:00:00"
    }
  ],
  "total": 100,
  "limit": 50,
  "offset": 0
}
```

`DELETE /api/v1/alerts/history` - 清空告警历史，返回 `{ "cleared": 100 }`。

### 告警统计汇总

`GET /api/v1/alerts/history/stats`

**返回**：
```json
{
  "total": 100,
  "by_type": {
    "sales_drop": 50,
    "low_inventory": 30,
    "conversion_drop": 20
  }
}
```

### 手动触发同步

`POST /api/v1/sync?async=false`

**查询参数**：
| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| async | boolean | false | 是否异步执行（Celery 任务队列） |

**同步模式返回**：
```json
{
  "status": "completed",
  "mode": "sync",
  "last_update": "2026-09-23T10:00:00",
  "results": {
    "products": "success",
    "orders": "success",
    "creators": "success",
    "creator_works": "success",
    "compliance": "success",
    "alerts": "success"
  }
}
```

**异步模式返回**：
```json
{
  "status": "started",
  "mode": "async",
  "task_id": "celery-task-id",
  "message": "Full sync task queued"
}
```

**同步流程**：获取商品 → 获取订单 → 获取创作者 → 检查告警

---

## 外部 API 概览

域名: `fxg.jinritemai.com`, `creator.douyin.com`

| 接口 | 方法 | 路径 | 说明 |
|------|------|------|------|
| 商品统计 | GET | `/product/tproduct/aggsProductCount` | 商品聚合计数 |
| 商品列表 | GET | `/product/tproduct/list` | 商品分页列表 |
| 订单统计 | GET | `/api/order/tabcnt` | 订单状态汇总 |
| 订单列表 | GET | `/api/order/searchlist` | 订单明细 |
| 创作者概览 | POST | `/janus/douyin/creator/data/overview/dashboard` | 创作者仪表盘 |
| 创作者作品 | GET/POST | `/janus/douyin/creator/pc/work_list` | 作品列表 |

---

## 外部 API 详细

### 1. 订单列表 `/api/order/searchlist`

**完整 URL 示例**：
```
https://fxg.jinritemai.com/api/order/searchlist?
  page=0&
  pageSize=10&
  compact_time[select]=create_time_start,create_time_end&
  order_by=create_time&
  order=desc&
  tab=all&
  appid=1&
  __token=YOUR_TOKEN&
  _bid=ffa_order&
  aid=4272&
  _lid=104476165896&
  msToken=YOUR_MS_TOKEN&
  a_bogus=YOUR_ABOGUS&
  verifyFp=YOUR_VERIFYFP&
  fp=YOUR_FP
```

**查询参数**：
| 参数 | 必填 | 类型 | 说明 |
|------|------|------|------|
| page | 是 | integer | 页码（从 0 开始） |
| pageSize | 是 | integer | 每页记录数 |
| compact_time[select] | 是 | string | 时间范围选择，如 `create_time_start,create_time_end` |
| order_by | 否 | string | 排序字段，默认 `create_time` |
| order | 否 | string | `asc`/`desc`，默认 `desc` |
| tab | 否 | string | 订单标签，如 `all` |
| appid | 否 | integer | 应用 ID，如 `1` |
| __token | 是 | string | 通讯凭证 token |
| _bid | 是 | string | 业务标识，固定 `ffa_order` |
| aid | 是 | integer | 业务 ID（店铺 ID） |
| _lid | 是 | integer | 业务日志 ID |
| msToken | 是 | string | 防刷令牌，需定时获取 |
| a_bogus | 是 | string | 防爬签名，需实时生成 |
| verifyFp | 是 | string | 指纹 Token |
| fp | 是 | string | 指纹 |

**请求头**：
| Header | 必填 | 说明 |
|--------|------|------|
| Accept | 是 | `application/json, text/plain, */*` |
| User-Agent | 是 | 浏览器 UA，统一使用 `Config.USER_AGENT` |
| Cookie | 是 | 完整 `fxg.jinritemai.com` 域名 Cookie |

**Cookie 示例**（需实时获取完整 Cookie）：
```
passport_csrf_token=...; passport_csrf_token_default=...; s_v_web_id=...; 
__security_mc_1_s_sdk_crypt_sdk=...; bd_ticket_guard_client_data=...; 
bd_ticket_guard_client_web_domain=2; uid_tt=...; sid_tt=...; 
sessionid=...; PHPSESSID=...; ecom_us_lt=...; ucas_c0=...; ttwid=...; ...
```

**响应示例**：
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "total": 123,
    "list": [
      {
        "order_id": "1234567890",
        "create_time": "2026-10-11 04:43:05",
        "status": "PAID",
        "amount": 1999,
        "buyer": {"uid": "111222333", "nickname": "用户A"}
      }
    ]
  }
}
```

### 2. 订单统计 `/api/order/tabcnt`

**参数**：`tabcnt_version=v1`, `tab=all|pay|cancel`, `appid`, `__token`, `_bid=ffa_order`, `aid`, `_lid`, `msToken`, `verifyFp`, `fp`, `a_bogus`

**请求头 & Cookie**：同订单列表

**响应示例**：
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "total": 123,
    "tabs": {
      "all": {"order_count": 100, "amount": 50000},
      "pay": {"order_count": 80, "amount": 40000}
    }
  }
}
```

### 3. 商品统计 `/product/tproduct/aggsProductCount`

**参数**：`appid`, `__token`, `_bid=ffa_product`, `aid`, `_lid`, `msToken`, `a_bogus`, `verifyFp`, `fp`

**请求头 & Cookie**：同订单列表（域名 `fxg.jinritemai.com`）

**响应示例**：
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "total_products": 57,
    "sales_today": 1200,
    "sales_yesterday": 1150,
    "inventory_total": 3400,
    "conversion_rate": 0.1243
  }
}
```

### 4. 商品列表 `/product/tproduct/list`

**参数**：`page`(从1开始), `pageSize`, `keyword`, 同商品统计的通用参数

**响应示例**：
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "products": [
      {
        "product_id": "p123",
        "product_name": "商品A",
        "sales_today": 120,
        "inventory": 30,
        "conversion_rate": 0.12
      }
    ],
    "total": 57,
    "page": 1,
    "size": 20
  }
}
```

### 5. 创作者概览 `/janus/douyin/creator/data/overview/dashboard`

**方法**：POST

**请求体**：
```json
{ "recent_days": 7 }
```

**请求头**：
| Header | 必填 | 说明 |
|--------|------|------|
| Accept | 是 | `application/json, text/plain, */*` |
| Content-Type | 是 | `application/json` |
| User-Agent | 是 | 统一使用 `Config.USER_AGENT` |
| Cookie | 是 | 完整 `creator.douyin.com` 域名 Cookie |

**响应示例**：
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "total_followers": 5000,
    "total_videos": 120,
    "recent_view": 3400,
    "recent_like": 800
  }
}
```

### 6. 创作者作品 `/janus/douyin/creator/pc/work_list`

**参数**：`cursor`, `count`, `creator_id`, `__token`, `msToken`, `a_bogus`, `verifyFp`, `fp`

**请求头 & Cookie**：同创作者概览

**响应示例**：
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "list": [
      {
        "work_id": "xxx",
        "title": "视频标题",
        "cover_url": "https://...",
        "play_count": 1000,
        "like_count": 100,
        "creator_name": "创作者名"
      }
    ]
  }
}
```

---

## 通用错误码 (外部 API)

| `code` | 含义 |
|--------|------|
| `0` | 成功 |
| `40001` | 参数错误/签名无效 |
| `40101` | 未登录/Token 失效 |
| `40301` | 防爬签名异常 (`a_bogus`/`msToken` 无效) |
| `429` | 请求频率过高/限流 |
| `500` | 服务端内部错误 |

---

## 认证与请求头

### 内部 API 认证（Flask + axios）

**后端鉴权中间件**（`app.py:check_auth`）：
- **Header 校验**：同时检查 `Authorization: Bearer <API_KEY>` 和 `X-API-Key: <API_KEY>`
- **通过条件**：任一 Header 校验通过即可（建议前后端双发）
- **白名单端点**（`PUBLIC_ENDPOINTS`）：
  - `/api/v1/health` - 健康检查
  - `/api/v1/auth/login` - OAuth 登录入口
  - `/api/v1/auth/callback` - OAuth 回调
  - `/api/v1/auth/qr-code` - 获取登录二维码
  - `/api/v1/auth/status` - 授权状态查询
- **API_KEY 来源**：`Config.API_KEY`（优先读取 Docker secret `api_key`，回退环境变量 `API_KEY`）
- **默认值**：`wlkj_douyin_api_20260921_abc123`
- **SKIP_AUTH 开关**：`SKIP_AUTH=true` 环境变量可完全跳过鉴权（调试用）

**前端 axios 封装**（`src/frontend/src/utils/apiClient.ts`）：
```typescript
// 同时发送双 Header
instance.defaults.headers.common['X-API-Key'] = token
instance.defaults.headers.common['Authorization'] = `Bearer ${token}`

// Token 来源优先级：VITE_API_KEY > localStorage.authToken
```
- 401 响应时自动清空 token，由调用方决定是否跳转登录
- 非 401 错误自动弹出 `message.error` 提示

### 外部 API 认证（抖店/创作者中心）

**统一请求转发器**（`services.fetcher._request`）：

| 项目 | 抖店 (`fxg.jinritemai.com`) | 创作者中心 (`creator.douyin.com`) |
|------|---------------------------|-------------------------------|
| **Base URL** | `Config.FXG_BASE_URL` | `Config.CREATOR_BASE_URL` |
| **Cookie** | `FXG_COOKIES` (完整域名 Cookie 字符串) | `CREATOR_COOKIES` (完整域名 Cookie 字符串) |
| **动态签名** | `a_bogus`, `msToken`, `verifyFp`, `fp`, `__TOKEN` | 同上 |
| **固定参数** | `_bid=ffa_product`, `aid=FXG_SHOP_ID`, `_lid=FXG_PRODUCT_LID` | `aid=CREATOR_WORK_AID` |
| **User-Agent** | `Config.USER_AGENT` (Chrome 150) | 同上 |
| **签名实现** | `douyin_sign.sign_request` (V8 实时计算 `a_bogus`) | 同上 |

**Cookie 传递差异**（关键点）：
- **抖店接口**：通过 `headers['Cookie']` 传递字符串
- **创作者中心作品列表** (`/janus/douyin/creator/pc/work_list`)：**必须**使用 `cookies` 参数传递字典（`requests` 库的 `cookies=`），而非 `Cookie` Header

**错误码分类与指引**（`_classify_external_error` + `_get_auth_error_guidance`）：
| 类别 | 包含码 | 处理指引 |
|------|--------|----------|
| `COOKIE_EXPIRED` | `40101`, `10008` | 重新登录抓取完整 Cookie 更新 `.env` |
| `SIGNATURE_ERROR` | `40301` | 重新抓取 `a_bogus`/`msToken`/`verifyFp`/`fp`/`__token` |
| `RATE_LIMITED` | `429` | 降低频率、增加间隔、稍后重试 |
| `RISK_CONTROL` | `10001010A` | 检查账号状态，降低请求频率 |
| `HTTP_ERROR` | 非 2xx 状态码 | 检查网络/目标服务状态 |
| `TIMEOUT` | 请求超时 | 检查网络或增加超时 |
| `CONNECTION_ERROR` | 连接失败 | 检查域名可达性 |
| `EXCEPTION` | 其他异常 | 查看详细日志 |

---

## 环境变量配置（基于 `config/settings.py` Settings 类）

后端配置优先级：**Docker Secret (`/run/secrets/...`) > 环境变量 > `.env` > 默认值**。

```env
# =========================================================================
# 基础配置
# =========================================================================
DATA_DIR=./data                    # 数据存储目录（容器内映射为 /data）
SCHEDULE_INTERVAL_MINUTES=60       # 定时任务间隔（分钟）
ALERT_EMAIL=                       # 告警通知邮箱
API_AUTH_TOKEN=                    # API 认证 Token（内部服务间调用，可选）
API_KEY=wlkj_douyin_api_20260921_abc123  # API 密钥（前后端统一，也可通过 secret `api_key` 注入）
KEEP_ALIVE_TIMEOUT=30              # Keep-alive 超时（秒）
TIMEOUT=30                         # 请求超时（秒）
EXTERNAL_DATA_BASE_URL=            # 外部数据服务基础 URL（预留扩展）

# =========================================================================
# 抖音开放平台 OAuth 2.0（如需）
# =========================================================================
DOUYIN_APP_ID=                     # 抖音开放平台 App ID
DOUYIN_APP_SECRET=                 # 抖音开放平台 App Secret
DOUYIN_ACCESS_TOKEN=               # 抖音访问令牌

# =========================================================================
# 双域名基础 URL
# =========================================================================
FXG_BASE_URL=https://fxg.jinritemai.com
CREATOR_BASE_URL=https://creator.douyin.com

# =========================================================================
# 公共请求头
# =========================================================================
USER_AGENT=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36

# =========================================================================
# 认证与签名参数（强时效性，需定期手动更新，通常 2h-7 天失效）
# 获取方式：浏览器登录目标网站 -> F12 Network -> 任意请求 -> Request Headers
# =========================================================================
# 抖店签名参数
TOKEN=                             # 抖店 __TOKEN 参数
MS_TOKEN=                          # 抖店 MS_TOKEN 参数
A_BOGUS=                           # 抖店 a_bogus 参数
VERIFY_FP=                         # 抖店 verifyFp 参数
FP=                                # 抖店 fp 参数

# =========================================================================
# Cookie 配置（完整 Cookie 字符串，分号分隔）
# 获取方法：浏览器登录 -> F12 -> Network -> 任意请求 -> Request Headers -> Cookie
# =========================================================================
FXG_COOKIES=                       # 抖店 Cookie (fxg.jinritemai.com)
CREATOR_COOKIES=                   # 创作者中心 Cookie (creator.douyin.com)

# =========================================================================
# 抖店 Shop ID 与 Log ID（多店铺场景需配置）
# =========================================================================
FXG_SHOP_ID=4272                   # 抖店 Shop ID
FXG_LOG_ID=104476165896            # 抖店 Log ID
FXG_PRODUCT_LID=829906029528       # 抖店商品列表 _lid
FXG_ORDER_LID=646601599070         # 抖店订单列表 _lid
FXG_ORDER_AID=4272                 # 抖店订单列表 aid
CREATOR_WORK_AID=1128              # 创作者作品列表 aid

# =========================================================================
# Celery / Redis 配置
# =========================================================================
CELERY_BROKER_URL=redis://redis:6379/0
CELERY_RESULT_BACKEND=redis://redis:6379/0

# =========================================================================
# 创作者中心内容管理 API
# =========================================================================
CREATOR_WORK_LIST_URL=https://creator.douyin.com/janus/douyin/creator/pc/work_list

# =========================================================================
# 告警配置
# =========================================================================
ALERT_WECOM_WEBHOOK=               # 企业微信告警 Webhook
ALERT_DINGTALK_WEBHOOK=            # 钉钉告警 Webhook
ALERT_SMTP_HOST=                   # SMTP 服务器地址
ALERT_SMTP_PORT=587                # SMTP 端口
ALERT_SMTP_USER=                   # SMTP 用户名
ALERT_SMTP_PASSWORD=               # SMTP 密码
ALERT_SMTP_FROM=                   # SMTP 发件人邮箱

# =========================================================================
# 日志配置
# =========================================================================
LOG_LEVEL=INFO
LOG_FILE=logs/app.log
LOG_MAX_BYTES=10485760             # 10MB
LOG_BACKUP_COUNT=5

# =========================================================================
# 监控配置
# =========================================================================
ENABLE_METRICS=true
METRICS_PORT=9090

# =========================================================================
# Docker Secrets 对应关系（用于生产环境）
# =========================================================================
# /run/secrets/api_key              -> API_KEY
# /run/secrets/douyin_app_id        -> DOUYIN_APP_ID
# /run/secrets/douyin_app_secret    -> DOUYIN_APP_SECRET
# /run/secrets/douyin_access_token  -> DOUYIN_ACCESS_TOKEN
# /run/secrets/fxg_cookies          -> FXG_COOKIES
# /run/secrets/creator_cookies      -> CREATOR_COOKIES
# /run/secrets/token                -> TOKEN (__TOKEN)
# /run/secrets/ms_token             -> MS_TOKEN
# /run/secrets/a_bogus              -> A_BOGUS
# /run/secrets/verify_fp            -> VERIFY_FP
# /run/secrets/fp                   -> FP
# /run/secrets/fxg_shop_id          -> FXG_SHOP_ID
# /run/secrets/fxg_log_id           -> FXG_LOG_ID
```

**前端环境变量**（`.env` 或 `.env.production`）：
```env
VITE_API_KEY=wlkj_douyin_api_20260921_abc123  # 必须与后端 API_KEY 一致
VITE_API_BASE_URL=http://localhost:5000       # 开发环境后端地址
```

---

## 签名机制

所有转发至抖店/创作者中心的请求，后端 `services.fetcher._request` 自动完成（仅对 `fxg.jinritemai.com` 域名）：

1. **读取长效参数**：从 `Config` 读取 `TOKEN`、`MS_TOKEN`、`A_BOGUS`、`VERIFY_FP`、`FP`（优先 Docker Secret，回退环境变量）
2. **动态生成 `a_bogus`**：调用 `douyin_sign.sign_request(endpoint, params, existing_tokens, USER_AGENT)`，使用 `py_mini_racer` (V8) 实时计算
3. **合并参数**：将签名参数合并到请求 `params` 中
4. **注入 Cookie**：抖店用 `headers['Cookie']`，创作者中心作品列表用 `cookies=` 字典参数
5. **统一请求头**：`User-Agent` 使用 `Config.USER_AGENT`，`Accept: application/json, text/plain, */*`

**签名实现细节**（`douyin_sign.py`）：
- 加载本地 JS 签名算法文件（通常为混淆后的字节码）
- 通过 V8 运行时执行签名函数，输入：URL、参数、现有 Token、User-Agent
- 输出：更新后的 `a_bogus`、`msToken` 等动态参数
- 失败时记录警告并继续发送无签名请求（由外部 API 返回错误码触发重试/告警）

**动态参数获取来源**：
| 参数 | 获取方式 | 更新频率 |
|------|----------|----------|
| `a_bogus` | V8 实时计算 (`douyin_sign`) | 每次请求 |
| `msToken` | 浏览器页面 `window.__INIT_DATA__` 或 Cookie | 定期手动更新 |
| `verifyFp` / `fp` | 页面加载时的指纹参数 | 定期手动更新 |
| `__TOKEN` | 登录后 Cookie `passport_csrf_token` 或请求头 | 定期手动更新 |
| Cookie | 浏览器插件/开发者工具导出完整域名 Cookie | 定期手动更新（通常 2h-7 天失效） |

**生产环境建议**：
- 使用 Docker Secrets 管理所有敏感参数（`/run/secrets/...`）
- 配置监控告警：外部 API 返回 `COOKIE_EXPIRED`/`SIGNATURE_ERROR` 时自动通知
- 定期轮换 Cookie 和长效 Token（建议每日或每半日）

---

## 变更记录

- **2026-10-07 v2.0.1**：根据实际代码完善「认证与请求头」「环境变量配置」「签名机制」三节，补充：
  - 内部 API 双 Header 鉴权细节、白名单端点、SKIP_AUTH 开关、前端 axios 拦截器行为
  - 外部 API 双域名认证差异、Cookie 传递方式差异、错误码分类与修复指引表
  - 环境变量完整清单（基于 `config/settings.py` Settings 类，含 Docker Secrets 映射）
  - 签名机制实现细节（V8 实时计算 `a_bogus`、参数来源表、生产环境建议）
- **2026-10-07 v2.0.0**：合并 INTERNAL-API-SPEC.md、EXTERNAL-API-SPEC.md、API_DOC.md 为统一规范文档
- **2026-09-26 v1.2.1**：修正同步 API：`POST /api/v1/sync` 支持 `?async=true` 异步模式（Celery 任务队列）；新增通用/抖店/抖音告警配置端点；明确健康检查端点无需认证（`PUBLIC_ENDPOINTS` 白名单）
- **2026-09-23 v1.2.0**：内部 API 前缀统一为 `/api/v1`；`GET /api/v1/creators/overview` 替代原 `POST /creators/overview/dashboard`；所有相对路径不带前导 `/`，配合 `baseURL: '/api/v1'`；前端鉴权头同时发送 `Authorization: Bearer` + `X-API-Key`

---

*历史归档文档已移除，完整变更记录请查阅 `CHANGELOG.md`*