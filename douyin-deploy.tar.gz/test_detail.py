import sys
sys.path.insert(0, '/opt/douyin-platform/src/backend')

from config import Config
from services.fetcher import _request, _read_secret, parse_cookies

creator_cookie_str = _read_secret('creator_cookies', 'CREATOR_COOKIES')
creator_cookies = parse_cookies(creator_cookie_str)

creator_headers = {
    'User-Agent': Config.USER_AGENT,
    'Referer': 'https://creator.douyin.com/',
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': 'application/json',
}

# Test 5: 创作者概览 - 详细返回
print("=" * 70)
print("5. 创作者概览 - POST /janus/douyin/creator/data/overview/dashboard (详细响应)")
print("=" * 70)
endpoint = f"{Config.CREATOR_BASE_URL}/janus/douyin/creator/data/overview/dashboard"
payload = {"recent_days": 7}
result = _request(endpoint, headers=creator_headers, method='POST', json=payload, cookies=creator_cookies)
print(f"Raw result type: {type(result)}")
print(f"Raw result: {result}")

# Test 6: 创作者作品 - 详细返回
print("\n" + "=" * 70)
print("6. 创作者作品 - GET /janus/douyin/creator/pc/work_list (详细响应)")
print("=" * 70)
endpoint = Config.CREATOR_WORK_LIST_URL
params = {
    'status': '0', 'count': '12', 'max_cursor': '0',
    'scene': 'star_atlas', 'device_platform': 'android', 'aid': Config.CREATOR_WORK_AID,
}
creator_headers_work = creator_headers.copy()
creator_headers_work['Referer'] = 'https://creator.douyin.com/creator-micro/content/manage'
result = _request(endpoint, params=params, headers=creator_headers_work, cookies=creator_cookies, method='GET')
print(f"Raw result type: {type(result)}")
print(f"Raw result: {result}")

# Also test with fxg cookies for order list
print("\n" + "=" * 70)
print("4. 订单列表 - GET /api/order/searchlist (详细响应)")
print("=" * 70)
fxg_cookie_str = _read_secret('fxg_cookies', 'FXG_COOKIES')
fxg_cookies = parse_cookies(fxg_cookie_str)
fxg_headers_order = {
    'User-Agent': Config.USER_AGENT,
    'Referer': 'https://fxg.jinritemai.com/order/order/list',
    'Origin': 'https://fxg.jinritemai.com',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
}
endpoint = f"{Config.FXG_BASE_URL}/api/order/searchlist"
from datetime import datetime, timedelta
now = datetime.now()
start_time = int((now - timedelta(days=30)).timestamp())
end_time = int(now.timestamp())
params = {
    'page': 0, 'pageSize': 20, 'order_by': 'create_time', 'order': 'desc',
    'tab': 'all', 'appid': 1, '_bid': 'ffa_order',
    'aid': Config.FXG_ORDER_AID, '_lid': Config.FXG_ORDER_LID,
    'compact_time[select]': 'create_time_start,create_time_end',
    'create_time_start': start_time, 'create_time_end': end_time,
}
result = _request(endpoint, params=params, headers=fxg_headers_order, cookies=fxg_cookies)
print(f"Raw result type: {type(result)}")
print(f"Raw result: {result}")