---
title: 运维手册
version: 1.2.0
status: Published
last_updated: 2026-10-07
owner: DevOps Lead
reviewers: ['运维工程师', 'Tech Lead']
approvers: ['DevOps Lead']
classification: Confidential
doc_id: DOC-OPS-001
tags: ['运维', '手册']
related_docs: []
changelog: |
  v1.2.0 (2026-10-07): 新增 Nginx DNS 缓存导致 502 故障排查与修复方案，更新 fetcher.py Cookie 传递方式修复记录 - DevOps Lead
  v1.1.0 (2026-10-05): 更新服务拓扑为统一 Docker Compose 编排，单一网络 douyin-platform_douyin-network，移除 systemd Nginx，更新健康检查地址 - DevOps Lead
  v1.0.0 (2026-09-26): 初版创建 - DevOps Lead
---
# 运维操作手册

> **版本**: 1.2.0
> **更新日期**: 2026-10-07
> **适用环境**: 生产 / Staging
> **受众**: 运维工程师、SRE、Tech Lead

---

## 1. 服务拓扑与端口

| 服务 | 容器名 | 内部端口 | 外部端口 | 网络 | 依赖 |
|------|--------|---------|---------|------|------|
| Frontend (Nginx) | douyin_frontend | 80 | 3000 | douyin-platform_douyin-network | Backend (douyin_monitor:5000) |
| Backend API (Flask) | douyin_monitor | 5000 | 5000 | douyin-platform_douyin-network | Redis, Celery |
| Celery Worker (sync) | douyin_celery_worker | - | - | douyin-platform_douyin-network | Redis, Backend |
| Celery Worker (report) | douyin_celery_worker_report | - | - | douyin-platform_douyin-network | Redis, Backend |
| Celery Beat | douyin_celery_beat | - | - | douyin-platform_douyin-network | Redis |
| Redis | douyin_redis | 6379 | 6379 | douyin-platform_douyin-network | - |

> **关键变更**: 统一使用根目录 `docker-compose.yml` 编排，所有服务共享单一网络 `douyin-platform_douyin-network`。Frontend 容器内 Nginx 代理到 `http://douyin_monitor:5000`。无 systemd Nginx，无域名，直接 IP + 端口访问。

---

## 2. 常用操作命令速查

```bash
# ==================== 服务状态 ====================
# 进入项目根目录
cd /opt/douyin-platform

# 查看所有容器状态
docker compose ps

# 查看容器详细信息
docker compose ps -a

# ==================== 日志查看 ====================
# Backend (Flask) 应用日志
docker compose logs -f monitor --tail 200

# Celery Worker (sync) 日志
docker compose logs -f celery_worker --tail 200

# Celery Worker (report) 日志
docker compose logs -f celery_worker_report --tail 200

# Celery Beat 日志
docker compose logs -f celery_beat --tail 200

# Redis 日志
docker compose logs -f redis --tail 200

# Frontend (Nginx) 日志
docker compose logs -f frontend --tail 200

# ==================== 健康检查 ====================
# 前端健康检查
curl -s http://122.51.208.138:3000/health | jq .

# API 健康检查 (外部访问)
curl -s http://122.51.208.138:5000/api/v1/health | jq .

# 后端直连健康检查 (容器内/服务器本地)
curl -s http://127.0.0.1:5000/api/v1/health | jq .

# Celery Worker 状态
docker compose exec monitor celery -A tasks inspect active

# Celery Beat 定时任务
docker compose exec monitor celery -A tasks inspect scheduled

# Redis 连通性
docker compose exec redis redis-cli ping

# ==================== 服务控制 ====================
# 重启全栈
docker compose restart

# 仅重启 Backend
docker compose restart monitor

# 仅重启 Celery Worker (sync)
docker compose restart celery_worker

# 仅重启 Celery Worker (report)
docker compose restart celery_worker_report

# 仅重启 Celery Beat
docker compose restart celery_beat

# 仅重启 Frontend
docker compose restart frontend

# 优雅停止单服务 (30s 超时)
docker compose stop -t 30 monitor

# 查看网络
docker network inspect douyin-platform_douyin-network

# ==================== 数据同步触发 ====================
# 手动触发全量同步 (需 API Key)
curl -X POST http://122.51.208.138:5000/api/v1/sync -H "X-API-Key: <your_api_key>"

# 查看同步状态
curl -s http://122.51.208.138:5000/api/v1/health | jq .data.last_update
```

---

## 3. 扩容操作

### 3.1 水平扩容 Celery Worker
```bash
# 临时扩容 (当前会话生效)
docker compose up -d --scale celery_worker=3

# 永久扩容 (修改 docker-compose.yml 的 deploy.replicas)
# 然后重新部署
docker compose up -d --no-deps celery_worker
```

**验证**：
```bash
# 查看 worker 数量
docker compose exec monitor celery -A tasks inspect active | jq 'keys | length'

# 查看队列积压
docker compose exec redis redis-cli LLEN celery
```

### 3.2 Backend 多实例扩容
```bash
# 临时扩容到 3 个实例
docker compose up -d --scale monitor=3 --no-deps monitor
```
> 注意: 扩容后需确保 Frontend Nginx upstream 配置支持多实例负载均衡，当前单实例模式下 Frontend 直接代理到 `douyin_monitor:5000`。

---

## 4. 备份与恢复

### 4.1 备份内容清单
| 数据类型 | 位置 | 备份频率 | 保留策略 |
|---------|------|---------|---------|
| 业务数据 (JSON) | `/opt/douyin-platform/apps/monitor/data/` | 每日 02:00 | 30 天 |
| Redis 数据 | `redis` 容器卷 | 每日 03:00 | 7 天 |
| 配置文件 | `.env`, `docker-compose.yml`, `docker-compose.prod.yml` | 变更时 | 永久 |
| Secrets | `/opt/douyin-platform/secrets/` | 变更时 | 永久 (加密存储) |
| 应用日志 | 容器日志 (`docker compose logs`) | 每周 | 90 天 |

### 4.2 备份脚本示例
```bash
#!/bin/bash
# backup.sh - 每日 02:00 cron 执行
set -euo pipefail

BACKUP_DIR="/backup/douyin_monitor/$(date +%Y%m%d)"
mkdir -p "$BACKUP_DIR"

# 1. 业务数据
tar -czf "$BACKUP_DIR/data.tar.gz" -C /opt/douyin-platform/apps/monitor data/

# 2. Redis RDB
docker compose exec -T redis redis-cli BGSAVE
sleep 5
docker cp douyin_redis:/data/dump.rdb "$BACKUP_DIR/redis.rdb"

# 3. 配置文件
tar -czf "$BACKUP_DIR/config.tar.gz" \
  /opt/douyin-platform/.env \
  /opt/douyin-platform/docker-compose.yml \
  /opt/douyin-platform/docker-compose.prod.yml \
  /opt/douyin-platform/secrets/

# 4. 清理 30 天前备份
find /backup/douyin_monitor -type d -mtime +30 -exec rm -rf {} \;

echo "Backup completed: $BACKUP_DIR"
```

### 4.3 恢复演练 (每季度必做)
```bash
# 1. 停止服务
cd /opt/douyin-platform
docker compose down

# 2. 恢复数据
tar -xzf /backup/douyin_monitor/20260818/data.tar.gz -C /opt/douyin-platform/apps/monitor/
docker cp /backup/douyin_monitor/20260818/redis.rdb douyin_redis:/data/dump.rdb

# 3. 启动 Redis 并验证
docker compose up -d redis
docker compose exec redis redis-cli ping

# 4. 启动应用
docker compose up -d

# 5. 验证
curl -s http://122.51.208.138:5000/api/v1/health | jq .
```

---

## 5. 证书轮换 (当前不适用)

> **注意**: 当前架构无 HTTPS/域名，直接 IP + 端口访问。如后续接入域名和 Nginx/云 LB，需配置 Let's Encrypt 自动续期。

---

## 6. 故障排查决策树

### 6.1 症状：前端页面白屏 / 静态资源 404
```
START
  │
  ├─► 检查 Frontend 容器日志 → docker compose logs frontend
  │       有错? → 修复 nginx.conf → docker compose restart frontend
  │
  ├─► 检查构建产物是否存在 → docker compose exec frontend ls /usr/share/nginx/html/assets/
  │       否 → 重新构建前端镜像 → docker compose build frontend → docker compose up -d frontend
  │
  ├─► 检查 Nginx try_files 配置 → location / { try_files $uri $uri/ /index.html; }
  │
  └─► 浏览器 Network 面板 → 看具体资源请求 URL 是否正确
```

### 6.2 症状：API 返回 502/504 / `ERR_CONNECTION_REFUSED`
```
START
  │
  ├─► 检查 Backend 容器状态 → docker compose ps monitor
  │       停止/异常? → docker compose logs monitor → 修复 → docker compose restart monitor
  │
  ├─► 检查 Frontend 到 Backend 连通性
  │       docker compose exec frontend wget -qO- http://douyin_monitor:5000/api/v1/health
  │       失败? → 检查网络 docker network inspect douyin-platform_douyin-network
  │
  ├─► 检查 Nginx DNS 缓存问题 (新增)
  │       docker compose exec frontend curl -s http://localhost:80/api/v1/health
  │       返回 502? → 执行 nginx -s reload 或检查 resolver 配置
  │
  ├─► 检查防火墙/安全组 → 5000/3000 端口是否放行
  │
  └─► 检查 Backend 健康检查 → curl http://127.0.0.1:5000/api/v1/health
```

### 6.3 症状：数据同步失败 / 定时任务不执行
```
START
  │
  ├─► 检查 Celery Beat 状态 → docker compose logs celery_beat
  │       无日志/异常? → 重启 beat → docker compose restart celery_beat
  │
  ├─► 检查 Celery Worker 状态 → docker compose exec monitor celery -A tasks inspect active
  │       无 worker? → 扩容 worker / 重启 worker
  │
  ├─► 检查 Redis 连通性 → docker compose exec redis redis-cli ping
  │
  ├─► 检查任务是否入队 → docker compose exec redis redis-cli LLEN celery
  │
  ├─► 检查任务执行日志 → docker compose logs celery_worker
  │       报错? → 看具体异常 (外部 API 限流/签名失效/网络超时)
  │
  ├─► 检查外部 API Cookie/签名参数 (新增)
  │       docker compose logs monitor | grep -i "cookie\|signature\|sign"
  │       报错? → 更新 .env 中的 fxg_cookies, creator_cookies, __TOKEN, MS_TOKEN, a_bogus 等
  │
  └─► 手动触发同步验证 → curl -X POST /api/v1/sync -H "X-API-Key: <key>"
```

### 6.4 症状：外部 API 返回 403/429 / 签名失效
```
START
  │
  ├─► 检查 Secrets/Cookie 是否过期 → 更新 fxg_cookies, creator_cookies 等
  │       docker compose restart monitor celery_worker celery_beat
  │
  ├─► 检查动态签名参数 → __TOKEN, MS_TOKEN, a_bogus, verifyFp, fp 是否有效
  │
  ├─► 检查 User-Agent 是否被拦截 → 更新为最新 Chrome UA (fetcher.py)
  │
  ├─► 检查请求频率 → 是否触发限流 (429) → 降低 Celery 并发/增加延迟
  │
  ├─► 检查 Cookie 传递方式 (新增)
  │       部分 API 需直接 cookie 参数而非 Cookie Header
  │       修改 fetcher.py 对应 fetch 函数使用 cookies=parse_cookies(cookie_str)
  │
  └─► 联系上游确认接口变更 → 更新 douyin_sign.py 签名逻辑
```

### 6.5 症状：磁盘空间不足 / 容器重启频繁
```
START
  │
  ├─► df -h → 看哪个分区满了
  │
  ├─► docker system df → 镜像/容器/卷占用
  │       清理: docker system prune -a --volumes
  │
  ├─► 容器日志过大 → docker compose logs --tail=0 (查看大小)
  │       配置 log driver max-size=10m max-file=3
  │
  ├─► Redis 内存 → docker compose exec redis redis-cli INFO memory
  │       设置 maxmemory-policy allkeys-lru
  │
  └─► 业务数据 JSON 过大 → 归档历史数据 / 迁移至数据库
```

---

## 7. 监控与告警规则

### 7.1 关键指标 (当前手动监控，Prometheus 规划中)
| 指标 | 告警阈值 | 严重级别 | 通知渠道 |
|------|---------|---------|---------|
| API 健康检查失败 | 连续 3 次失败 | P0 (Critical) | 电话 + 企业微信 |
| API 延迟 P99 > 500ms | 持续 5 分钟 | P1 (High) | 企业微信 |
| Celery 队列积压 > 1000 | 持续 10 分钟 | P1 | 企业微信 |
| Celery Worker 数 < 期望数 | 立即 | P0 | 电话 |
| Redis 内存 > 80% maxmemory | 持续 15 分钟 | P2 (Warning) | 企业微信 |
| 磁盘使用率 > 85% | 立即 | P1 | 企业微信 |
| 同步最后更新 > 2 小时 | 立即 | P1 | 企业微信 |
| 外部 API 错误率 > 5% | 持续 5 分钟 | P1 | 企业微信 |

### 7.2 日志聚合查询 (当前使用 docker logs)
```bash
# 查看最近错误日志
docker compose logs monitor | grep -i "error\|exception\|traceback\|failed"

# 查看同步任务耗时
docker compose logs monitor | grep "sync.*completed"

# 查看外部 API 错误
docker compose logs monitor | grep -E "403|429|500"
```

---

## 8. 版本发布与回滚

### 8.1 发布流程 (滚动更新)
```bash
# 1. 进入项目目录
cd /opt/douyin-platform

# 2. 拉取新镜像 (生产环境使用 docker-compose.prod.yml)
docker compose -f docker-compose.yml -f docker-compose.prod.yml pull

# 3. 滚动部署 Backend
docker compose up -d --no-deps --scale monitor=3 monitor
# 等待健康检查通过
sleep 10

# 4. 部署 Celery Workers
docker compose up -d --no-deps celery_worker celery_beat celery_worker_report

# 5. 部署 Frontend (无需重新构建，运行时注入 API_BASE_URL)
docker compose up -d --no-deps frontend

# 6. 部署后验证
curl -s http://122.51.208.138:5000/api/v1/health | jq .
curl -s http://122.51.208.138:3000/health | jq .
```

### 8.2 回滚流程
```bash
# 1. 查看历史镜像
docker images | grep douyin-platform

# 2. 回滚 Backend (指定镜像标签)
docker compose -f docker-compose.yml -f docker-compose.prod.yml pull monitor:v1.1.0
docker compose up -d --no-deps monitor

# 3. 同步回滚 Celery (同镜像)
docker compose up -d --no-deps celery_worker celery_beat celery_worker_report

# 4. 回滚 Frontend
docker compose up -d --no-deps frontend

# 5. 验证
curl -s http://122.51.208.138:5000/api/v1/health | jq .
```

### 8.3 数据兼容性检查
- 发布前运行 `scripts/check_env.py` 确保配置兼容
- 如有 Schema 变更，提供迁移脚本并在 Release Note 标记 `migration_required: true`

---

## 9. 安全事件响应

### 9.1 密钥泄露
```bash
# 1. 立即轮换泄露的密钥
#   - 更新 /opt/douyin-platform/secrets/ 对应文件
#   - 重启服务生效: docker compose restart monitor celery_worker celery_beat

# 2. 撤销泄露的 Token (如有上游管理控制台)

# 3. 审计日志确认是否被利用
docker compose logs monitor | grep "leaked_key"

# 4. 事后复盘记录到 Incident Report
```

### 9.2 疑似入侵
```bash
# 1. 隔离: 防火墙封禁可疑 IP
iptables -A INPUT -s <suspicious_ip> -j DROP

# 2. 保留现场: 复制日志、容器镜像
mkdir -p /evidence/$(date +%s)
docker compose logs > /evidence/$(date +%s)/logs.txt
docker commit douyin_monitor forensic_$(date +%s)

# 3. 通报安全团队, 走应急响应流程
```

---

## 10. 联系人与升级路径

| 角色 | 姓名 | 电话/企业微信 | 责任范围 |
|------|------|--------------|---------|
| **主责运维** | 张三 | 138-xxxx-xxxx / @zhangsan | 日常巡检、发布、故障一线处理 |
| **备份运维** | 李四 | 139-xxxx-xxxx / @lisi | 主责不可用时接管 |
| **Tech Lead** | 王五 | 137-xxxx-xxxx / @wangwu | 架构决策、疑难故障、发布把关 |
| **安全负责人** | 赵六 | 136-xxxx-xxxx / @zhaoliu | 安全事件、密钥管理、合规 |
| **业务负责人** | 钱七 | 135-xxxx-xxxx / @qianqi | 业务影响评估、沟通协调 |

### 升级路径
```
L1 (运维) 15 分钟未解决 → L2 (Tech Lead) 30 分钟未解决 → L3 (架构师/VP) 1 小时未解决 → 启动重大事故流程
```

---

## 11. 变更记录

| 版本 | 日期 | 变更内容 | 作者 |
|------|------|----------|------|
| 1.2.0 | 2026-10-07 | 新增 Nginx DNS 缓存导致 502 故障排查与修复方案，更新 fetcher.py Cookie 传递方式修复记录 | DevOps Lead |
| 1.1.0 | 2026-10-05 | 更新服务拓扑为统一 Docker Compose 编排，单一网络 douyin-platform_douyin-network，移除 systemd Nginx，更新健康检查地址为 IP + 端口 | DevOps Lead |
| 1.0.0 | 2026-08-18 | 初始版本：服务拓扑、常用命令、扩容、备份恢复、证书轮换、故障决策树、监控告警、发布回滚、安全响应 | Auto |

---

## 12. Nginx DNS 缓存问题修复记录 (2026-10-07 新增)

### 12.1 问题描述
后端容器 (`douyin_monitor`) 重启后，前端容器 (`douyin_frontend`) 内的 Nginx 仍缓存旧的后端 IP 地址，导致所有 API 请求返回 502 Bad Gateway。

### 12.2 根因分析
Nginx 默认在启动时解析上游服务域名并缓存 IP。当后端容器重启获得新 IP 时，Nginx 仍尝试连接旧 IP，导致连接失败。

### 12.3 修复方案
修改 `/etc/nginx/conf.d/default.conf` (前端容器内)：

```nginx
# 1. 添加 resolver 指令，使用 Docker 内部 DNS，每 10 秒刷新
resolver 127.0.0.11 valid=10s;

# 2. 使用变量强制动态解析
location /api/ {
    set $backend_host douyin_monitor;
    set $backend_port 5000;
    proxy_pass http://$backend_host:$backend_port;
    ...
}
```

### 12.4 验证步骤
```bash
# 1. 重启后端
docker compose restart monitor

# 2. 等待后端健康检查通过
sleep 10

# 3. 验证前端代理是否正常
docker compose exec frontend curl -s http://localhost:80/api/v1/health
# 应返回 {"success":true,"data":{"status":"healthy",...}}

# 4. 验证需认证的 API
docker compose exec frontend curl -s -H 'X-API-Key: wlkj_douyin_api_20260921_abc123' http://localhost:80/api/v1/dashboard/stats
```

### 12.5 预防措施
- 所有新部署必须包含此 nginx 配置
- 部署脚本中包含 `docker compose restart monitor && sleep 5 && docker exec douyin_frontend nginx -s reload` 步骤
- 监控告警增加检查：前端健康检查通过但 API 返回 502 时触发告警

---

> **使用提示**：
> 1. 本手册建议打印一份放在机房/运维工位，关键命令贴在显示器边
> 2. 每季度进行一次 **故障演练**，验证决策树有效性
> 3. 重大架构变更后 **必须同步更新** 本手册
> 4. 所有操作前先 **备份**、**快照**、**通知相关人员**