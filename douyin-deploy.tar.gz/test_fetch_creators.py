import sys
sys.path.insert(0, "/app")
from services.fetcher import fetch_and_store_creators, cache, CACHE_KEYS

# Test the actual fetch
result = fetch_and_store_creators()
print('Fetch result:', result)
print('Cache after fetch:', cache.get(CACHE_KEYS['creators']))