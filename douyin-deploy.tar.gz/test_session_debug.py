import os, requests, json

endpoint = "https://fxg.jinritemai.com/api/order/searchlist"
params = {
    "page": 0,
    "pageSize": 10,
    "order_by": "create_time",
    "order": "desc",
    "tab": "all",
    "appid": 1,
    "_bid": "ffa_order",
    "aid": 4272,
    "_lid": "606316310312",
    "__token": os.getenv("TOKEN"),
    "verifyFp": open("/run/secrets/verify_fp").read().strip(),
    "fp": open("/run/secrets/fp").read().strip(),
}

cookie_str = os.getenv('FXG_COOKIES', '')
cookies = {}
for pair in cookie_str.split(';'):
    if '=' in pair:
        k, v = pair.strip().split('=', 1)
        cookies[k] = v

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Referer": "https://fxg.jinritemai.com/ffa/order",
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-origin",
    "Sec-Ch-Ua": "Chromium;v=134, Not:A-Brand;v=24, Google Chrome;v=134",
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Ch-Ua-Platform": "Windows"
}

# Test 1: Direct requests.get
print("=== Test 1: Direct requests.get ===")
r1 = requests.get(endpoint, params=params, headers=headers, cookies=cookies, timeout=30)
print(f"Status: {r1.status_code}")
print(f"Length: {len(r1.text)}")
print(f"First 100: {r1.text[:100]}")
print(f"Content-Type: {r1.headers.get('Content-Type')}")

# Test 2: Session
print("\n=== Test 2: Session ===")
session = requests.Session()
session.headers.update(headers)
r2 = session.get(endpoint, params=params, cookies=cookies, timeout=30)
print(f"Status: {r2.status_code}")
print(f"Length: {len(r2.text)}")
print(f"First 100: {r2.text[:100]}")
print(f"Content-Type: {r2.headers.get('Content-Type')}")
session.close()

# Test 3: Session with cookies in session
print("\n=== Test 3: Session with cookies in session ===")
session3 = requests.Session()
session3.headers.update(headers)
session3.cookies.update(cookies)
r3 = session3.get(endpoint, params=params, timeout=30)
print(f"Status: {r3.status_code}")
print(f"Length: {len(r3.text)}")
print(f"First 100: {r3.text[:100]}")
session3.close()