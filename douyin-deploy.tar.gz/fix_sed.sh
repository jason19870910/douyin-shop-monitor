sed -i "s/'RISK_CONTROL': {'10001010A'}/'RISK_CONTROL': set()/" /opt/douyin-platform/src/backend/services/fetcher.py
sed -i "s/'SIGNATURE_ERROR': {40301, '40301'}/'SIGNATURE_ERROR': {40301, '40301', '10001010A'}/" /opt/douyin-platform/src/backend/services/fetcher.py
echo 'done'