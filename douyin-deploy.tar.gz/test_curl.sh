#!/bin/bash
docker exec douyin_monitor curl -s "https://fxg.jinritemai.com/api/order/searchlist?page=0&pageSize=10&order_by=create_time&order=desc&tab=all&appid=1&_bid=ffa_order&aid=4272&_lid=606316310312&__token=3b2d8e84e60678508ca0441155d6c3c2&verifyFp=verify_muxpd4sm_1bBReQID_lVHw_4zlq_9lf4_1tIMYEUgN2sA&fp=verify_muxpd4sm_1bBReQID_lVHw_4zlq_9lf4_1tIMYEUgN2sA" \
  -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" \
  -H "Referer: https://fxg.jinritemai.com/ffa/order" \
  -H "Accept: application/json, text/plain, */*" \
  -H "Accept-Language: zh-CN,zh;q=0.9" \
  -H "Sec-Fetch-Dest: empty" \
  -H "Sec-Fetch-Mode: cors" \
  -H "Sec-Fetch-Site: same-origin" \
  -H "Sec-Ch-Ua: Chromium;v=134, Not:A-Brand;v=24, Google Chrome;v=134" \
  -H "Sec-Ch-Ua-Mobile: ?0" \
  -H "Sec-Ch-Ua-Platform: Windows" \
  --cookie "$(docker exec douyin_monitor env | grep FXG_COOKIES | cut -d= -f2-)" | head -c 500