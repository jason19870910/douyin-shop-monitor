---
title: Git 工作流与开发规范
version: 2.0.0
status: Published
last_updated: 2026-10-07
owner: Tech Lead
reviewers: [资深工程师, 架构师, DevOps Lead, QA Lead]
approvers: [Tech Lead]
classification: Internal
doc_id: DOC-DEV-002
tags: [开发, Git, 工作流, 分支策略, CI/CD, 版本管理, Code Review, 提交规范]
related_docs: [DOC-DEV-001, DOC-QA-004, DOC-OPS-001]
changelog: |
  v2.0.0 (2026-10-07): 合并 BRANCH_STRATEGY.md、COMMIT_CONVENTION.md、CODE_REVIEW_GUIDE.md 为统一开发规范文档 - DevOps Lead
  v1.0.0 (2026-09-26): 初版创建 - Tech Lead
---

# Git 工作流与开发规范

> 本文档统一了分支策略、提交规范、Code Review 指南，作为团队日常开发的核心参考。

---

## 目录

1. [分支策略](#1-分支策略)
2. [工作流程](#2-工作流程)
3. [提交规范](#3-提交规范)
4. [PR 流程与 Code Review](#4-pr-流程与-code-review)
5. [版本发布规范](#5-版本发布规范)
6. [常用 Git 命令速查](#6-常用-git-命令速查)
7. [Git Hooks 与自动化](#7-git-hooks-与自动化)
8. [常见问题与最佳实践](#8-常见问题与最佳实践)

---

## 1. 分支策略

### 1.1 分支层级
```
                    ┌─────────────────────┐
                    │     main (保护)      │ ◄── 生产环境镜像，仅接受 PR 合并
                    └──────────┬──────────┘
                               │
              ┌────────────────┼────────────────┐
              ▼                ▼                ▼
       ┌─────────────┐  ┌─────────────┐  ┌─────────────┐
       │ release/v1.2│  │ release/v1.3│  │ release/v1.4│ ◄── 发布分支，仅修复发布相关 Bug
       └──────┬──────┘  └──────┬──────┘  └──────┬──────┘
              │                │                │
              └────────────────┼────────────────┘
                               ▼
                    ┌─────────────────────┐
                    │     develop (保护)   │ ◄── 集成分支，日常开发合并目标
                    └──────────┬──────────┘
                               │
              ┌────────────────┼────────────────┐
              ▼                ▼                ▼
       ┌─────────────┐  ┌─────────────┐  ┌─────────────┐
       │ feature/xxx │  │ bugfix/xxx  │  │ hotfix/xxx  │ ◄── 短生命周期工作分支
       └─────────────┘  └─────────────┘  └─────────────┘
```

### 1.2 分支命名规范
| 分支类型 | 命名模式 | 示例 | 生命周期 | 合并目标 |
|----------|----------|------|----------|----------|
| 主分支 | `main` | `main` | 永久 | - |
| 集成分支 | `develop` | `develop` | 永久 | `main` (发布时) |
| 发布分支 | `release/v{MAJOR}.{MINOR}` | `release/v1.2` | 发布周期 | `main`、`develop` |
| 功能分支 | `feature/{issue-id}-{short-desc}` | `feature/123-add-export-api` | 天~周 | `develop` |
| 缺陷分支 | `bugfix/{issue-id}-{short-desc}` | `bugfix/456-fix-export-null` | 天 | `develop` |
| 紧急修复 | `hotfix/{issue-id}-{short-desc}` | `hotfix/789-fix-payment-crash` | 小时~天 | `main`、`develop`、`release/*` |
| 实验分支 | `experiment/{desc}` | `experiment/new-cache-strategy` | 短期 | `develop` 或废弃 |

### 1.3 分支保护规则
| 分支 | 保护规则 | 说明 |
|------|----------|------|
| `main` | ✅ Required PR review (2) ✅ Status checks ✅ Linear history ✅ No force push ✅ No deletion ✅ Signed commits | 生产镜像，最高保护 |
| `develop` | ✅ Required PR review (1) ✅ Status checks ✅ No force push ✅ No deletion | 集成分支，需 Code Review |
| `release/*` | ✅ Required PR review (1) ✅ Status checks ✅ No force push | 发布分支，仅修复发布 Bug |
| `feature/*` `bugfix/*` | ❌ 无强制保护，建议开启 Status checks | 短生命周期，由作者自管 |
| `hotfix/*` | ✅ Required PR review (1) ✅ Status checks | 紧急修复，需快速 Review |

### 1.4 策略选型依据 (摘要)
- **团队规模**：10-20 人，支持并行开发、代码审查、冲突最小化
- **发布节奏**：月度次版本 + 周度补丁 + 按需热修复，支持多版本并行维护
- **环境层级**：开发 → 测试 → 预发布 → 生产，分支映射环境
- **选型**：混合策略 = GitFlow (版本隔离) + GitHub Flow (主干持续集成)

---

## 2. 工作流程

### 2.1 日常功能开发流程
```bash
# 1. 从 develop 创建功能分支
git checkout develop
git pull origin develop
git checkout -b feature/123-add-export-api

# 2. 本地开发，遵循提交规范
git add .
git commit -m "feat(export): add bulk export API
Closes #123"

# 3. 定期同步 develop (避免大冲突)
git fetch origin
git rebase origin/develop

# 4. 推送并创建 PR
git push origin feature/123-add-export-api
# GitHub/GitLab 创建 PR: feature/123-add-export-api → develop

# 5. Code Review 通过后，Squash and Merge
# 删除远程分支，本地清理
git checkout develop
git pull origin develop
git branch -d feature/123-add-export-api
```

### 2.2 缺陷修复流程
```bash
# 1. 从 develop 创建 bugfix 分支
git checkout develop
git pull origin develop
git checkout -b bugfix/456-fix-export-null

# 2. 修复并编写回归测试
git commit -m "fix(export): handle null status in bulk export
Root cause: status field not validated before CSV writer
Test: add null status test case in test_export.py
Fixes #456"

# 3. PR → develop，Review 通过后 Merge
```

### 2.3 紧急热修复流程
```bash
# 场景: 生产环境 P0 故障，需立即修复
# 1. 从 main 创建 hotfix 分支
git checkout main
git pull origin main
git checkout -b hotfix/789-fix-payment-crash

# 2. 修复、测试、构建验证
git commit -m "fix(payment): prevent null pointer in callback handler
Root cause: callback data missing required field
Test: add mock callback test with missing fields
Fixes #789"

# 3. 双 PR 并行 (或 cherry-pick)
# PR 1: hotfix/789-fix-payment-crash → main (优先部署)
# PR 2: hotfix/789-fix-payment-crash → develop (同步修复)

# 4. 如有活跃 release 分支，同步修复
git checkout release/v1.2
git cherry-pick <hotfix-commit-hash>
git push origin release/v1.2
```

### 2.4 发布流程
```bash
# 1. 发布准备: 从 develop 创建 release 分支
git checkout develop
git pull origin develop
git checkout -b release/v1.2
# 版本号更新、CHANGELOG 生成、版本号提交
git commit -m "chore(release): bump version to v1.2.0
Update CHANGELOG.md
Bump package.json version"

# 2. 发布分支仅接受 bugfix，不接受新功能
git checkout -b bugfix/release-v1.2-fix-export
# 修复发布阻断性 Bug...
git push origin bugfix/release-v1.2-fix-export
# PR → release/v1.2

# 3. 发布验证通过后，合并到 main 并打 Tag
git checkout main
git pull origin main
git merge --no-ff release/v1.2 -m "chore(release): merge release v1.2.0"
git tag -a v1.2.0 -m "Release v1.2.0"
git push origin main --tags

# 4. 同步回 develop
git checkout develop
git merge --no-ff release/v1.2 -m "chore(release): sync release v1.2.0 to develop"
git push origin develop

# 5. 清理 release 分支 (可选保留)
git branch -d release/v1.2
git push origin --delete release/v1.2
```

---

## 3. 提交规范

### 3.1 标准格式 (Conventional Commits 1.0.0)
```
<type>(<scope>): <subject>

<body>

<footer>
```

| 部分 | 必填 | 说明 |
|------|------|------|
| `type` | ✅ | 提交类型，决定语义化版本影响 |
| `scope` | ⭕ | 影响模块/范围，便于过滤和归类 |
| `subject` | ✅ | 简短摘要，祈使语气，首字母小写，无句号，< 50 字符 |
| `body` | ⭕ | 详细说明：动机、设计决策、破坏性变更 |
| `footer` | ⭕ | 关联 Issue、Breaking Change 声明、Co-author |

### 3.2 完整示例
```
feat(order): add bulk export API with CSV/Excel support

- Add new endpoint POST /api/v1/orders/export
- Support CSV and Excel format with configurable columns
- Add async job processing with progress tracking
- Implement permission check for export operation

Closes #123
Breaking Change: Response structure changed from direct file to job ID
Co-authored-by: Zhang San <zhangsan@example.com>
```

### 3.3 Type 类型规范
| type | 语义化版本影响 | 说明 | 示例 |
|------|---------------|------|------|
| `feat` | **MINOR** (次版本) | 新增用户可见功能 | `feat(order): add bulk export API` |
| `fix` | **PATCH** (补丁版本) | 修复 Bug | `fix(order): handle null status in export` |
| `perf` | **PATCH** | 性能优化 (不改变行为) | `perf(order): add index for status query` |
| `refactor` | 无 (或 PATCH) | 重构 (非功能/非修复) | `refactor(order): extract export logic to service` |
| `style` | 无 | 代码风格 (格式化、分号、空格) | `style: format order service with ruff` |
| `docs` | 无 | 文档更新 (README/CHANGELOG/API/注释) | `docs(order): update export API doc` |
| `test` | 无 | 测试相关 (新增/修改/重构测试) | `test(order): add export edge case tests` |
| `chore` | 无 | 构建/工具/依赖/配置/维护 | `chore: upgrade ruff to 0.4.0` |
| `build` | 无 | 构建系统/外部依赖/打包配置 | `build: add docker multi-stage build` |
| `ci` | 无 | CI/CD 配置/脚本/流水线 | `ci: add security scan stage` |
| `security` | **PATCH** (或 MINOR) | 安全加固/漏洞修复/合规 | `security: upgrade vulnerable dependency` |
| `release` | **MAJOR/MINOR/PATCH** | 发布准备/版本号/CHANGELOG | `release: prepare v1.3.0` |
| `revert` | 视情况 | 回滚之前的提交 | `revert: feat(order): add bulk export API` |
| `wip` | 无 | 工作进行中 (仅限本地/草稿 PR) | `wip: drafting export service` |

> **规则**：`wip` 类型**严禁**出现在合并到保护分支的历史中。

### 3.4 Scope 范围规范
| scope | 覆盖模块 | 示例 |
|-------|----------|------|
| `order` | 订单模块 (列表/详情/导出/状态) | `feat(order): add bulk export` |
| `product` | 商品模块 (列表/详情/SKU/分类) | `fix(product): fix sku price calc` |
| `auth` | 认证授权 (登录/OAuth/Token/JWT/RBAC) | `feat(auth): add OAuth2 refresh token` |
| `user` | 用户/账号/个人中心 | `feat(user): add avatar upload` |
| `compliance` | 合规/风控/规则引擎 | `feat(compliance): add keyword rule` |
| `alert` | 告警/通知/渠道 | `fix(alert): fix wecom notification` |
| `sync` | 数据同步/定时任务/Celery | `perf(sync): optimize batch insert` |
| `api` | 通用 API 基础设施 (中间件/异常/文档) | `refactor(api): unify error response` |
| `ui` | 前端 UI 组件/页面/样式 | `feat(ui): add dark theme toggle` |
| `infra` | 基础设施/部署/配置/监控/日志 | `chore(infra): add prometheus alerts` |
| `deps` | 依赖升级/锁文件 | `chore(deps): upgrade ruff to 0.4.0` |
| `release` | 发布相关 | `release: prepare v1.3.0` |
| `security` | 安全加固/漏洞修复 | `security: fix CVE-2024-xxxx` |

### 3.5 Subject 主题规范
| 规则 | 正例 | 反例 |
|------|------|------|
| **祈使语气** | `add export API` | `added export API` |
| **首字母小写** | `add export API` | `Add export API` |
| **无末尾句号** | `add export API` | `add export API.` |
| **简洁明了** | `add bulk export API` | `add a new feature to export orders in bulk` |
| **< 50 字符** | `add bulk export API` | `add bulk export API with CSV and Excel support...` |

### 3.6 Body 正文结构 (复杂变更必填)
```
# 动机/背景
说明为什么要做这个变更，关联 Issue/需求背景。

# 解决方案
核心实现思路、关键设计决策、考虑的替代方案及放弃理由。

# 实现细节
关键代码变更点、新增/修改的关键类/函数、数据流变化。

# 破坏性变更 (如有)
## 影响范围
- API: ...
- 数据库: ...
- 配置: ...

## 迁移指南
1. 步骤一...
2. 步骤二...

## 时间表
- v1.3: 新版本发布，旧字段标记废弃
- v1.4: 移除旧字段

# 测试验证
- 单元测试: 新增/修改 X 个测试用例
- 集成测试: 覆盖核心链路 X 条
- 手动验证: 已在测试环境验证导出功能
- 性能测试: P99 延迟从 500ms 降至 200ms
```

### 3.7 Footer 页脚规范
| 关键词 | 含义 | 示例 |
|--------|------|------|
| `Closes` / `Fixes` / `Resolves` | 关闭 Issue | `Closes #123` |
| `Refs` | 关联但不关闭 | `Refs #111, #222` |
| `BREAKING CHANGE:` | 破坏性变更声明 | 见下方示例 |
| `Co-authored-by:` | 协作者 | `Co-authored-by: Name <email>` |

**Breaking Change 示例**：
```
BREAKING CHANGE: API response structure changed from direct file download to async job pattern.

Impact:
- Old: GET /api/v1/orders/export → 200 OK (file stream)
- New: POST /api/v1/orders/export → 202 Accepted { job_id }
         GET /api/v1/export/jobs/{job_id} → 200 OK (file stream)

Migration guide: docs/migration/v1.3-export-api.md
```

### 3.8 常用提交示例
**功能新增**：
```
feat(order): add bulk export API with CSV/Excel support

- Add new endpoint POST /api/v1/orders/export
- Support CSV and Excel format with configurable columns
- Add async job processing with progress tracking (Redis + Celery)
- Implement permission check for export operation

Closes #123
Breaking Change: Response changed from direct file to async job pattern.
Migration guide: docs/migration/v1.3-export-api.md
```

**Bug 修复**：
```
fix(order): handle null status in bulk export CSV writer

Root cause: Order.status can be None for legacy orders, causing
AttributeError when CSV writer calls str(status.value).

Fix: Add null check, default to 'UNKNOWN' status for display.
Add regression test in test_export.py::test_export_null_status.

Fixes #456
```

**性能优化**：
```
perf(order): optimize order list query with composite index

Before: P99 latency 1.2s (full table scan on 500k rows)
After: P99 latency 45ms (index seek)

Changes:
- Add composite index (shop_id, status, created_at)
- Refactor query to use index seek instead of scan

Closes #789
```

**重构**：
```
refactor(order): extract export logic to dedicated service

Motivation: Export logic was mixed in controller, hard to test and reuse.
Extract to OrderExportService with clear interface.

Changes:
- New: OrderExportService (CSV/Excel generation, job management)
- New: ExportJob entity (progress tracking, result storage)
- Modified: OrderController -> delegate to service
```

**依赖升级**：
```
chore(deps): upgrade ruff from 0.3.0 to 0.4.0

Changes:
- Update pyproject.toml ruff version
- Fix new lint warnings: RUF012 (mutable default argument)
- Update pre-commit hook rev

Ref: https://github.com/astral-sh/ruff/releases/tag/0.4.0
```

### 3.9 语义化版本映射
| Commit Type | 版本号变化 | 示例 |
|-------------|-----------|------|
| `feat` | `MINOR` +1 | `v1.2.0` → `v1.3.0` |
| `fix` / `perf` / `security` | `PATCH` +1 | `v1.2.0` → `v1.2.1` |
| `BREAKING CHANGE` (footer) | `MAJOR` +1 | `v1.2.0` → `v2.0.0` |
| `release` | 显式指定 | `release: v2.0.0` |
| 其他 (`docs`/`style`/`chore`/`refactor`/`test`/`build`/`ci`) | **无变化** | - |

---

## 4. PR 流程与 Code Review

### 4.1 PR 创建检查清单
- [ ] 分支命名符合规范
- [ ] Commit Message 符合 Conventional Commits
- [ ] 代码通过 Lint、Type Check、Test (CI 全绿)
- [ ] 单元测试覆盖新增/修改逻辑 (核心模块 ≥ 80%)
- [ ] 更新相关文档 (README/CHANGELOG/API 文档/注释)
- [ ] 无明显性能退化、安全隐患
- [ ] PR 描述清晰：What/Why/How、关联 Issue、测试步骤、截图/录屏

### 4.2 PR 模板
```markdown
## 变更类型
- [ ] feat: 新功能
- [ ] fix: Bug 修复
- [ ] refactor: 重构
- [ ] perf: 性能优化
- [ ] docs: 文档更新
- [ ] test: 测试相关
- [ ] chore: 构建/工具/依赖

## 变更描述
**What**: 简述做了什么
**Why**: 为什么要做 (关联 Issue #123)
**How**: 核心实现思路、关键设计决策

## 变更影响
- 影响模块: [order, product, auth...]
- 破坏性变更: [无 / 有，详见下方]
- 数据库变更: [无 / 有迁移脚本]
- 配置变更: [无 / 新增环境变量 XXX]

## 测试验证
- [ ] 单元测试通过
- [ ] 集成测试通过
- [ ] 手动验证步骤:
  1. 登录系统
  2. 进入订单导出页
  3. 点击导出，验证 CSV 格式正确
- [ ] 性能测试: [无 / 通过基线对比]

## 破坏性变更 (如有)
- API 变更: `/api/v1/orders/export` 响应结构调整
- 迁移指南: 见 `docs/migration/v1.2-export-api.md`
- 废弃时间表: v1.3 移除旧字段

## 相关链接
- Issue: #123
- 设计文档: https://wiki.xxx.com/design/export-api
- 部署清单: https://wiki.xxx.com/deploy/checklist
```

### 4.3 Code Review 核心维度

| 维度 | 重点检查项 |
|------|------------|
| **正确性** | 需求对齐、边界处理、错误处理、事务一致性、并发安全 |
| **安全性** | 输入验证、SQL 注入防护、XSS/CSRF、认证授权、敏感数据、依赖安全 |
| **性能** | N+1 查询、索引覆盖、缓存策略、并发控制、资源释放、算法复杂度 |
| **代码质量** | 单一职责、命名规范、复用抽象、类型安全、文档注释 |
| **测试** | 单测覆盖 ≥80% 核心模块、集成测试关键链路、无 Flaky Test |
| **架构** | 分层清晰、依赖倒置、模块边界、配置外部化、向后兼容 |

### 4.4 评论最佳实践
| 评论类型 | 格式示例 | 适用场景 |
|----------|----------|----------|
| **建议修改** | `建议: 这里用 \`user_id\` 而非 \`uid\`，保持命名一致性` | 命名、风格、最佳实践 |
| **提问澄清** | `疑问: 这里为什么用 \`list\` 而非 \`set\`？是否有序要求？` | 逻辑不清、设计决策不明 |
| **指出风险** | `⚠️ 风险: 并发场景下可能丢失更新，建议加乐观锁` | 并发、安全、性能隐患 |
| **要求修复** | `🔴 必须修复: 直接拼接 SQL 存在注入风险，请用参数化查询` | 安全、正确性阻塞项 |
| **赞扬/学习** | `👍 这里用 \`functools.lru_cache\` 很巧妙，学习了` | 优秀实践、知识分享 |

### 4.5 评论礼仪
| 原则 | 正例 | 反例 |
|------|------|------|
| **具体可操作** | `建议将此处提取为 calculate_tax 函数` | `这段代码写得不好` |
| **区分阻塞/建议** | `🔴 必须修复: ...` / `💡 建议: ...` | 混淆优先级 |
| **提供替代方案** | `建议改用 dict.get(key, default) 避免 KeyError` | 只指出问题不给方案 |
| **避免人身攻击** | `这段逻辑容易引起并发问题` | `你写的代码有问题` |
| **及时跟进** | Author 修复后及时 Re-review，勾选 Resolved | 留存未解决评论 |

### 4.6 PR 规模控制
| 规模 | 建议行数 | 审查时长 | 策略 |
|------|----------|----------|------|
| **小** | < 100 行 | 10-15 分钟 | 直接审查 |
| **中** | 100-400 行 | 20-30 分钟 | 分模块审查 |
| **大** | 400-800 行 | 40-60 分钟 | **拆分为多个 PR** |
| **超大** | > 800 行 | > 1 小时 | **强制拆分** |

### 4.7 大 PR 拆分策略
| 拆分维度 | 示例 |
|----------|------|
| **按层级** | 1) 数据库迁移 2) Repository 层 3) Service 层 4) API 层 5) 前端组件 |
| **按功能** | 1) 核心 CRUD 2) 导出功能 3) 筛选/搜索 4) 权限控制 |
| **按依赖** | 1) 基础设施/配置 2) 核心领域模型 3) 业务逻辑 4) 接口暴露 |

### 4.8 审查决策
| 结论 | 含义 | 后续动作 |
|------|------|----------|
| **Approve** | 代码质量达标，可以合并 | Author 可合并 (或自动合并) |
| **Request Changes** | 存在必须修复的问题 | Author 修复后重新请求 Review |
| **Comment** | 仅有建议性意见，无阻塞项 | Author 可自行决定是否采纳 |

### 4.9 Review 角色与 SLA
| 角色 | 职责 | SLA |
|------|------|-----|
| **Author** | 自检、编写清晰 PR 描述、回应评论、修复问题 | - |
| **Reviewer** | 深度阅读代码、提出建设性反馈、Approve/Request Changes | 首次 Review ≤ 24h |
| **Tech Lead** | 核心模块/架构变更最终把关、裁决争议 | 关键 PR ≤ 4h |
| **QA** | 验证测试覆盖、复现缺陷、回归风险评估 | 测试相关 PR ≤ 8h |

### 4.10 Merge 策略
| 分支合并 | 策略 | 说明 |
|----------|------|------|
| `feature/*` → `develop` | **Squash and Merge** | 保持历史整洁，单次提交 |
| `bugfix/*` → `develop` | **Squash and Merge** | 同理 |
| `hotfix/*` → `main` | **Squash and Merge** | 快速合并，保持 main 简洁 |
| `release/*` → `main` | **Merge Commit (--no-ff)** | 保留发布分支历史、便于回溯 |
| `release/*` → `develop` | **Merge Commit (--no-ff)** | 同步发布修复回 develop |

---

## 5. 版本发布规范

### 5.1 语义化版本
```
MAJOR.MINOR.PATCH[-PRERELEASE][+BUILD]

MAJOR: 不兼容的 API 变更、重大架构调整
MINOR: 向后兼容的功能新增
PATCH: 向后兼容的 Bug 修复
PRERELEASE: alpha/beta/rc (如 v1.2.0-rc.1)
BUILD: Git Commit Hash (如 +abc1234)
```

### 5.2 发布节奏
| 发布类型 | 频率 | 分支 | 发布内容 |
|----------|------|------|----------|
| **主版本** | 半年/年 | `release/v{M+1}.0` | 重大架构、不兼容变更 |
| **次版本** | 月度/双周 | `release/v{M}.{m+1}` | 新功能、改进、兼容修复 |
| **补丁版本** | 周度/按需 | `release/v{M}.{m}.{p+1}` / `hotfix/*` | Bug 修复、安全补丁 |
| **预发布** | 按需 | `release/v{M}.{m}.{p}-rc.{n}` | 内测、灰度验证 |

### 5.3 发布清单
| 步骤 | 责任人 | 验收标准 |
|------|--------|----------|
| 版本号确认、CHANGELOG 生成 | PM/Tech Lead | 版本号语义正确、变更完整 |
| 发布分支创建、版本号提交 | Tech Lead | CI 通过、版本号一致 |
| 发布分支验证 (测试/预发布/灰度) | QA/运维/业务 | 核心流程通过、无 P0/P1 缺陷 |
| 生产部署、冒烟测试 | 运维/Tech Lead | 核心接口可用、监控正常 |
| Tag 打标、合并回 develop | Tech Lead | Tag 规范、合并无冲突 |
| 发布通知、文档归档 | PM | 发布公告、归档制品 |

---

## 6. 常用 Git 命令速查

### 6.1 分支操作
```bash
# 查看分支
git branch -a -vv          # 显示所有分支及上游
git log --oneline --graph --all -20  # 可视化历史

# 创建/切换
git switch -c feature/xxx  # 创建并切换 (Git 2.23+)
git switch develop         # 切换分支

# 同步上游
git fetch origin           # 仅获取
git pull --rebase          # 变基拉取 (功能分支推荐)
git pull                   # 合并拉取 (主分支推荐)

# 删除分支
git branch -d feature/xxx  # 本地删除 (已合并)
git branch -D feature/xxx  # 强制删除
git push origin --delete feature/xxx  # 远程删除
```

### 6.2 提交与重写
```bash
# 修正最近一次提交
git commit --amend --no-edit      # 仅修正内容，保留 message
git commit --amend -m "new msg"   # 修改 message

# 交互式变基 (整理提交历史)
git rebase -i HEAD~3              # 最近 3 个提交
# pick/squash/drop/edit/reword

# 撤销操作
git reset --soft HEAD~1           # 保留改动在暂存区
git reset --mixed HEAD~1          # 保留改动在工作区 (默认)
git reset --hard HEAD~1           # 彻底丢弃 (慎用!)

# 恢复丢失提交
git reflog                        # 查看操作历史
git checkout <commit-hash>        # 恢复到该提交
```

### 6.3 冲突解决
```bash
# 变基时冲突
git rebase origin/develop
# 冲突文件会标记 <<<<<<< ======= >>>>>>>
# 手动解决后
git add <resolved-files>
git rebase --continue

# 合并时冲突
git merge feature/xxx
# 解决后
git add <resolved-files>
git commit -m "resolve conflict: merge feature/xxx"
```

### 6.4 远程操作
```bash
# 设置上游
git push -u origin feature/xxx    # 首次推送设置上游

# 强制推送 (仅限个人分支、变基后)
git push --force-with-lease origin feature/xxx  # 更安全

# 标签操作
git tag -a v1.2.0 -m "Release v1.2.0"
git push origin v1.2.0
git push origin --tags            # 推送所有标签

# 清理远程已删除分支的本地跟踪
git fetch -p                      # prune
```

### 6.5 搜索与诊断
```bash
# 搜索代码
git grep "TODO" -- "*.py"         # 搜索特定模式
git log --all --grep="JIRA-123"   # 搜索提交信息
git log -p --follow -- <file>     # 文件完整修改历史

# 统计贡献
git shortlog -sn                  # 按提交数排序
git shortlog -sn --since="2026-01-01"

# 大文件查找
git rev-list --objects --all | grep "$(git verify-pack -v .git/objects/pack/*.idx | sort -k3 -n | tail -10 | awk '{print $1}')"
```

---

## 7. Git Hooks 与自动化

### 7.1 客户端 Hooks (本地强制)
```bash
# .pre-commit-config.yaml
repos:
-   repo: https://github.com/astral-sh/ruff-pre-commit
    rev: v0.4.0
    hooks:
    -   id: ruff
        args: [--fix, --exit-non-zero-on-fix]
    -   id: ruff-format

-   repo: https://github.com/pre-commit/mirrors-mypy
    rev: v1.8.0
    hooks:
    -   id: mypy
        args: [--strict]

-   repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v4.5.0
    hooks:
    -   id: trailing-whitespace
    -   id: end-of-file-fixer
    -   id: check-yaml
    -   id: check-json
    -   id: check-merge-conflict
    -   id: detect-private-key
    -   id: check-added-large-files
```

安装：`pre-commit install`

### 7.2 服务端 Hooks (CI/CD 强制)
- `pre-receive`：拒绝未签名提交、拒绝未通过 CI 的提交
- `update`：保护分支命名规范、提交 message 规范
- `post-receive`：触发 CI/CD、通知系统

### 7.3 Commit Lint (CI 校验)
```yaml
# .github/workflows/commit-lint.yml
name: Commit Lint
on: [push, pull_request]
jobs:
  commitlint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with: { fetch-depth: 0 }
      - uses: wagoid/commitlint-github-action@v5
        with: { configFile: .commitlintrc.yaml }
```

```yaml
# .commitlintrc.yaml
extends: ['@commitlint/config-conventional']
rules:
  type-enum: [2, always, [feat, fix, perf, refactor, style, docs, test, chore, build, ci, security, release, revert]]
  subject-case: [2, never, [sentence-case, start-case, pascal-case, upper-case]]
  subject-empty: [2, never]
  subject-full-stop: [2, never, '.']
  header-max-length: [2, always, 72]
```

### 7.4 自动化发布
```yaml
# .github/workflows/release.yml
name: Release
on:
  push:
    branches: [main]
    tags: ['v*']

jobs:
  release:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with: { fetch-depth: 0 }
      - uses: conventional-changelog/conventional-changelog-action@v4
        with:
          github-token: ${{ secrets.GITHUB_TOKEN }}
          version-file: package.json
          tag-prefix: 'v'
      - name: Create Release
        uses: softprops/action-gh-release@v1
        with: { generate_release_notes: true }
```

---

## 8. 常见问题与最佳实践

### 8.1 场景速查表
| 场景 | 推荐做法 | 避坑指南 |
|------|----------|----------|
| 长期功能分支 | 定期 `rebase develop`、小步提交、及时 PR | 避免大冲突、避免分支腐烂 |
| 多人协作同一功能 | 共享功能分支、约定 commit message 前缀 | 避免 force push 覆盖他人工作 |
| 代码审查发现大改动 | 拆分小 PR、或在 PR 中分多次 commit | 避免单次 PR 过大 (>500 行) |
| 生产热修复同步 develop | `cherry-pick` 或合并 hotfix 分支 | 避免遗漏同步导致回归 |
| 大文件误提交 | `git filter-repo` / BFG Repo-Cleaner 清理历史 | 预提交钩子拦截大文件 |
| 敏感信息泄露 | 立即轮换密钥、`git filter-repo` 清理、通知安全团队 | 预提交钩子检测密钥 |

### 8.2 遗留分支清理
```bash
# 查找已合并的远程分支
git branch -r --merged main | grep -v "main\|develop\|release/" | xargs -n 1 git push origin --delete

# 查找超过 90 天无活动的分支
git for-each-ref --format='%(refname:short) %(committerdate:iso8601) %(authorname)' refs/remotes/origin | \
  awk '$2 < "'$(date -d '90 days ago' +%Y-%m-%d)'" {print $1}' | \
  xargs -n 1 git push origin --delete
```

### 8.3 单仓多版本维护
```bash
# 场景：同时维护 v1.x、v2.x 两个主版本
main          → v2.x 生产
release/v1.2  → v1.x 生产维护分支
release/v2.3  → v2.x 预发布
develop       → v2.x 下一版本开发

# 热修复同步策略
hotfix/v1.2.x → release/v1.2 → main (v1.x 生产)
hotfix/v2.x   → main → develop (v2.x 同步)
```

### 8.4 Review 反模式与避坑
| 反模式 | 表现 | 危害 | 纠正措施 |
|--------|------|------|----------|
| **橡皮图章** | 快速 Approve，未细读代码 | 漏缺陷、形式主义 | 强制 Checklist、最小审查时长、Review 质量考核 |
| **事无巨细** | 纠结缩进、换行、变量名偏好 | 浪费时间、打击积极性 | 交给 Formatter/Linter、约定风格指南 |
| **推迟 Review** | PR 挂起数天 | 阻塞交付、上下文丢失 | SLA 考核、自动提醒、轮值 Reviewer |
| **只看不评** | 只看不发表评论 | 知识不传递、问题不暴露 | 最少 1 条评论/建议、鼓励提问 |
| **争论不休** | 风格偏好争论、不设截止 | 消耗精力、延误合并 | 约定风格指南、Tech Lead 裁决、约定优于配置 |

---

## 9. 附录

### 9.1 快速参考卡
```
# 类型速查
feat     → MINOR    新功能
fix      → PATCH    修复Bug
perf     → PATCH    性能优化
refactor → (无)     重构
docs     → 无       文档
test     → 无       测试
chore    → 无       杂项
revert   → 视情况   回滚

# Scope 常用
order | product | auth | user | compliance | alert | sync | api | ui | infra | deps | security

# Subject 口诀
祈使语气、首字母小写、无句点、<50字符

# Footer 关键字
Closes #123 | BREAKING CHANGE: ... | Co-authored-by: Name <email>
```

### 9.2 常用 Git 别名
```bash
# ~/.gitconfig
[alias]
  co = checkout
  br = branch -vv
  st = status -sb
  lg = log --oneline --graph --decorate --all -20
  amend = commit --amend --no-edit
  undo = reset --soft HEAD~1
  clean-branches = "!git branch --merged | grep -v '\\*\\|main\\|develop' | xargs -r git branch -d"
  fix = "!f() { git commit -m \"fix($1): $2\"; }; f"
  feat = "!f() { git commit -m \"feat($1): $2\"; }; f"
  perf = "!f() { git commit -m \"perf($1): $2\"; }; f"
```

### 9.3 全局 Git 配置推荐
```bash
# ~/.gitconfig
[user]
    name = Your Name
    email = your.email@company.com
    signingkey = YOUR_GPG_KEY_ID

[commit]
    gpgsign = true
    template = ~/.gitmessage.txt

[rebase]
    autoStash = true
    updateRefs = true

[merge]
    conflictstyle = diff3
    ff = only

[pull]
    rebase = true
    ff = only

[push]
    autoSetupRemote = true
    followTags = true
```

---

*文档版本: v2.0.0 | 维护者: Tech Lead | 更新周期: 季度 | 遵循标准: Conventional Commits 1.0.0*
EOF