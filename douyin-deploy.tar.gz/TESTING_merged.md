---
title: 测试与质量保障规范
version: 2.0.0
status: Published
last_updated: 2026-10-07
owner: QA Lead
reviewers: [测试工程师, Tech Lead, PM, DevOps Lead]
approvers: [QA Lead]
classification: Internal
doc_id: DOC-QA-001
tags: [质量, 测试, 测试策略, 质量计划, 测试报告, Code Review, CI/CD]
related_docs: [DOC-DEV-002, DOC-OPS-001]
changelog: |
  v2.0.0 (2026-10-07): 合并 TEST_STRATEGY.md、QUALITY_PLAN.md、TEST_REPORT_TEMPLATE.md、CODE_REVIEW_CHECKLIST.md 为统一测试质量规范文档 - DevOps Lead
  v1.0.0 (2026-09-26): 初版创建 - QA Lead
---

# 测试与质量保障规范

> 本文档统一了测试策略、质量计划、测试报告模板、Code Review 检查清单，作为团队质量保障的核心参考。

---

## 目录

1. [测试策略](#1-测试策略)
2. [质量管理计划](#2-质量管理计划)
3. [测试报告模板](#3-测试报告模板)
4. [Code Review 检查清单](#4-code-review-检查清单)
5. [CI/CD 质量门禁](#5-cicd-质量门禁)
6. [缺陷管理](#6-缺陷管理)
7. [持续改进](#7-持续改进)

---

## 1. 测试策略

### 1.1 测试金字塔

```
                    ╔═════════════════════╗
                    ║    E2E Tests        ║  █ 少量，覆盖核心用户流程
                    ║   (Playwright)      ║
                ╔══════════════════════════╗
                ║  Contract Tests         ║  █ API 契约验证
                ║   (Pact/Swagger)        ║
            ╔══════════════════════════════════╗
            ║  Integration Tests            ║  █ 服务间交互、DB、外部 API
            ║   (Testcontainers)            ║
        ╔══════════════════════════════════════════╗
        ║        Unit Tests                    ║  █ 大量，快速，覆盖业务逻辑
        ║   (pytest / Vitest)                  ║
        ╚══════════════════════════════════════════╝
```

### 1.2 测试目标
- **功能正确性**：核心业务流程 100% 覆盖，验收标准 100% 满足
- **回归防护**：重构/新增功能不破坏现有功能
- **性能基线**：API P99 ≤ 500ms，页面加载 ≤ 3s，同步成功率 ≥ 99%
- **安全合规**：0 Critical/High CVE，0 未修复安全漏洞
- **可维护性**：测试代码作为活文档，新人可阅读理解业务

### 1.3 单元测试

#### 1.3.1 后端
| 维度 | 标准 |
|------|------|
| **框架** | `pytest` + `pytest-mock` + `pytest-cov` |
| **覆盖率** | ≥ 85%（核心业务逻辑 ≥ 95%） |
| **命名规范** | `test_<module>_<function>_<scenario>` |
| **执行时限** | 单次运行 < 30s |

#### 1.3.2 关键模块测试重点
| 模块 | 测试场景 |
|------|----------|
| `config.py` | 环境变量解析、默认值、类型转换、缺失必填项报错 |
| `douyin_sign.py` | 签名算法正确性、边界参数、异常输入处理 |
| `app.py` - `_request` | 重试策略、超时处理、错误码映射、Header 注入 |
| `app.py` - `fetch_and_store_*` | 字段标准化、默认值兜底、幂等写入调用 |
| `tasks.py` - Celery 任务 | 任务幂等性、重试机制、失败告警 |
| `utils/formatters.ts` | 格式化函数边界值、空值、大数值、负数 |

#### 1.3.3 Mock 策略
```python
# 外部 API 统一 Mock
@pytest.fixture
def mock_external_api(monkeypatch):
    async def mock_get(*args, **kwargs):
        return {"data": {"products": [{"product_id": "p1", "sales_today": 100}]}}
    monkeypatch.setattr("app._request", mock_get)

# 数据库/Redis 使用 fakeredis / sqlite 内存模式
@pytest.fixture
def fake_redis():
    import fakeredis
    return fakeredis.FakeRedis()
```

#### 1.3.4 测试数据管理
- **Fixtures**：`tests/fixtures/` 存放 JSON 模板数据 (`products.json`, `orders.json`)
- **Factory**：使用 `factory_boy` 生成测试数据
- **参数化**：`@pytest.mark.parametrize` 覆盖多场景

### 1.4 集成测试

#### 1.4.1 范围
- Flask 应用完整启动 (`TestClient`)
- Redis / Celery 真实集成 (Testcontainers)
- 外部 API 契约验证 (录制/回放模式)

#### 1.4.2 关键测试场景
| 场景 | 验证点 |
|------|--------|
| 全量同步流程 | `POST /api/sync` → 触发 Celery → 数据入库 → 缓存更新 → 告警检查 |
| 分页查询 | `/api/products?page=2&size=10` 正确返回分页数据 |
| 签名参数注入 | 请求 Header 包含 `a_bogus`、`msToken` 等动态参数 |
| 告警触发 | 模拟销量下跌 40% → 生成告警记录 → 发送通知 (Mock SMTP) |
| 健康检查 | `/api/health` 返回 `status: healthy` + 最后同步时间 |

#### 1.4.3 环境隔离
```python
# tests/integration/conftest.py
@pytest.fixture(scope="session")
def docker_services():
    import testcontainers.redis
    redis = testcontainers.redis.RedisContainer("redis:7-alpine")
    redis.start()
    yield {"redis": redis.get_container_host_ip(), "port": redis.get_exposed_port(6379)}
    redis.stop()
```

### 1.5 契约测试

| 方式 | 适用场景 | 实现 |
|------|----------|------|
| **OpenAPI 规范验证** | CI 中验证 `openapi.json` | `swagger-codegen` / `openapi-validator` |
| **Pact 消费者驱动契约** | 前端 Consumer / 后端 Provider | 验证请求/响应结构 |
| **TypeScript 类型集成** | OpenAPI 生成前端类型 | `openapi-typescript` → `tsc --noEmit` |

```yaml
# CI 集成示例
- name: Validate OpenAPI spec
  run: |
    python -c "import json; json.load(open('openapi.json'))"
    npx @redocly/openapi-cli lint openapi.json
- name: Generate frontend types
  run: |
    npx openapi-typescript openapi.json -o frontend/src/types/api.d.ts
    npx tsc --noEmit
```

### 1.6 端到端测试

| 维度 | 标准 |
|------|------|
| **工具** | Playwright (TypeScript) |
| **核心用户流程** | 登录 → 仪表盘查看 → 手动同步 → 等待完成 → 刷新验证 → 告警配置修改保存 → 商品搜索导出 CSV |

### 1.7 性能测试

| 指标 | 目标 |
|------|------|
| API P95 响应时间 | ≤ 200ms |
| API P99 响应时间 | ≤ 500ms |
| 并发承载 | ≥ 100 RPS (单机) |
| 页面首屏加载 (LCP) | ≤ 2.5s |

```javascript
// tests/performance/api_load.js (k6)
export const options = {
  stages: [
    { duration: '30s', target: 50 },
    { duration: '1m', target: 100 },
    { duration: '30s', target: 0 },
  ],
  thresholds: {
    http_req_duration: ['p(95)<200', 'p(99)<500'],
    http_req_failed: ['rate<0.01'],
  },
}
```

### 1.8 安全测试

| 工具 | 频率 | 标准 |
|------|------|------|
| `pip-audit` / `safety` | 每次 CI | 0 High/Critical |
| `npm audit` | 每次 CI | 0 High/Critical |
| `trivy` (Docker 镜像) | Release 前 | 0 Critical |
| `Bandit` (Python SAST) | 每次 CI | 0 High |
| `ESLint Security Plugin` (TS) | 每次 CI | 0 High |
| `GitLeaks` / `TruffleHog` | 每次 CI | 0 泄露 |

### 1.9 测试环境与数据

| 环境 | 用途 | 数据来源 | 隔离策略 |
|------|------|----------|----------|
| **Local** | 开发调试 | Mock / 本地 JSON | 每次运行隔离 |
| **CI** | 自动化验证 | Fixtures + Testcontainers | 每次运行隔离 |
| **Staging** | 冒烟/回归 | 生产数据脱敏拷贝 | 每日同步 |
| **Production** | 监控告警 | 真实数据 | 实时 |

**测试数据规范**：
- 严禁使用生产真实数据跑自动化测试
- 脱敏规则：手机号中间 4 位脱敏、身份证/银行卡脱敏、金额 ±10% 扰动
- 数据版本控制：`tests/fixtures/v1/` 目录管理，Schema 变更同步更新

---

## 2. 质量管理计划

### 2.1 质量目标

| 维度 | 目标指标 | 验收方式 | 责任人 |
|------|----------|----------|--------|
| **功能正确性** | 核心业务流程 100% 覆盖 | 单元/集成/契约/E2E 测试覆盖率 | 测试工程师 |
| **代码质量** | 0 Critical/High 静态分析问题 | CI Lint/Gate | 开发工程师 |
| **安全合规** | 0 未修复 Critical/High CVE | Trivy/Snyk 扫描 | 安全工程师 |
| **性能基线** | API P99 < 500ms，同步成功率 > 99% | 持续监控 + 压测 | 后端工程师 |
| **可用性** | 服务可用性 ≥ 99.9% | 健康检查 + SLA 监控 | 运维工程师 |
| **文档同步** | 代码变更同步更新文档 | CI 文档检查 | 文档工程师 |

### 2.2 质量保障活动

#### 2.2.1 开发阶段 (每 PR)
| 活动 | 频率 | 工具/标准 | 通过标准 |
|------|------|-----------|----------|
| **代码评审** | 每 PR | GitLab MR + 至少 1 Approve | 无阻塞性意见 |
| **静态分析** | 每次提交 | flake8 + black + mypy | 0 errors, 0 warnings |
| **单元测试** | 每次提交 | pytest + pytest-cov | 覆盖率 ≥ 80% (核心 100%) |
| **契约测试** | 每 PR | pytest-contract | 100% 通过 |
| **依赖扫描** | 每次构建 | Trivy (requirements.txt) | 0 Critical/High |

#### 2.2.2 集成/验收阶段 (每日/每 PR)
| 活动 | 频率 | 工具/标准 | 通过标准 |
|------|------|-----------|----------|
| **集成测试** | 每日/每 PR | pytest-integration (Mock 外部 API) | 100% 通过 |
| **端到端测试** | 每次发布前 | Playwright (自动化/手动) | 核心流程 100% |
| **安全扫描** | 每次构建 | Trivy (fs/config/deps) | 0 Critical/High |
| **镜像扫描** | 每次发布 | Trivy (Docker image) | 0 Critical/High |
| **性能基线** | 每次发布前 | Locust/k6 压测 | P99 < 500ms，成功率 > 99% |

#### 2.2.3 发布/运维阶段
| 活动 | 频率 | 工具/标准 | 通过标准 |
|------|------|-----------|----------|
| **健康检查** | 每 5 分钟 | `/api/v1/health` | success=true |
| **冒烟测试** | 每次部署后 | 核心 API 调用 | 核心接口 200 OK |
| **回滚演练** | 季度 | 手动/自动演练 | RTO < 5 分钟 |
| **灾备演练** | 半年 | 手动演练 | RPO < 1 小时，RTO < 30 分钟 |

### 2.3 测试策略金字塔覆盖率要求

| 层级 | 覆盖目标 | 典型用例数量级 |
|------|----------|----------------|
| **单元测试** | 核心业务 100%，整体 ≥ 85% | 数百 |
| **集成测试** | 核心链路 100% | 数十 |
| **契约测试** | 所有对外 API 100% | 数十 |
| **E2E 测试** | 核心用户流程 100% | < 20 |
| **性能测试** | 核心接口基线达标 | 5-10 场景 |
| **安全测试** | 0 Critical/High | 全量扫描 |

### 2.4 代码质量标准

| 语言 | 规范 | 工具 | CI 强制 |
|------|------|------|---------|
| **Python** | PEP 8 + Google Style Docstring | black + flake8 + pydocstyle | ✅ |
| **TypeScript** | Airbnb + Prettier | eslint + prettier | ✅ |
| **Dockerfile** | Hadolint | hadolint | ✅ |
| **YAML** | Yamllint | yamllint | ✅ |

#### 2.4.1 代码评审清单 (核心项)
- [ ] 功能实现完整符合需求
- [ ] 单元测试覆盖新增/修改逻辑 (核心模块 ≥ 80%)
- [ ] 错误处理完善 (统一错误码、可读信息、保留堆栈)
- [ ] 无安全隐患 (SQL 注入、XSS、权限绕过、敏感信息硬编码)
- [ ] 无性能反模式 (N+1、无索引全表扫描、大事务、阻塞调用)
- [ ] 命名规范、类型注解完整、文档注释同步更新
- [ ] 配置外部化、无硬编码、Feature Flag 渐进式发布

---

## 3. 测试报告模板

### 3.1 报告基本信息
| 项目 | 内容 |
|------|------|
| 项目名称 | 抖音电商数据监控平台 |
| 版本/迭代 | v{版本号} / Sprint {编号} |
| 测试类型 | 功能测试 / 回归测试 / UAT / 性能测试 / 安全测试 |
| 测试周期 | {开始日期} ~ {结束日期} |
| 测试环境 | 测试环境 / 预发布环境 / 生产环境 (灰度) |
| 报告编制 | {测试工程师姓名} |
| 报告审核 | {QA Lead 姓名} |
| 报告日期 | {YYYY-MM-DD} |

### 3.2 整体结论
- [ ] **通过** - 满足发布标准，建议发布
- [ ] **条件通过** - 存在已知风险，需业务方确认接受
- [ ] **不通过** - 存在阻塞性缺陷，不建议发布

### 3.3 关键指标仪表盘
| 指标 | 目标值 | 实际值 | 达成状态 |
|------|--------|--------|---------|
| 测试用例执行率 | 100% | {XX}% | ✅/❌ |
| 测试用例通过率 | ≥ 95% | {XX}% | ✅/❌ |
| P0 缺陷清零率 | 100% | {XX}% | ✅/❌ |
| P1 缺陷清零率 | 100% | {XX}% | ✅/❌ |
| 缺陷修复验证通过率 | 100% | {XX}% | ✅/❌ |
| 核心接口自动化覆盖率 | ≥ 80% | {XX}% | ✅/❌ |
| 性能基线达标率 | 100% | {XX}% | ✅/❌ |
| 安全扫描高危漏洞 | 0 个 | {XX} 个 | ✅/❌ |

### 3.4 测试用例执行统计
| 模块 | 计划数 | 执行数 | 通过数 | 失败数 | 阻塞数 | 执行率 | 通过率 |
|------|--------|--------|--------|--------|--------|--------|--------|
| 仪表盘 | {XX} | {XX} | {XX} | {XX} | {XX} | {XX}% | {XX}% |
| 商品管理 | {XX} | {XX} | {XX} | {XX} | {XX} | {XX}% | {XX}% |
| 订单管理 | {XX} | {XX} | {XX} | {XX} | {XX} | {XX}% | {XX}% |
| 合规管理 | {XX} | {XX} | {XX} | {XX} | {XX} | {XX}% | {XX}% |
| 告警设置 | {XX} | {XX} | {XX} | {XX} | {XX} | {XX}% | {XX}% |
| 授权管理 | {XX} | {XX} | {XX} | {XX} | {XX} | {XX}% | {XX}% |
| 同步任务 | {XX} | {XX} | {XX} | {XX} | {XX} | {XX}% | {XX}% |
| API 接口 | {XX} | {XX} | {XX} | {XX} | {XX} | {XX}% | {XX}% |

### 3.5 缺陷统计分析
| 严重级别 | 新建 | 已修复 | 验证通过 | 验证失败 | 延期/拒绝 | 遗留未修复 |
|----------|------|--------|----------|----------|-----------|------------|
| P0 (阻塞) | {XX} | {XX} | {XX} | {XX} | {XX} | **0** |
| P1 (严重) | {XX} | {XX} | {XX} | {XX} | {XX} | **0** |
| P2 (一般) | {XX} | {XX} | {XX} | {XX} | {XX} | {XX} |
| P3 (建议) | {XX} | {XX} | {XX} | {XX} | {XX} | {XX} |

**遗留缺陷风险确认**：P2/P3 未修复缺陷需经 PM/业务方评估签字确认可接受。

### 3.6 专项测试结果
- **性能测试**：核心场景 (仪表盘查询、商品列表、订单导出、同步任务) 基线对比
- **安全测试**：SAST/DAST/依赖/容器/渗透扫描结果及修复状态
- **兼容性测试**：浏览器/分辨率/移动端适配结果
- **自动化覆盖**：单元/接口/UI/契约测试用例数、通过率、维护成本

### 3.7 发布决策签署
| 角色 | 姓名 | 签名 | 日期 | 意见 |
|------|------|------|------|------|
| QA Lead | | | | |
| Tech Lead | | | | |
| PM / 业务方 | | | | |

---

## 4. Code Review 检查清单

### 4.1 PR 基本信息
| 项目 | 内容 |
|------|------|
| PR 编号 | #XXXX |
| 标题 | {简述变更内容} |
| 作者 | @{作者} |
| Reviewer(s) | @{Reviewer1}, @{Reviewer2} |
| 关联 Issue | #{Issue 编号} |
| 变更类型 | [ ] 功能新增 [ ] Bug 修复 [ ] 重构 [ ] 性能优化 [ ] 文档更新 [ ] 配置变更 [ ] 依赖升级 |
| 风险等级 | [ ] 低 [ ] 中 [ ] 高 (核心链路/数据库变更/安全/架构调整) |

### 4.2 设计与架构
- [ ] 变更完整解决 Issue 问题，无过度设计 (YAGNI)
- [ ] 符合现有架构 (分层、模块边界、依赖方向)
- [ ] API 设计规范 (RESTful、分页、错误码、版本控制、向后兼容)
- [ ] 数据库 Schema 变更有迁移脚本 (可回滚)、索引合理、敏感字段加密
- [ ] 认证授权完整 (资源级权限、所有权校验)、输入验证全面、防常见漏洞
- [ ] 无硬编码密钥/Token、敏感操作有审计日志

### 4.3 代码实现质量

#### 通用规范
- [ ] Lint/格式化通过、命名语义清晰、函数单一职责 (< 50 行、圈复杂度 < 10)
- [ ] DRY 原则、错误处理完善、日志规范 (级别正确、结构化、含 Trace ID、不打印敏感信息)
- [ ] 公共 API 必须有文档注释、复杂逻辑有行内注释

#### Python (Backend)
- [ ] 类型注解完整，`mypy --strict` 通过
- [ ] 依赖版本锁定、异步代码正确、无阻塞调用、连接池复用
- [ ] 数据库查询参数化、无 N+1、大事务拆分
- [ ] Celery 任务幂等、可重试、超时设置、结果后端配置

#### TypeScript/React (Frontend)
- [ ] `strict: true` 通过、无 `any` 滥用
- [ ] 组件设计合理 (展示/容器分离、Props 类型、默认值)
- [ ] Hooks 依赖数组完整、无 stale closure、状态管理最小化
- [ ] 性能优化到位 (`React.memo`、`useMemo`、`useCallback`、代码分割)
- [ ] 无直接操作 DOM、无内存泄漏、国际化/无障碍支持

#### 测试覆盖
- [ ] 单元测试覆盖核心逻辑 (边界/异常/外部依赖 Mock)
- [ ] 集成测试验证模块间交互、测试数据隔离、无 Flaky Test

### 4.4 性能与可观测性
- [ ] 无 N+1、大循环查询、未分页大列表、同步阻塞
- [ ] 缓存策略合理 (Key、TTL、穿透/击穿/雪崩防护、一致性)
- [ ] 数据库查询有索引覆盖、分页用游标/Keyset
- [ ] 关键指标已埋点 (QPS、延迟 P50/P95/P99、错误率、业务计数器)
- [ ] 分布式追踪完整、健康检查端点完整、告警规则覆盖核心指标

### 4.5 部署与运维
- [ ] 环境变量/配置无硬编码、敏感信息外部化
- [ ] 数据库迁移脚本已测试 (正向/逆向、大表在线变更)
- [ ] API 版本兼容策略明确、弃用时间表
- [ ] 启动/停止优雅、日志结构化 (JSON)、指标导出标准 (Prometheus)

### 4.6 文档与知识传递
- [ ] README/CHANGELOG 更新 (版本号、变更摘要、升级指南、Breaking Changes)
- [ ] 架构/设计文档同步 (ADR、数据流、接口文档)
- [ ] 运维手册更新 (新增配置、部署步骤、故障排查、常用命令)

### 4.7 审查结论
| 结论 | 含义 | 后续 |
|------|------|------|
| **Approve** | 质量达标，可合并 | 作者可合并 |
| **Request Changes** | 有阻塞性问题 | 作者修复后重新 Review |
| **Comment** | 仅建议性意见 | 作者自行决定采纳 |

**核心模块/高风险变更**：需 2 名 Reviewer + Tech Lead Approve

### 4.8 常见问题速查 (必修复项)
| 类别 | 典型错误 | 检查方法 |
|------|----------|----------|
| SQL 注入 | 字符串拼接 SQL | 搜索 `f"SELECT`、`%s` 拼接、`execute(` 非参数化 |
| XSS | `dangerouslySetInnerHTML`、未转义输出 | 搜索 `dangerouslySetInnerHTML`、`v-html` |
| 权限绕过 | 缺少资源所有权校验 | 检查写接口是否校验 `resource.owner == current_user` |
| 敏感信息泄露 | 日志打印 Token/密码 | 搜索 `log.*password`、`log.*token`、`print(` |
| 死锁 | 多表更新顺序不一致 | 检查事务中多表更新顺序 |
| 内存泄漏 | 订阅未取消、缓存无 TTL | 搜索 `addEventListener` 无 `remove` |

### 4.9 性能陷阱
| 场景 | 症状 | 优化方向 |
|------|------|----------|
| N+1 查询 | 列表接口查询数 = N+1 | `joinedload`/`selectinload`/批量查询 |
| 大事务 | 锁等待超时、主从延迟 | 拆分事务、异步补偿、乐观锁 |
| 无索引全表扫描 | 慢查询日志、EXPLAIN type=ALL | 添加联合索引、覆盖索引 |
| 缓存击穿 | 热 Key 过期瞬间 DB 压力飙升 | 互斥锁重建、永不过期+异步更新 |
| 连接池耗尽 | "Too many connections" | 调整池大小、检查泄漏、缩短事务 |

---

## 5. CI/CD 质量门禁

```mermaid
graph LR
    A[Push/PR] --> B[Lint + TypeCheck]
    B --> C[Unit Tests]
    C --> D[Integration Tests]
    D --> E[Contract Tests]
    E --> F[Security Scan]
    F --> G[Build Docker]
    G --> H[E2E Tests on Staging]
    H --> I[Deploy Decision]
```

### 5.1 必须通过门禁
| 阶段 | 必须通过 | 可选 |
|------|----------|------|
| Lint/TypeCheck | ✅ | - |
| Unit Tests | ✅ (覆盖率 ≥ 80%) | - |
| Integration Tests | ✅ | - |
| Contract Tests | ✅ | - |
| Security Scan | ✅ (0 Critical/High) | - |
| E2E Tests | - | ✅ (Staging) |

### 5.2 关键 CI 配置
```yaml
# .github/workflows/ci.yml 关键质量门禁
- flake8 .              # 语法/风格检查
- black --check .       # 格式化检查
- pytest --cov=80%      # 覆盖率门禁
- trivy fs .            # 漏洞扫描 (Critical/High 闸机)
- trivy config .        # 配置扫描
```

### 5.3 本地预检
```bash
# 安装 pre-commit
pre-commit install

# 本地全量检查
make check  # 等价: flake8 + black --check + pytest --cov=80%

# 本地安全扫描
trivy fs . --severity CRITICAL,HIGH
```

---

## 6. 缺陷管理

### 6.1 严重分级
| 级别 | 定义 | 响应时限 | 修复时限 | 示例 |
|------|------|----------|----------|------|
| **Critical (P0)** | 核心功能不可用/数据丢失/安全漏洞 | 15 分钟 | 2 小时 | 同步全挂、SQL 注入、数据泄露 |
| **High (P1)** | 重要功能异常/性能严重劣化 | 30 分钟 | 4 小时 | 接口 P99 > 500ms、同步成功率 < 90% |
| **Medium (P2)** | 非核心功能缺陷/UI 问题 | 2 小时 | 1 天 | 样式错乱、非核心接口报错 |
| **Low (P3)** | 优化建议/文档/技术债 | 1 周 | 下个迭代 | 代码规范、注释缺失 |

### 6.2 缺陷生命周期
```
新建 → 确认 → 分配 → 修复中 → 待验证 → 验证通过 → 关闭
              ↓
         拒绝/延期 (需评估风险)
```

### 6.3 发布阻塞规则
- **P0/P1 未清零**：严禁发布
- **P2 遗留**：需风险评估 + 业务方签字确认可接受
- **回归缺陷**：同类缺陷复发，优先级自动升级

### 6.4 关键质量指标
| 指标 | 目标 | 统计频率 | 责任人 |
|------|------|----------|--------|
| 单元测试覆盖率 | ≥ 80% (核心 100%) | 每次构建 | 测试工程师 |
| 缺陷漏测率 | < 5% | 每版本 | QA Lead |
| 平均修复时间 (MTTR) | < 4 小时 (P0) | 月度 | 运维工程师 |
| 发布失败率 | < 10% | 月度 | 项目经理 |
| 冒烟测试通过率 | 100% | 每日 | 运维工程师 |

---

## 7. 持续改进

### 7.1 改进建议跟踪
| 改进项 | 现状痛点 | 建议措施 | 预期收益 | 负责人 | 计划完成 |
|--------|----------|----------|----------|--------|----------|
| 测试数据管理 | 手工造数耗时、环境污染 | 引入测试数据工厂、数据隔离 | 造数效率提升 80% | QA | v{版本} |
| 接口自动化覆盖 | 仅 60% 核心接口覆盖 | 补全契约测试、生成 Mock Server | 回归效率提升 50% | 后端 | v{版本} |
| 缺陷根因分析 | 分析不规范 | 引入 5Why 模板、强制关联代码变更 | 同类缺陷复发率降低 60% | QA/Tech Lead | v{版本} |
| 性能基线管理 | 无历史基线对比 | 建立性能基线库、自动对比告警 | 性能退化早发现 | 后端/运维 | v{版本} |
| Code Review 质量 | 审查深度不一 | 强制 Checklist、最小审查时长、质量考核 | 审查发现缺陷率提升 | Tech Lead | v{版本} |

### 7.2 角色职责
| 角色 | 职责 |
|------|------|
| **开发工程师** | 编写单元/集成测试、自测通过、修复 CI 失败、响应 Review 意见 |
| **QA** | 维护 E2E 测试、性能基线、安全扫描、缺陷管理、测试报告 |
| **Tech Lead** | 制定测试策略、把关 Review 质量、设定质量门禁、架构评审 |
| **DevOps** | 维护 CI 流水线、测试环境、监控告警、部署自动化 |
| **PM** | 验收标准确认、发布决策、遗留缺陷风险评估签字 |

---

## 8. 版本历史

| 版本 | 日期 | 变更说明 | 作者 |
|------|------|----------|------|
| 2.0.0 | 2026-10-07 | 合并 4 个质量文档为统一规范 | DevOps Lead |
| 1.0.0 | 2026-08-18 | 初版：测试策略、质量计划、报告模板、Review 清单 | Auto |

---

> **执行建议**：
> 1. 优先补全核心模块单元测试 (`config.py`、`douyin_sign.py`、`_request`、`fetch_and_store_*`)
> 2. 引入 Testcontainers 实现集成测试真实 Redis/Celery 依赖
> 3. 配置 Playwright E2E 覆盖 4 个核心用户流程
> 4. 接入 Codecov + Pact Broker 可视化覆盖率与契约状态
> 5. 强制 PR 模板包含 Code Review Checklist 核心项