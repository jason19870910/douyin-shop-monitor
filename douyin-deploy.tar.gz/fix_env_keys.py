with open('/opt/douyin-platform/src/backend/services/fetcher.py', 'r') as f:
    content = f.read()

# Fix env var names to match .env
content = content.replace("_read_secret('token', '__TOKEN')", "_read_secret('token', 'TOKEN')")
content = content.replace("_read_secret('verify_fp', 'verifyFp')", "_read_secret('verify_fp', 'VERIFY_FP')")
content = content.replace("_read_secret('fp', 'fp')", "_read_secret('fp', 'FP')")

with open('/opt/douyin-platform/src/backend/services/fetcher.py', 'w') as f:
    f.write(content)

print('Fixed env var names')