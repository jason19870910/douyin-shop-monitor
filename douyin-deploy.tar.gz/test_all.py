import sys
sys.path.insert(0, '/opt/douyin-platform/src/backend')

from services.fetcher import (
    fetch_and_store_products,
    fetch_and_store_orders,
    fetch_and_store_creators,
    fetch_and_store_creator_works,
    fetch_and_check_compliance,
    check_alerts,
)

print("=" * 60)
print("Testing all 6 data fetch functions...")
print("=" * 60)

# 1. Products
print("\n1. fetch_and_store_products (FXG 商品 API):")
result = fetch_and_store_products()
print("   Status: {}, Count: {}, Source: {}".format(result.get('status'), result.get('count', 0), result.get('data_source', 'N/A')))
if result.get('error_category'):
    print("   Error: {} - {}".format(result.get('error_category'), result.get('message', '')[:80]))

# 2. Orders
print("\n2. fetch_and_store_orders (FXG 订单 API):")
result = fetch_and_store_orders()
print("   Status: {}, Count: {}, Source: {}".format(result.get('status'), result.get('count', 0), result.get('data_source', 'N/A')))
if result.get('error_category'):
    print("   Error: {} - {}".format(result.get('error_category'), result.get('message', '')[:80]))

# 3. Creators
print("\n3. fetch_and_store_creators (本地账号缓存):")
result = fetch_and_store_creators()
print("   Status: {}, Count: {}, Source: {}".format(result.get('status'), result.get('count', 0), result.get('data_source', 'N/A')))
if result.get('error_category'):
    print("   Error: {} - {}".format(result.get('error_category'), result.get('message', '')[:80]))

# 4. Creator Works
print("\n4. fetch_and_store_creator_works (Creator 作品 API):")
result = fetch_and_store_creator_works()
print("   Status: {}, Count: {}, Source: {}".format(result.get('status'), result.get('count', 0), result.get('data_source', 'N/A')))
if result.get('error_category'):
    print("   Error: {} - {}".format(result.get('error_category'), result.get('message', '')[:80]))

# 5. Compliance
print("\n5. fetch_and_check_compliance (本地合规规则):")
result = fetch_and_check_compliance()
print("   Status: {}, Checked: {}, Violations: {}".format(result.get('status'), result.get('checked', 0), result.get('violations', 0)))

# 6. Alerts
print("\n6. check_alerts (本地告警检查):")
result = check_alerts()
print("   Status: {}, Alerts: {}".format(result.get('status'), result.get('alerts', 0)))

print("\n" + "=" * 60)