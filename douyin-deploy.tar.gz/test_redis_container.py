import socket
try:
    ip = socket.gethostbyname('redis')
    print('DNS resolve redis:', ip)
except Exception as e:
    print('DNS error:', e)

import redis
try:
    r = redis.Redis(host='redis', port=6379, socket_connect_timeout=5)
    print('Redis ping:', r.ping())
except Exception as e:
    print('Redis connect error:', e)