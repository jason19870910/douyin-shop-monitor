import os, requests, json

endpoint = "https://fxg.jinritemai.com/api/order/searchlist"
params = {
    "page": 0,
    "pageSize": 10,
    "order_by": "create_time",
    "order": "desc",
    "tab": "all",
    "appid": 1,
    "_bid": "ffa_order",
    "aid": 4272,
    "_lid": "606316310312",
    "__token": os.getenv("TOKEN"),
    "verifyFp": open("/run/secrets/verify_fp").read().strip(),
    "fp": open("/run/secrets/fp").read().strip(),
}

cookie_str = os.getenv('FXG_COOKIES', '')
cookies = {}
for pair in cookie_str.split(';'):
    if '=' in pair:
        k, v = pair.strip().split('=', 1)
        cookies[k] = v

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Referer": "https://fxg.jinritemai.com/ffa/order",
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-origin",
    "Sec-Ch-Ua": "Chromium;v=134, Not:A-Brand;v=24, Google Chrome;v=134",
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Ch-Ua-Platform": "Windows"
}

print("Testing with requests.get()...")
r = requests.get(endpoint, params=params, headers=headers, cookies=cookies, timeout=30)
print(f"Status: {r.status_code}")
print(f"Response length: {len(r.text)}")
print(f"First 200 chars: {r.text[:200]}")
print(f"Headers: {dict(r.headers)}")