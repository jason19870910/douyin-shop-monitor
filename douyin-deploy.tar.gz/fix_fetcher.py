import re

with open('/opt/douyin-platform/src/backend/services/fetcher.py', 'r') as f:
    content = f.read()

old = """    cookie_str = _read_secret('fxg_cookies', 'FXG_COOKIES')
    headers = {
        'User-Agent': Config.USER_AGENT,
    cookie_str = _read_secret('fxg_cookies', 'FXG_COOKIES')
    headers = {
        'User-Agent': Config.USER_AGENT,
        'Referer': 'https://fxg.jinritemai.com/order/list',
        'Cookie': cookie_str,
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        'X-Requested-With': 'XMLHttpRequest',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
    }

    result = _request(endpoint, params=params, headers=headers, method='GET')"""

new = """    cookie_str = _read_secret('fxg_cookies', 'FXG_COOKIES')
    headers = {
        'User-Agent': Config.USER_AGENT,
        'Referer': 'https://fxg.jinritemai.com/order/list',
        'Cookie': cookie_str,
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        'X-Requested-With': 'XMLHttpRequest',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
    }

    result = _request(endpoint, params=params, headers=headers, method='GET')"""

if old in content:
    content = content.replace(old, new)
    with open('/opt/douyin-platform/src/backend/services/fetcher.py', 'w') as f:
        f.write(content)
    print('Fixed successfully')
else:
    print('Pattern not found')