import re

with open('/etc/nginx/conf.d/default.conf', 'r') as f:
    content = f.read()

# Add resolver after server {
content = re.sub(r'(server \{)', r'\1\n    resolver 127.0.0.11 valid=10s;', content)

# Replace proxy_pass line with variable-based approach
old = 'proxy_pass http://douyin_monitor:5000;'
new = '        set $backend_host douyin_monitor;\n        set $backend_port 5000;\n        proxy_pass http://$backend_host:$backend_port;'
content = content.replace(old, new)

with open('/etc/nginx/conf.d/default.conf', 'w') as f:
    f.write(content)

print('Config updated')