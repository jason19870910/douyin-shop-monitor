import sys
sys.path.insert(0, '/opt/douyin-platform/src/backend')
from config import Config
from services.fetcher import _request, _read_secret, parse_cookies
import requests

# 订单列表 - 查看完整错误
fxg_cookie_str = _read_secret('fxg_cookies', 'FXG_COOKIES')
fxg_cookies = parse_cookies(fxg_cookie_str)
fxg_headers = {
    'User-Agent': Config.USER_AGENT,
    'Referer': 'https://fxg.jinritemai.com/order/order/list',
    'Accept': 'application/json, text/plain, */*',
}
endpoint = f'{Config.FXG_BASE_URL}/api/order/searchlist'
params = {'page': 0, 'pageSize': 10, 'order_by': 'create_time', 'order': 'desc', 'tab': 'all', 'appid': 1, '_bid': 'ffa_order', 'aid': Config.FXG_ORDER_AID}
result = _request(endpoint, params=params, headers=fxg_headers, cookies=fxg_cookies, skip_sign=True)
print('订单列表 full response:', str(result)[:500])
print()

# 创作者概览 - 查看完整响应
creator_cookie_str = _read_secret('creator_cookies', 'CREATOR_COOKIES')
creator_cookies = parse_cookies(creator_cookie_str)
creator_headers = {'User-Agent': Config.USER_AGENT, 'Referer': 'https://creator.douyin.com/', 'Accept': 'application/json, text/plain, */*', 'Content-Type': 'application/json'}
endpoint = f'{Config.CREATOR_BASE_URL}/janus/douyin/creator/data/overview/dashboard'
try:
    r = requests.post(endpoint, headers=creator_headers, json={'recent_days': 7}, cookies=creator_cookies, timeout=15)
    print('创作者概览 status:', r.status_code)
    print('创作者概览 response:', r.text[:500])
except Exception as e:
    print('创作者概览 exception:', e)

# 创作者作品
endpoint = Config.CREATOR_WORK_LIST_URL
params = {'status': '0', 'count': '12', 'max_cursor': '0', 'scene': 'star_atlas', 'device_platform': 'android', 'aid': Config.CREATOR_WORK_AID}
try:
    r = requests.get(endpoint, params=params, headers=creator_headers, cookies=creator_cookies, timeout=15)
    print('创作者作品 status:', r.status_code)
    print('创作者作品 response:', r.text[:500])
except Exception as e:
    print('创作者作品 exception:', e)
