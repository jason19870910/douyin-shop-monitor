import os
import requests

cookie_str = os.getenv('FXG_COOKIES', '')
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Referer': 'https://fxg.jinritemai.com/product/tproduct/list',
    'Cookie': cookie_str,
}

def test_params(page, page_size, label):
    print(f'=== {label} ===')
    resp = requests.get('https://fxg.jinritemai.com/product/tproduct/list', params={'page': page, 'pageSize': page_size}, headers=headers, timeout=30)
    print(f'Status: {resp.status_code}')
    result = resp.json()
    print(f'Keys: {list(result.keys())}')
    if 'data' in result:
        data = result['data']
        print(f'data type: {type(data)}')
        if isinstance(data, dict):
            print(f'data keys: {list(data.keys())}')
            if 'products' in data:
                print(f'products count: {len(data["products"])}')
                if data['products']:
                    print(f'First product keys: {list(data["products"][0].keys())}')
        elif isinstance(data, list):
            print(f'data list length: {len(data)}')
            if data:
                print(f'First item keys: {list(data[0].keys())}')

test_params(0, 10, 'page=0, pageSize=10')
print()
test_params(1, 10, 'page=1, pageSize=10')
print()
test_params(0, 1, 'page=0, pageSize=1 (current)')
print()
test_params(1, 1, 'page=1, pageSize=1')