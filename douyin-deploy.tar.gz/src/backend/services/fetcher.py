"""Shared data fetching service layer for both Celery tasks and Flask app."""
import json
import logging
import os
import random
import requests
import time
from datetime import datetime, timedelta
from pathlib import Path
from functools import wraps
from typing import Dict, Any, List, Optional, Tuple

logger = logging.getLogger(__name__)

# Load environment variables
from dotenv import load_dotenv
load_dotenv()

# Import config
from config import Config

# Import Redis cache - lazy initialization to avoid connection at module load
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

# Lazy cache getter - only initializes Redis connection when first accessed
_cache_instance = None

def _get_cache():
    """Get cache instance with lazy initialization."""
    global _cache_instance
    if _cache_instance is None:
        from redis_cache import get_cache
        _cache_instance = get_cache()
    return _cache_instance

# For backwards compatibility - property-like access
class _CacheProxy:
    def __getattr__(self, name):
        return getattr(_get_cache(), name)

cache = _CacheProxy()

# Cache keys
CACHE_KEYS = {
    'products': 'products',
    'orders': 'orders',
    'creators': 'creators',
    'videos': 'videos',
    'accounts': 'accounts',
    'compliance_rules': 'compliance_rules',
    'compliance_logs': 'compliance_logs',
    'media': 'media',
    'auth': 'auth',
    'creator_works': 'creator_works',
    'alert_config': 'alert_config',
    'alert_douyin_config': 'alert_douyin_config',
    'alert_dian_config': 'alert_dian_config',
    'alert_history': 'alert_history',
    'sync_history': 'sync_history',
    'auth_config': 'auth_config',
    'audit_log': 'audit_log',
}

# 映射文档API_SPEC.md中列出的典型 english_metric_name 到实际 API 返回的可能字段名
# 用于兼容不同版本的外部返回格式
METRIC_ALIASES = {
    'total_followers': ('total_fans_cnt', 'followers', 'fans_cnt'),
    'total_videos'  : ('publish_cnt', 'video_cnt', 'videos_cnt'),
    'total_views'   : ('play_cnt', 'total_views', 'view_cnt'),
    'total_likes'   : ('digg_cnt', 'likes', 'likes_cnt'),
    'total_comments': ('comment_cnt', 'comments', 'comment_count'),
    'total_shares'  : ('share_count', 'shares', 'share_cnt'),
    'recent_followers_gain': ('net_fans_cnt', 'follower_gain', 'new_fans'),
}

def _metric_value(metric_map: Dict[str, int], key: str) -> int:
    """根据英文名称从 metric_map 中查找对应的数值。
    
    先尝试精确匹配，再依据 METRIC_ALIASES 别名列表回退。
    若未找到则返回 0 并记录警告，便于排查。
    """
    # 1) 精确匹配
    if key in metric_map:
        return metric_map[key]
    # 2) 别名回退
    for alias in METRIC_ALIASES.get(key, (key,)):
        if alias in metric_map:
            return metric_map[alias]
    # 3) 未找到
    logger.warning(f"Creator overview metric '{key}' not found in API response, returning 0")
    return 0

# Data storage paths
DATA_DIR = Path(os.getenv('DATA_DIR', '/data'))
# Ensure data directory exists
DATA_DIR.mkdir(parents=True, exist_ok=True)

PRODUCTS_FILE = DATA_DIR / 'products.json'
ORDERS_FILE = DATA_DIR / 'orders.json'
CREATORS_FILE = DATA_DIR / 'creators.json'
VIDEOS_FILE = DATA_DIR / 'videos.json'
ACCOUNTS_FILE = DATA_DIR / 'accounts.json'
COMPLIANCE_FILE = DATA_DIR / 'compliance.json'
MEDIA_FILE = DATA_DIR / 'media.json'
AUTH_FILE = DATA_DIR / 'auth.json'
CREATOR_WORKS_FILE = DATA_DIR / 'creator_works.json'
ALERT_CONFIG_FILE = DATA_DIR / 'alert_config.json'
ALERT_DOUYIN_CONFIG_FILE = DATA_DIR / 'alert_douyin_config.json'
ALERT_DIAN_CONFIG_FILE = DATA_DIR / 'alert_dian_config.json'

# Default configurations
DEFAULT_ALERT_CONFIG = {
    'sales_drop_threshold': 0.3,
    'conversion_drop_threshold': 0.2,
    'inventory_low_threshold': 10,
    'notification_email': os.getenv('ALERT_EMAIL', ''),
    'enabled': True
}

DEFAULT_ALERT_DOUYIN_CONFIG = {
    'video_view_drop_threshold': 0.3,
    'video_like_drop_threshold': 0.2,
    'creator_follower_drop_threshold': 0.1,
    'notification_email': os.getenv('ALERT_EMAIL', ''),
    'enabled': True
}

DEFAULT_ALERT_DIAN_CONFIG = {
    'product_sales_drop_threshold': 0.3,
    'order_refund_rate_threshold': 0.15,
    'compliance_risk_threshold': 'medium',
    'notification_email': os.getenv('ALERT_EMAIL', ''),
    'enabled': True
}

DEFAULT_AUTH_CONFIG = {
    'douyin_app_id': '',
    'douyin_app_secret': '',
    'redirect_uri': '',
    'authorized': False,
    'access_token': '',
    'refresh_token': '',
    'expires_at': 0,
    'scope': []
}

DEFAULT_VIDEOS = []
DEFAULT_ACCOUNTS = []
DEFAULT_COMPLIANCE = []
DEFAULT_MEDIA = []


def _read_secret(secret_name: str, env_var: str = None, default: str = '') -> str:
    """Read secret from environment variable first, then Docker secret file, then default."""
    if env_var:
        env_val = os.getenv(env_var)
        if env_val is not None and env_val != '':
            return env_val
    secret_path = Path(f'/run/secrets/{secret_name}')
    if secret_path.exists():
        try:
            return secret_path.read_text().strip()
        except Exception:
            pass
    if env_var:
        return os.getenv(env_var, default)
    return default


def _read_secret_int(secret_name: str, env_var: str = None, default: int = 0) -> int:
    """Read integer secret from Docker secret file or environment variable."""
    val = _read_secret(secret_name, env_var, str(default))
    try:
        return int(val)
    except (ValueError, TypeError):
        return default


# HTTP 请求重试装饰器（指数退避 + 抖动）
def _http_retry(max_retries=3, base_delay=1.0, max_delay=10.0, timeout=30):
    """HTTP 请求重试装饰器（指数退避 + 抖动）"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except (requests.ConnectionError, requests.Timeout, requests.RequestException) as e:
                    last_exception = e
                    if attempt < max_retries - 1:
                        delay = min(base_delay * (2 ** attempt) + random.uniform(0, 1), max_delay)
                        logger.warning(f"HTTP 请求失败 (尝试 {attempt + 1}/{max_retries}): {e}, {delay:.2f}s 后重试")
                        time.sleep(delay)
                    else:
                        logger.error(f"HTTP 请求最终失败 (已重试 {max_retries} 次): {e}")
            raise last_exception
        return wrapper
    return decorator


def parse_cookies(cookie_str: str) -> dict:
    """Parse cookie string to dict."""
    cookies = {}
    if not cookie_str:
        return cookies
    for pair in cookie_str.split(';'):
        pair = pair.strip()
        if '=' in pair:
            k, v = pair.split('=', 1)
            cookies[k.strip()] = v.strip()
    return cookies


def get_fxg_cookies() -> dict:
    """Get fxg.jinritemai.com cookies."""
    cookie_str = _read_secret('fxg_cookies', 'FXG_COOKIES')
    return parse_cookies(cookie_str)


def get_creator_cookies() -> dict:
    """Get creator.douyin.com cookies."""
    cookie_str = _read_secret('creator_cookies', 'CREATOR_COOKIES')
    return parse_cookies(cookie_str)


def save_json_file(file_path: Path, data: Any) -> None:
    """Save data to JSON file."""
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"Failed to save JSON to {file_path}: {e}")


def load_json_file(
    file_path: Path, 
    default: Any = None, 
    model_type: Optional[str] = None
) -> Any:
    """Load JSON file with optional Pydantic validation, return default if not exists.
    
    Args:
        file_path: Path to JSON file
        default: Default value if file doesn't exist or validation fails
        model_type: Optional model type key from MODEL_MAP for validation
        
    Returns:
        Parsed and validated data, or default
    """
    if file_path.exists():
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Apply Pydantic validation if model_type provided
            if model_type:
                from models import validate_data, validate_single, MODEL_MAP
                if isinstance(data, list) and model_type in MODEL_MAP:
                    return validate_data(data, model_type)
                elif isinstance(data, dict) and model_type in MODEL_MAP:
                    return validate_single(data, model_type)
            
            return data
        except json.JSONDecodeError:
            logger.error(f"Failed to parse JSON from {file_path}")
            return default
        except Exception as e:
            logger.error(f"Validation failed for {file_path} (model_type={model_type}): {e}")
            return default
    return default


# ==================== Product Fetching ====================

@_http_retry(max_retries=3, base_delay=1.0, max_delay=10.0)
def _fetch_products_from_api() -> List[Dict[str, Any]]:
    """Fetch products from external FXG API."""
    logger.info("Fetching products from external FXG API...")
    
    endpoint = f"{Config.FXG_BASE_URL}/product/tproduct/list"
    base_params = {
        'page': 0,
        'pageSize': 20,
    }
    
    params = base_params
    
    cookie_str = os.getenv('FXG_COOKIES', '')
    headers = {
        'User-Agent': Config.USER_AGENT,
        'Referer': 'https://fxg.jinritemai.com/product/tproduct/list',
        'Cookie': cookie_str,
    }
    
    resp = requests.get(endpoint, params=params, headers=headers, timeout=30)
    resp.raise_for_status()
    result = resp.json()
    
    # 外部 API 实际返回格式：{ st, msg, code, data: [...], page, size, total }
    # data 是直接的产品列表，不是包含 products 键的字典
    data_block = result.get('data')
    if isinstance(data_block, list):
        products = data_block
    elif isinstance(data_block, dict):
        products = data_block.get('products', [])
    else:
        products = []
    
    logger.info(f"Fetched {len(products)} products from API (page={params['page']}, pageSize={params['pageSize']}, total={result.get('total', 'unknown')})")
    return products


def _classify_error(error: Exception) -> Dict[str, str]:
    """将异常分类为标准错误类型，便于监控和告警。
    
    Returns:
        Dict with 'error_type' and 'error_code' keys
    """
    error_msg = str(error).lower()
    
    # 外部 API 错误码分类（参考 API_SPEC.md）
    if any(code in error_msg for code in ['40101', '10008', 'cookie expired', 'cookie 过期', 'login required']):
        return {'error_type': 'COOKIE_EXPIRED', 'error_code': '40101'}
    if any(code in error_msg for code in ['40301', 'signature', '签名', 'sign error', 'a_bogus', 'msToken']):
        return {'error_type': 'SIGNATURE_ERROR', 'error_code': '40301'}
    if any(code in error_msg for code in ['429', 'rate limit', '限流', 'too many requests']):
        return {'error_type': 'RATE_LIMITED', 'error_code': '429'}
    if any(code in error_msg for code in ['10001010A', 'risk control', '风控']):
        return {'error_type': 'RISK_CONTROL', 'error_code': '10001010A'}
    if isinstance(error, requests.ConnectionError):
        return {'error_type': 'CONNECTION_ERROR', 'error_code': 'CONN_ERR'}
    if isinstance(error, requests.Timeout):
        return {'error_type': 'TIMEOUT', 'error_code': 'TIMEOUT'}
    if isinstance(error, requests.HTTPError):
        return {'error_type': 'HTTP_ERROR', 'error_code': str(error.response.status_code) if error.response else 'HTTP_ERR'}
    if isinstance(error, requests.RequestException):
        return {'error_type': 'EXTERNAL_API_ERROR', 'error_code': 'EXT_API_ERR'}
    
    return {'error_type': 'EXCEPTION', 'error_code': 'UNKNOWN'}


def fetch_and_store_products() -> Dict[str, Any]:
    """Fetch products from API and store in Redis + JSON file."""
    try:
        products = _fetch_products_from_api()
        
        # Transform and store
        for product in products:
            product['fetched_at'] = datetime.now().isoformat()
            product['sales_today'] = product.get('sales_today', 0)
            product['sales_yesterday'] = product.get('sales_yesterday', 0)
            product['inventory'] = product.get('inventory', 0)
            product['conversion_rate'] = product.get('conversion_rate', 0.0)
            product['conversion_rate_today'] = product.get('conversion_rate_today', 0.0)
            product['conversion_rate_yesterday'] = product.get('conversion_rate_yesterday', 0.0)
        
        # Store in Redis cache
        cache.set(CACHE_KEYS['products'], products)
        # Also save to JSON file for persistence
        save_json_file(PRODUCTS_FILE, products)
        logger.info(f"Fetched and stored {len(products)} products")
        
        return {'status': 'success', 'count': len(products)}
        
    except Exception as e:
        error_info = _classify_error(e)
        logger.error(f"Failed to fetch products: {e}", extra=error_info)
        return {
            'status': 'error', 
            'message': str(e),
            'error_type': error_info['error_type'],
            'error_code': error_info['error_code']
        }


# ==================== Order Fetching ====================

@_http_retry(max_retries=3, base_delay=5.0, max_delay=30.0)
def _fetch_orders_from_api() -> List[Dict[str, Any]]:
    """Fetch orders from external FXG API using _request with skip_sign=True.
    
    Per API spec: searchlist does NOT need a_bogus/msToken (short-lived, minutes).
    Only needs long-lived params: __token, verifyFp, fp.
    Uses skip_sign=True to prevent auto-injection of expired msToken/a_bogus.
    """
    logger.info("Fetching orders from external FXG API...")
    
    endpoint = f'{Config.FXG_BASE_URL}/api/order/searchlist'
    
    # 稳定签名参数（从配置读取，不随请求变化，不易过期）
    # __token、verifyFp、fp 为长效参数，直接加入请求参数
    # msToken、a_bogus 为强时效参数（几分钟失效），通过 skip_sign=True 跳过自动注入
    token = _read_secret('token', '__TOKEN')
    verify_fp = _read_secret('verify_fp', 'verifyFp')
    fp = _read_secret('fp', 'fp')
    
    base_params = {
        'page': 0,
        'pageSize': 10,
        'order_by': 'create_time',
        'order': 'desc',
        'tab': 'all',
        'appid': 1,
        '_bid': 'ffa_order',
        'aid': Config.FXG_ORDER_AID,
        '_lid': '606316310312',  # 使用实测有效的 _lid 值（用户浏览器抓包值）
    }
    # 追加稳定签名参数（仅当配置存在时）
    if token:
        base_params['__token'] = token
    if verify_fp:
        base_params['verifyFp'] = verify_fp
    if fp:
        base_params['fp'] = fp
    
    cookie_str = os.getenv('FXG_COOKIES', '')
    cookies = {}
    if cookie_str:
        for pair in cookie_str.split(';'):
            if '=' in pair:
                k, v = pair.strip().split('=', 1)
                cookies[k] = v
    
    # 使用完整的浏览器指纹头部，模拟真实浏览器请求以获取丰富数据
    # 参考浏览器抓包：包含 Sec-Fetch-*, Sec-Ch-Ua*, Priority, 详细 Referer 等
    headers = {
        **Config.COMMON_HEADERS,
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'Accept-Encoding': 'gzip, deflate',
        'Referer': 'https://fxg.jinritemai.com/ffa/order',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Ch-Ua': '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Ch-Ua-Platform': '"Windows"',
    }
    
    # 使用 _request 并设置 skip_sign=True，避免自动注入过期的 msToken/a_bogus
    # 这是按 API 规范要求的：searchlist 不需要动态签名
    result = _request(
        endpoint=endpoint,
        params=base_params,
        headers=headers,
        cookies=cookies,
        method='GET',
        skip_sign=True  # 关键：跳过 a_bogus/msToken 自动注入
    )
    
    # _request 失败时返回 {'data': {}, 'error': ...}，需检查
    if isinstance(result, dict) and result.get('error'):
        raise requests.RequestException(f"External API error: {result.get('error')}")
    
    # 兼容不同的返回结构
    if isinstance(result, list):
        orders = result
    elif isinstance(result, dict):
        data_block = result.get('data')
        if isinstance(data_block, list):
            orders = data_block
        elif isinstance(data_block, dict):
            orders = data_block.get('orders', [])
        else:
            orders = result.get('orders', [])
    else:
        orders = []
    return orders


def fetch_and_store_orders() -> Dict[str, Any]:
    """Fetch orders from API and store in Redis + JSON file."""
    try:
        orders = _fetch_orders_from_api()
        
        # Transform and store
        for order in orders:
            order['fetched_at'] = datetime.now().isoformat()
        
        # Store in Redis cache
        cache.set(CACHE_KEYS['orders'], orders)
        # Also save to JSON file for persistence
        save_json_file(ORDERS_FILE, orders)
        logger.info(f"Fetched and stored {len(orders)} orders")
        
        return {'status': 'success', 'count': len(orders)}
        
    except Exception as e:
        error_info = _classify_error(e)
        logger.error(f"Failed to fetch orders: {e}", extra=error_info)
        return {
            'status': 'error', 
            'message': str(e),
            'error_type': error_info['error_type'],
            'error_code': error_info['error_code']
        }


# ==================== Creator Fetching ====================

@_http_retry(max_retries=3, base_delay=1.0, max_delay=10.0)
def _fetch_creators_from_api() -> List[Dict[str, Any]]:
    """Fetch creators from external Creator API.
    
    Per API spec: Creator center MUST use cookies dict parameter (requests cookies=),
    NOT Cookie header string. Parse cookie string to dict first.
    """
    logger.info("Fetching creators from external Creator API...")
    
    url = f'{Config.CREATOR_BASE_URL}/janus/douyin/creator/data/overview/dashboard'
    payload = {"recent_days": 7}
    cookie_str = os.getenv('CREATOR_COOKIES', '')
    
    # Parse cookie string to dict (required for creator.douyin.com endpoints)
    cookies = {}
    if cookie_str:
        for pair in cookie_str.split(';'):
            if '=' in pair:
                k, v = pair.strip().split('=', 1)
                cookies[k] = v
    
    headers = {
        'User-Agent': Config.USER_AGENT,
        'Referer': 'https://creator.douyin.com/',
        'Accept': 'application/json, text/plain, */*',
        'Content-Type': 'application/json',
    }
    
    response = requests.post(url, headers=headers, json=payload, cookies=cookies, timeout=30)
    response.raise_for_status()
    result = response.json()
    
    # 外部 API 返回 metrics 数组，需解析映射到 creators 列表格式
    # 兼容旧格式：data.creators 以及新格式：metrics 数组
    if 'creators' in result.get('data', {}):
        return result['data']['creators']
    
    metrics = result.get('metrics') or result.get('data', {}).get('metrics', [])
    if not metrics:
        return []
    
    # 将 metrics 数组转换为单个 creator 信息 dict
    metric_map = {m.get('english_metric_name'): m.get('metric_value', 0) for m in metrics}
    creator_info = {
        'total_followers'    : _metric_value(metric_map, 'total_followers'),
        'total_videos'       : _metric_value(metric_map, 'total_videos'),
        'total_views'        : _metric_value(metric_map, 'total_views'),
        'total_likes'        : _metric_value(metric_map, 'total_likes'),
        'total_comments'     : _metric_value(metric_map, 'total_comments'),
        'total_shares'       : _metric_value(metric_map, 'total_shares'),
        'recent_followers_gain': _metric_value(metric_map, 'recent_followers_gain'),
    }
    return [creator_info]


@_http_retry(max_retries=3, base_delay=1.0, max_delay=10.0)
def _fetch_creator_overview_from_api(recent_days: int = 7) -> Dict[str, Any]:
    """Fetch creator overview from external Creator API.
    
    Per API spec: Creator center MUST use cookies dict parameter (requests cookies=),
    NOT Cookie header string. Parse cookie string to dict first.
    """
    logger.info(f"Fetching creator overview from external Creator API (recent_days={recent_days})...")

    url = f'{Config.CREATOR_BASE_URL}/janus/douyin/creator/data/overview/dashboard'
    payload = {"recent_days": recent_days}
    cookie_str = os.getenv('CREATOR_COOKIES', '')
    
    # Parse cookie string to dict (required for creator.douyin.com endpoints)
    cookies = {}
    if cookie_str:
        for pair in cookie_str.split(';'):
            if '=' in pair:
                k, v = pair.strip().split('=', 1)
                cookies[k] = v

    headers = {
        'User-Agent': Config.USER_AGENT,
        'Referer': 'https://creator.douyin.com/',
        'Accept': 'application/json, text/plain, */*',
        'Content-Type': 'application/json',
    }

    response = requests.post(url, headers=headers, json=payload, cookies=cookies, timeout=30)
    response.raise_for_status()
    result = response.json()

    # 外部 API 实际返回格式：{ metrics: [{english_metric_name, metric_name, metric_value, trends}, ...] }
    # 兼容旧格式：{ code: 0, data: { total_followers, total_videos, recent_view, recent_like } }
    if 'total_followers' in result.get('data', {}):
        data = result.get('data', {})
        return {
            'total_followers': data.get('total_followers', 0),
            'total_videos': data.get('total_videos', 0),
            'recent_view': data.get('recent_view', 0),
            'recent_like': data.get('recent_like', 0),
        }
    
    metrics = result.get('metrics') or result.get('data', {}).get('metrics', [])
    if not metrics:
        return {
            'total_followers': 0,
            'total_videos': 0,
            'recent_view': 0,
            'recent_like': 0,
            'total_views': 0,
            'total_likes': 0,
            'total_comments': 0,
            'total_shares': 0,
            'recent_followers_gain': 0,
        }
    
    # 将 metrics 数组转换为 dict
    metric_map = {m.get('english_metric_name'): m.get('metric_value', 0) for m in metrics}
    return {
        'total_followers': metric_map.get('total_fans_cnt', 0),
        'total_videos': metric_map.get('publish_cnt', 0),
        'total_views': metric_map.get('play_cnt', 0),
        'total_likes': metric_map.get('digg_cnt', 0),
        'total_comments': metric_map.get('comment_cnt', 0),
        'total_shares': metric_map.get('share_count', 0),
        'recent_view': metric_map.get('play_cnt', 0),  # 兼容旧字段名
        'recent_like': metric_map.get('digg_cnt', 0),  # 兼容旧字段名
        'recent_followers_gain': metric_map.get('net_fans_cnt', 0),
    }


def fetch_and_store_creators() -> Dict[str, Any]:
    """Fetch creators from API and store in Redis + JSON file."""
    try:
        creators = _fetch_creators_from_api()
        
        # Ensure each creator has fetched_at timestamp
        for creator in creators:
            creator['fetched_at'] = datetime.now().isoformat()
        
        # Store in Redis cache
        cache.set(CACHE_KEYS['creators'], creators)
        # Also save to JSON file for persistence
        save_json_file(CREATORS_FILE, creators)
        logger.info(f"Fetched and stored {len(creators)} creators")
        
        return {'status': 'success', 'count': len(creators)}
        
    except Exception as e:
        error_info = _classify_error(e)
        logger.error(f"Failed to fetch creators: {e}", extra=error_info)
        return {
            'status': 'error', 
            'message': str(e),
            'error_type': error_info['error_type'],
            'error_code': error_info['error_code']
        }


# ==================== Creator Works Fetching ====================

@_http_retry(max_retries=3, base_delay=1.0, max_delay=10.0)
def _fetch_creator_works_from_api() -> List[Dict[str, Any]]:
    """Fetch creator works from external Creator API.
    
    Per API spec: Creator center works list MUST use cookies dict parameter (requests cookies=),
    NOT Cookie header string. Parse cookie string to dict first.
    """
    logger.info("Fetching creator works from external Creator API...")
    
    endpoint = Config.CREATOR_WORK_LIST_URL
    params = {
        'status': '0',
        'count': '12',
        'max_cursor': '0',
        'scene': 'star_atlas',
        'device_platform': 'android',
        'aid': Config.CREATOR_WORK_AID,
    }
    cookie_str = os.getenv('CREATOR_COOKIES', '')
    
    # Parse cookie string to dict (required for creator.douyin.com endpoints)
    cookies = {}
    if cookie_str:
        for pair in cookie_str.split(';'):
            if '=' in pair:
                k, v = pair.strip().split('=', 1)
                cookies[k] = v
    
    headers = {
        'User-Agent': Config.USER_AGENT,
        'Referer': 'https://creator.douyin.com/creator-micro/content/manage',
        'Accept': 'application/json, text/plain, */*',
    }
    
    resp = requests.get(endpoint, params=params, headers=headers, cookies=cookies, timeout=30)
    resp.raise_for_status()
    result = resp.json()
    
    # 兼容不同的返回结构：aweme_list / data / works
    works = result.get('aweme_list') or result.get('items') or []
    if isinstance(works, dict):
        works = works.get('works', [])
    return works


def fetch_and_store_creator_works() -> Dict[str, Any]:
    """Fetch creator works from API and store in Redis + JSON file."""
    try:
        works = _fetch_creator_works_from_api()
        
        # Transform and store
        for work in works:
            work['fetched_at'] = datetime.now().isoformat()
        
        # Store in Redis cache
        cache.set(CACHE_KEYS['creator_works'], works)
        # Also save to JSON file for persistence
        save_json_file(CREATOR_WORKS_FILE, works)
        logger.info(f"Fetched and stored {len(works)} creator works")
        
        return {'status': 'success', 'count': len(works)}
        
    except Exception as e:
        error_info = _classify_error(e)
        logger.error(f"Failed to fetch creator works: {e}", extra=error_info)
        return {
            'status': 'error', 
            'message': str(e),
            'error_type': error_info['error_type'],
            'error_code': error_info['error_code']
        }


# ==================== Compliance Fetching ====================

def fetch_and_check_compliance() -> Dict[str, Any]:
    """Fetch compliance data and run checks."""
    logger.info("Running compliance checks...")
    
    # This is a placeholder - in production, fetch from actual compliance API
    # For now, we just return success
    logger.info("Compliance check completed")
    return {'status': 'success', 'message': 'Compliance check completed'}


# ==================== Alert Checking ====================

def get_alert_config() -> Dict[str, Any]:
    """Get current alert configuration from Redis cache."""
    config = cache.get(CACHE_KEYS['alert_config'])
    if config is None:
        return DEFAULT_ALERT_CONFIG
    return config


def check_alerts() -> Dict[str, Any]:
    """Check alert conditions and send notifications if needed."""
    alert_config = get_alert_config()
    
    if not alert_config.get('enabled', True):
        return {'status': 'skipped', 'reason': 'alerts disabled'}
    
    logger.info("Checking alert conditions...")
    
    products = cache.get(CACHE_KEYS['products'], [])
    alerts_triggered = []
    
    for product in products:
        product_name = product.get('product_name', 'Unknown')
        product_id = product.get('product_id', '')
        
        # Check sales drop
        sales_today = product.get('sales_today', 0)
        sales_yesterday = product.get('sales_yesterday', 0)
        
        if sales_yesterday > 0:
            drop_rate = (sales_yesterday - sales_today) / sales_yesterday
            if drop_rate >= alert_config['sales_drop_threshold']:
                alert = {
                    'type': 'sales_drop',
                    'product_id': product_id,
                    'product_name': product_name,
                    'message': f"Product {product_name} sales dropped by {drop_rate:.1%}",
                    'drop_rate': drop_rate,
                    'threshold': alert_config['sales_drop_threshold'],
                    'timestamp': datetime.now().isoformat()
                }
                alerts_triggered.append(alert)
                save_alert_to_history(alert)
                send_alert_notification(alert)

        # Check inventory
        inventory = product.get('inventory', 0)
        if inventory <= alert_config['inventory_low_threshold']:
            alert = {
                'type': 'low_inventory',
                'product_id': product_id,
                'product_name': product_name,
                'message': f"Product {product_name} inventory low: {inventory}",
                'inventory': inventory,
                'threshold': alert_config['inventory_low_threshold'],
                'timestamp': datetime.now().isoformat()
            }
            alerts_triggered.append(alert)
            save_alert_to_history(alert)
            send_alert_notification(alert)

        # Check conversion rate drop
        conv_today = product.get('conversion_rate_today', 0)
        conv_yesterday = product.get('conversion_rate_yesterday', 0)

        if conv_yesterday > 0:
            drop_rate = (conv_yesterday - conv_today) / conv_yesterday
            if drop_rate >= alert_config['conversion_drop_threshold']:
                alert = {
                    'type': 'conversion_drop',
                    'product_id': product_id,
                    'product_name': product_name,
                    'message': f"Product {product_name} conversion rate dropped by {drop_rate:.1%}",
                    'drop_rate': drop_rate,
                    'threshold': alert_config['conversion_drop_threshold'],
                    'timestamp': datetime.now().isoformat()
                }
                alerts_triggered.append(alert)
                save_alert_to_history(alert)
                send_alert_notification(alert)
    
    logger.info(f"Alert check completed. Triggered {len(alerts_triggered)} alerts")
    return {'status': 'success', 'alerts_triggered': len(alerts_triggered)}


def send_alert_notification(alert: Dict[str, Any]) -> None:
    """Send alert notification via WeChat Work webhook and email."""
    from utils.notifications import send_alert_notification as _send

    alert_config = get_alert_config()
    email = alert_config.get('notification_email')

    try:
        _send(alert, email=email)
    except Exception as e:
        logger.error(f"Failed to send alert notification: {e}")


# ==================== Alert History ====================

def save_alert_to_history(alert: Dict[str, Any]) -> None:
    """Persist triggered alert to history list in Redis cache."""
    history = cache.get(CACHE_KEYS['alert_history'], [])
    if not isinstance(history, list):
        history = []
    # Prepend new alert (most recent first)
    history.insert(0, alert)
    # Keep only last 500 alerts to avoid memory bloat
    if len(history) > 500:
        history = history[:500]
    cache.set(CACHE_KEYS['alert_history'], history)


def get_alert_history(
    limit: int = 50,
    offset: int = 0,
    alert_type: str = None,
) -> Dict[str, Any]:
    """Get paginated alert history with optional type filter."""
    history = cache.get(CACHE_KEYS['alert_history'], [])
    if not isinstance(history, list):
        history = []

    # Filter by type if specified
    if alert_type:
        history = [a for a in history if a.get('type') == alert_type]

    total = len(history)
    # Paginate
    paginated = history[offset:offset + limit]

    return {
        'list': paginated,
        'total': total,
        'limit': limit,
        'offset': offset,
    }


def clear_alert_history() -> int:
    """Clear all alert history. Returns count of cleared alerts."""
    history = cache.get(CACHE_KEYS['alert_history'], [])
    count = len(history) if isinstance(history, list) else 0
    cache.set(CACHE_KEYS['alert_history'], [])
    return count


# ==================== Data Initialization ====================

def init_compliance_data() -> None:
    """Initialize compliance data (rules, logs, mock data)."""
    from models import validate_data
    
    # Initialize compliance rules if not exists
    existing_rules = cache.get(CACHE_KEYS['compliance_rules'])
    if not existing_rules:
        mock_rules = [
            {
                'id': 'rule_001',
                'rule_name': '广告法禁用词检测',
                'rule_type': 'KEYWORD',
                'rule_content': {'keywords': ['最', '第一', '顶级', '极佳', '绝对', '全网', '全国', '世界级', '顶尖', '巅峰', '史无前例', '永久', '根治', '彻底', '特效', '神效', '祖传', '秘方', '独家', '专利', '专利技术', '填补空白']},
                'severity': 'HIGH',
                'category': '广告法',
                'enabled': True,
                'created_at': datetime.now().isoformat(),
                'updated_at': datetime.now().isoformat()
            },
            {
                'id': 'rule_002',
                'rule_name': '价格承诺合规',
                'rule_type': 'PRICE',
                'rule_content': {'max_price_ratio': 1.5, 'min_price_ratio': 0.5},
                'severity': 'MEDIUM',
                'category': '价格监管',
                'enabled': True,
                'created_at': datetime.now().isoformat(),
                'updated_at': datetime.now().isoformat()
            },
            {
                'id': 'rule_003',
                'rule_name': '资质证照有效性',
                'rule_type': 'LICENSE',
                'rule_content': {'required_licenses': ['营业执照', '食品经营许可证', '化妆品备案凭证']},
                'severity': 'HIGH',
                'category': '资质合规',
                'enabled': True,
                'created_at': datetime.now().isoformat(),
                'updated_at': datetime.now().isoformat()
            }
        ]
        validated_rules = validate_data(mock_rules, 'compliance_rules')
        cache.set(CACHE_KEYS['compliance_rules'], validated_rules)
        save_json_file(COMPLIANCE_FILE, validated_rules)
        logger.info(f"Initialized {len(validated_rules)} compliance rules")
    
    # Initialize compliance logs if not exists
    existing_logs = cache.get(CACHE_KEYS['compliance_logs'])
    if not existing_logs:
        mock_logs = [
            {
                'id': 'log_001',
                'rule_id': 'rule_001',
                'target_type': 'product',
                'target_id': 'mock_p_001',
                'target_name': '模拟商品-爆款T恤',
                'status': 'pass',
                'details': {'matched_keywords': [], 'checked_fields': ['product_name', 'description']},
                'checked_at': (datetime.now() - timedelta(hours=2)).isoformat()
            },
            {
                'id': 'log_002',
                'rule_id': 'rule_001',
                'target_type': 'product',
                'target_id': 'mock_p_002',
                'target_name': '模拟商品-无线耳机',
                'status': 'fail',
                'details': {'matched_keywords': ['最'], 'checked_fields': ['product_name', 'description']},
                'checked_at': (datetime.now() - timedelta(hours=5)).isoformat()
            }
        ]
        validated_logs = validate_data(mock_logs, 'compliance_logs')
        cache.set(CACHE_KEYS['compliance_logs'], validated_logs)
        logger.info(f"Initialized {len(validated_logs)} compliance logs")


def load_all_data() -> None:
    """Load all data files into Redis cache with Pydantic validation."""
    # Load data into Redis cache (list types with automatic validation)
    data_map = {
        'products': (PRODUCTS_FILE, []),
        'orders': (ORDERS_FILE, []),
        'creators': (CREATORS_FILE, []),
        'videos': (VIDEOS_FILE, DEFAULT_VIDEOS),
        'accounts': (ACCOUNTS_FILE, DEFAULT_ACCOUNTS),
        'compliance_rules': (COMPLIANCE_FILE, DEFAULT_COMPLIANCE),
        'media': (MEDIA_FILE, DEFAULT_MEDIA),
        'auth': (AUTH_FILE, DEFAULT_AUTH_CONFIG),
        'creator_works': (CREATOR_WORKS_FILE, []),
    }
    
    for key, (file_path, default) in data_map.items():
        data = load_json_file(file_path, default, model_type=key)
        cache.set(CACHE_KEYS[key], data)
    
    # Load configs into Redis (dict types with automatic validation)
    config_map = {
        'alert_config': (ALERT_CONFIG_FILE, DEFAULT_ALERT_CONFIG),
        'alert_douyin_config': (ALERT_DOUYIN_CONFIG_FILE, DEFAULT_ALERT_DOUYIN_CONFIG),
        'alert_dian_config': (ALERT_DIAN_CONFIG_FILE, DEFAULT_ALERT_DIAN_CONFIG),
        'auth_config': (AUTH_FILE, DEFAULT_AUTH_CONFIG),
    }
    
    for key, (file_path, default) in config_map.items():
        data = load_json_file(file_path, default, model_type=key)
        cache.set(CACHE_KEYS[key], data)
    
    cache.set('last_update', datetime.now().isoformat())
    
    # Initialize compliance data
    init_compliance_data()
    
    logger.info("All data loaded successfully with Pydantic validation")


def save_all_data() -> None:
    """Save all cached data from Redis to JSON files."""
    save_json_file(PRODUCTS_FILE, cache.get(CACHE_KEYS['products'], []))
    save_json_file(ORDERS_FILE, cache.get(CACHE_KEYS['orders'], []))
    save_json_file(CREATORS_FILE, cache.get(CACHE_KEYS['creators'], []))
    save_json_file(VIDEOS_FILE, cache.get(CACHE_KEYS['videos'], []))
    save_json_file(ACCOUNTS_FILE, cache.get(CACHE_KEYS['accounts'], []))
    save_json_file(COMPLIANCE_FILE, cache.get(CACHE_KEYS['compliance_rules'], []))
    save_json_file(MEDIA_FILE, cache.get(CACHE_KEYS['media'], []))
    save_json_file(AUTH_FILE, cache.get(CACHE_KEYS['auth'], []))
    save_json_file(CREATOR_WORKS_FILE, cache.get(CACHE_KEYS['creator_works'], []))
    save_json_file(ALERT_CONFIG_FILE, cache.get(CACHE_KEYS['alert_config'], {}))
    save_json_file(ALERT_DOUYIN_CONFIG_FILE, cache.get(CACHE_KEYS['alert_douyin_config'], {}))
    save_json_file(ALERT_DIAN_CONFIG_FILE, cache.get(CACHE_KEYS['alert_dian_config'], {}))
    logger.info("All data saved successfully")


# ==================== Scheduled Job ====================

# 分布式锁配置
SYNC_LOCK_KEY = "douyin:monitor:sync:lock"
SYNC_LOCK_TTL = 300  # 5 分钟锁过期时间（防止死锁）


def _acquire_sync_lock() -> bool:
    """尝试获取同步分布式锁（基于 Redis SET NX EX）。
    
    Returns:
        True 如果获取锁成功，False 如果锁已被占用
    """
    try:
        # 使用 SET key value NX EX 实现原子加锁
        result = cache._client.set(SYNC_LOCK_KEY, "1", nx=True, ex=SYNC_LOCK_TTL)
        if result:
            logger.info("Acquired sync lock")
            return True
        else:
            logger.warning("Sync lock already held by another process, skipping this run")
            return False
    except Exception as e:
        logger.error(f"Failed to acquire sync lock: {e}")
        # 锁获取失败时，为了不阻塞业务，允许继续执行（但记录警告）
        return True


def _release_sync_lock() -> None:
    """释放同步分布式锁。"""
    try:
        cache._client.delete(SYNC_LOCK_KEY)
        logger.info("Released sync lock")
    except Exception as e:
        logger.error(f"Failed to release sync lock: {e}")


def _check_and_log_auth_errors(results: Dict[str, Any]) -> None:
    """检测 AUTH_ERROR (Cookie 失效) 并仅记录日志（方式 2：最保守）。
    
    此函数不修改 os.environ，不重新执行任务，仅在日志中标记
    哪些服务出现了 Cookie 失效，留给运维人工介入。
    
    Args:
        results: scheduled_job() 返回的各任务结果字典
    """
    auth_services = []
    
    for key, result in (results or {}).items():
        if isinstance(result, dict):
            # _classify_error 返回的 error_type 包含 'COOKIE_EXPIRED' 等
            error_type = result.get('error_type', '')
            error_code = result.get('error_code', '')
            if error_type in ('AUTH_ERROR', 'COOKIE_EXPIRED'):
                auth_services.append({
                    'service': key,
                    'error_code': error_code,
                    'message': result.get('message', '')[:120]
                })
    
    if auth_services:
        logger.warning(
            f"Cookie 失效检测: {len(auth_services)} 个服务需要人工介入",
            extra={
                'event': 'cookie_expired_detected',
                'affected_services': [s['service'] for s in auth_services],
                'error_codes': [s['error_code'] for s in auth_services],
                'require_action': 'manual_refresh_cookies',
                'auto_mode': 'log_only_way2'
            }
        )
        # 此处仅记录日志，不自动刷新 os.environ，
        # 不重新执行任务，留给运维人工判断是否需要介入
    # 如果没有 AUTH_ERROR/COOKIE_EXPIRED，静默返回，不影响流程


def scheduled_job() -> Dict[str, Any]:
    """Main scheduled job to fetch all data and check alerts.
    This function is called by Celery Beat tasks.
    
    使用分布式锁防止并发执行（Celery Beat + 手动触发 /api/v1/sync 可能并发）。
    """
    # 尝试获取分布式锁
    if not _acquire_sync_lock():
        return {
            'status': 'skipped',
            'reason': 'another_sync_in_progress',
            'message': 'Another sync task is already running, skipping this execution'
        }
    
    logger.info("Running scheduled job...")
    start_time = datetime.now()

    results = {}
    results['products'] = fetch_and_store_products()
    results['orders'] = fetch_and_store_orders()
    results['creators'] = fetch_and_store_creators()
    results['creator_works'] = fetch_and_store_creator_works()
    results['compliance'] = fetch_and_check_compliance()
    results['alerts'] = check_alerts()
    
    # 【P1】方式 2：检测 AUTH_ERROR 并仅记录日志（不自动刷新）
    _check_and_log_auth_errors(results)

    end_time = datetime.now()
    duration_ms = int((end_time - start_time).total_seconds() * 1000)
    cache.set('last_update', end_time.isoformat())

    # 释放锁
    _release_sync_lock()

    # 计算整体状态
    overall_status = _calculate_overall_status(results)

    # Record sync history
    _save_sync_history({
        'timestamp': end_time.isoformat(),
        'duration_ms': duration_ms,
        'status': overall_status,
        'trigger': 'scheduled',
        'details': {
            'products': _extract_status(results.get('products')),
            'orders': _extract_status(results.get('orders')),
            'creators': _extract_status(results.get('creators')),
            'creator_works': _extract_status(results.get('creator_works')),
            'compliance': _extract_status(results.get('compliance')),
            'alerts': _extract_status(results.get('alerts')),
        },
    })

    logger.info("Scheduled job completed in %dms with status: %s", duration_ms, overall_status)
    return {'status': overall_status, 'results': results, 'duration_ms': duration_ms}


def _calculate_overall_status(results: Dict[str, Any]) -> str:
    """根据各子任务结果计算整体同步状态。
    
    Returns:
        'success' - 全部成功
        'partial' - 部分成功部分失败
        'failed' - 全部失败
    """
    statuses = [_extract_status(r) for r in results.values()]
    success_count = sum(1 for s in statuses if s == 'success')
    error_count = sum(1 for s in statuses if s == 'error')
    
    if error_count == 0:
        return 'success'
    elif success_count == 0:
        return 'failed'
    else:
        return 'partial'


def _extract_status(result: Any) -> str:
    """Extract status string from fetch result."""
    if isinstance(result, dict):
        return result.get('status', 'unknown')
    return 'unknown'


def _save_sync_history(record: Dict[str, Any]) -> None:
    """Persist sync record to history list in Redis cache."""
    history = cache.get(CACHE_KEYS['sync_history'], [])
    if not isinstance(history, list):
        history = []
    history.insert(0, record)
    # Keep last 100 sync records
    if len(history) > 100:
        history = history[:100]
    cache.set(CACHE_KEYS['sync_history'], history)


def get_sync_history(limit: int = 20, offset: int = 0) -> Dict[str, Any]:
    """Get paginated sync history."""
    history = cache.get(CACHE_KEYS['sync_history'], [])
    if not isinstance(history, list):
        history = []
    total = len(history)
    paginated = history[offset:offset + limit]
    return {
        'list': paginated,
        'total': total,
        'limit': limit,
        'offset': offset,
    }


# ==================== Mock Data (DEBUG only) ====================

def _load_mock_data() -> Dict[str, Any]:
    """Load mock data from fixtures (only used when DEBUG=True)."""
    # Import from fixtures only in DEBUG mode
    import os
    if os.getenv('DEBUG', '').lower() not in ('1', 'true', 'yes'):
        return {}
    
    try:
        from tests.fixtures.mock_data import (
            MOCK_PRODUCTS,
            MOCK_ORDERS,
            MOCK_CREATORS,
            MOCK_VIDEOS,
            MOCK_ACCOUNTS,
            MOCK_COMPLIANCE,
            MOCK_MEDIA,
        )
        logger.info("DEBUG mode: Loading mock data from fixtures")
        return {
            'products': MOCK_PRODUCTS,
            'orders': MOCK_ORDERS,
            'creators': MOCK_CREATORS,
            'videos': MOCK_VIDEOS,
            'accounts': MOCK_ACCOUNTS,
            'compliance_rules': MOCK_COMPLIANCE,
            'media': MOCK_MEDIA,
        }
    except ImportError:
        logger.warning("Mock data fixtures not found")
        return {}


def get_mock_data(key: str) -> List[Dict[str, Any]]:
    """Get mock data for a specific key (only in DEBUG mode)."""
    import os
    if os.getenv('DEBUG', '').lower() not in ('1', 'true', 'yes'):
        return []
    
    mock_data = _load_mock_data()
    return mock_data.get(key, [])


# Provide mock data constants for backward compatibility (only in DEBUG)
import os
if os.getenv('DEBUG', '').lower() in ('1', 'true', 'yes'):
    try:
        from tests.fixtures.mock_data import (
            MOCK_PRODUCTS,
            MOCK_ORDERS,
            MOCK_CREATORS,
        )
    except ImportError:
        MOCK_PRODUCTS = []
        MOCK_ORDERS = []
        MOCK_CREATORS = []
else:
    MOCK_PRODUCTS = []
    MOCK_ORDERS = []
    MOCK_CREATORS = []


def get_data_with_fallback(cache_key: str, mock_data: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], str]:
    """
    Get data from cache, fall back to mock data if cache is empty.
    Only returns mock data in DEBUG mode.
    
    Returns:
        tuple: (data_list, data_source) where data_source is 'real' or 'mock'
    """
    import os
    is_debug = os.getenv('DEBUG', '').lower() in ('1', 'true', 'yes')
    
    data = cache.get(CACHE_KEYS.get(cache_key, cache_key), [])
    if data and len(data) > 0:
        return data, 'real'
    
    # Only return mock data in DEBUG mode
    if is_debug and mock_data:
        return mock_data, 'mock'
    
    return [], 'empty'


# ==================== External Request Forwarder ====================

def _request(endpoint: str, params: dict = None, headers: dict = None, cookies: dict = None,
             method: str = 'GET', json: dict = None, data: str = None, data_headers: dict = None,
             skip_sign: bool = False) -> dict:
    """通用 HTTP 请求转发器，支持 GET/POST，带签名、重试和统一错误处理。
    
    用于将 Flask 蓝图中的请求转发到外部 API（fxg/creator 等）。
    失败时返回包含 'data' 空字典和 'error' 字段的响应，调用方可通过 result.get('data', {}) 安全降级。
    
    Args:
        skip_sign: 跳过签名注入，用于 searchlist 等不需要动态签名的端点
    """
    params = params or {}
    headers = headers or {}
    cookies = cookies or {}
    
    # 仅对 fxg.jinritemai.com 域名做签名（searchlist 等端点不需要签名，设置 skip_sign=True）
    if 'fxg.jinritemai.com' in endpoint and not skip_sign:
        try:
            from douyin_sign import sign_request
            existing_tokens = {
                '__token': _read_secret('token', '__TOKEN'),
                'msToken': _read_secret('ms_token', 'MS_TOKEN'),
                'verifyFp': _read_secret('verify_fp', 'verifyFp'),
                'fp': _read_secret('fp', 'fp'),
            }
            sign_params = sign_request(endpoint, params, existing_tokens, Config.USER_AGENT)
            params = {**params, **sign_params}
        except Exception as e:
            logger.warning(f"签名失败，继续无签名请求: {e}")
    
    try:
        method = (method or 'GET').upper()
        merged_headers = headers.copy()
        if data_headers:
            merged_headers.update(data_headers)
        if method == 'POST':
            # 优先用 json=，否则用 data=
            if json is not None:
                resp = requests.post(endpoint, params=params, json=json, headers=merged_headers, cookies=cookies, timeout=30)
            elif data is not None:
                resp = requests.post(endpoint, params=params, data=data, headers=merged_headers, cookies=cookies, timeout=30)
            else:
                resp = requests.post(endpoint, params=params, headers=merged_headers, cookies=cookies, timeout=30)
        else:
            resp = requests.get(endpoint, params=params, headers=merged_headers, cookies=cookies, timeout=30)
        resp.raise_for_status()
        return resp.json()
    except requests.RequestException as e:
        logger.error(f"_request 请求失败: {endpoint} - {e}")
        return {'data': {}, 'error': str(e)}
    except ValueError as e:
        logger.error(f"_request JSON 解析失败: {endpoint} - {e}")
        return {'data': {}, 'error': str(e)}


# ==================== Generic Config Access ====================

_CONFIG_DEFAULTS: Dict[str, Dict[str, Any]] = {
    'alert_config': DEFAULT_ALERT_CONFIG,
    'alert_douyin_config': DEFAULT_ALERT_DOUYIN_CONFIG,
    'alert_dian_config': DEFAULT_ALERT_DIAN_CONFIG,
    'auth_config': DEFAULT_AUTH_CONFIG,
}

_CONFIG_FILES: Dict[str, Path] = {
    'alert_config': ALERT_CONFIG_FILE,
    'alert_douyin_config': ALERT_DOUYIN_CONFIG_FILE,
    'alert_dian_config': ALERT_DIAN_CONFIG_FILE,
    'auth_config': AUTH_FILE,
}


def get_config(key: str) -> Dict[str, Any]:
    """从 Redis 缓存获取配置，缺失时返回对应的默认配置。"""
    value = cache.get(CACHE_KEYS.get(key, key))
    if value is None:
        return _CONFIG_DEFAULTS.get(key, {}).copy()
    return value


def set_config(key: str, value: Dict[str, Any]) -> None:
    """保存配置到 Redis 缓存，并持久化到对应的 JSON 文件。"""
    cache.set(CACHE_KEYS.get(key, key), value)
    file_path = _CONFIG_FILES.get(key)
    if file_path:
        save_json_file(file_path, value)


def get_mock_status() -> Dict[str, Any]:
    """获取各数据源的状态（real/mock/empty）以及 DEBUG 模式开关。"""
    import os
    is_debug = os.getenv('DEBUG', '').lower() in ('1', 'true', 'yes')
    
    sources = ['products', 'orders', 'creators', 'videos', 'accounts', 'creator_works']
    status: Dict[str, Any] = {}
    for key in sources:
        data = cache.get(CACHE_KEYS.get(key, key), [])
        if data and len(data) > 0:
            status[key] = 'real'
        elif is_debug:
            status[key] = 'mock'
        else:
            status[key] = 'empty'
    status['debug_mode'] = is_debug
    return status