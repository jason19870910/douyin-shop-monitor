import { apiClient } from '@/utils/apiClient';

// Re-export types from apiClient
export type { NormalizedError } from '@/utils/apiClient';

// 通用响应格式 - 前后端统一返回结构
export interface ApiResponse<T = unknown> {
  success?: boolean;
  data?: T;
  message?: string;
  error?: string;
}

// 分页响应格式 - 用于 /api/products, /api/creators 等返回的结构
// 后端返回: { data: { items: T[], total: number, page?: number, size?: number }, success, message, error }
// 前端使用时通过 .data 获取 { items, total, page, size }
export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page?: number;
  size?: number;
}

// 订单
export interface Order {
  order_id: string;
  product_id: string;
  product_name: string;
  quantity: number;
  amount: number;
  status: string;
  create_time: string;
  pay_time?: string;
  [key: string]: unknown;
}

// 账户
export interface Account {
  account_id: string;
  account_name: string;
  account_type: string;
  phone: string;
  email: string;
  status: string;
  last_login: string | null;
  create_time: string;
  [key: string]: unknown;
}

// 创作者统计数据接口
export interface CreatorOverviewData {
  // 基础概览字段
  total_followers: number;        // 总粉丝数
  total_videos: number;           // 近期投稿量（7天）
  recent_view: number;            // 近期播放量（7天）
  recent_like: number;            // 近期点赞数（7天）
  
  // 互动详情（7天聚合）
  recent_share: number;           // 近期分享数
  recent_comment: number;         // 近期评论数
  recent_homepage_view: number;   // 近期主页访问
  
  // 粉丝变化（7天聚合）
  net_followers_gain: number;     // 净增粉丝
  cancel_followers: number;       // 取关粉丝
  
  // 视频质量指标（7天聚合）
  completion_rate_5s: number;     // 5秒完播率
  bounce_rate_2s: number;         // 2秒跳出率
  avg_view_second: number;        // 平均播放时长(秒)
  cover_click_ratio: number;      // 封面点击率
  
  // 兼容字段（实际为近期7天数据）
  total_views: number;            // 兼容：近期总播放
  total_likes: number;            // 兼容：近期总点赞
  total_comments: number;         // 兼容：近期总评论
  total_shares: number;           // 兼容：近期总分享
  
  // 元数据
  data_source?: string;           // 数据来源
  recent_days?: number;           // 统计天数
}

// 创作者作品
export interface CreatorWork {
  work_id: string;
  title?: string;
  name?: string;
  creator_name?: string;
  creator_id: string;
  cover_url?: string;
  cover?: string;
  play_count?: number;
  like_count?: number;
  comment_count?: number;
  share_count?: number;
  status?: number;
  create_time?: string;
  update_time?: string;
  duration?: number;
  video_url?: string;
  fetched_at?: string;
  [key: string]: unknown;
}

// 视频
export interface Video {
  video_id: string;
  title: string;
  creator_name: string;
  play_count: number;
  like_count: number;
  comment_count: number;
  share_count: number;
  status: string;
  create_time: string;
  [key: string]: unknown;
}

// 合规商品
export interface ComplianceItem {
  product_id: string;
  product_name: string;
  risk_level: 'high' | 'medium' | 'low';
  violation_type: string;
  violation_detail: string;
  detected_at: string;
  status: 'pending' | 'ignored' | 'resolved';
  compliance_score?: number;
  violations?: ComplianceViolation[];
  check_batch_id?: string;
  ignored_at?: string;
  resolved_at?: string;
  restored_at?: string;
  resolution?: string;
  [key: string]: unknown;
}

// 合规违规
export interface ComplianceViolation {
  rule_id: string;
  rule_name: string;
  violation_type: string;
  violation_detail: string;
  matched_keywords: string[];
  severity: string;
  category: string;
}

// 合规规则
export interface ComplianceRule {
  rule_id: string;
  rule_name: string;
  rule_type: string;
  keywords: string[];
  severity: 'high' | 'medium' | 'low';
  category: string;
  enabled: boolean;
  created_at: string;
  updated_at: string;
  [key: string]: unknown;
}

// 合规规则历史
export interface ComplianceLog {
  log_id: string;
  rule_id: string;
  action: 'create' | 'update' | 'delete' | 'enable' | 'disable';
  old_value?: Record<string, unknown>;
  new_value?: Record<string, unknown>;
  operator: string;
  created_at: string;
  [key: string]: unknown;
}

// 合规统计
export interface ComplianceStats {
  total_products: number;
  checked_products: number;
  compliance_rate: number;
  pass_count: number;
  warning_count: number;
  fail_count: number;
  status_distribution: Record<string, number>;
  risk_distribution: Record<string, number>;
  total_checked: number;
  total_violations: number;
  pass_rate: number;
}

// 合规检查结果
export interface ComplianceCheckResult {
  batch_id: string;
  total_checked: number;
  total_violations: number;
  results: {
    product_id: string;
    product_name: string;
    compliance_status: string;
    compliance_score: number;
    violations: Array<{
      rule_id: string;
      rule_name: string;
      violation_type: string;
      violation_detail: string;
      matched_keywords: string[];
      severity: string;
      category: string;
    }>;
    violation_count: number;
    checked_at: string;
    rules_checked: number;
  };
  checked: number;
  pass: number;
  warning: number;
  fail: number;
}

// 媒体项
export interface MediaItem {
  media_id: string;
  type: 'video' | 'image';
  title: string;
  status: string;
  source_url: string;
  output_url: string;
  create_time: string;
  [key: string]: unknown;
}

// 告警配置
export interface AlertConfig {
  sales_drop_threshold?: number;
  conversion_drop_threshold?: number;
  inventory_low_threshold?: number;
  notification_email?: string;
  enabled?: boolean;
  video_view_drop_threshold?: number;
  video_like_drop_threshold?: number;
  creator_follower_drop_threshold?: number;
  product_sales_drop_threshold?: number;
  order_refund_rate_threshold?: number;
  compliance_risk_threshold?: string;
}

// 告警历史
export interface AlertHistoryItem {
  type: string;
  product_id: string;
  product_name: string;
  message: string;
  drop_rate?: number;
  inventory?: number;
  threshold?: number;
  timestamp: string;
}

// 告警统计接口
export interface AlertStats {
  total: number;
  by_type: Record<string, number>;
}

// 同步历史
export interface SyncHistoryItem {
  timestamp: string;
  duration_ms: number;
  status: 'success' | 'failed';
  trigger: 'scheduled' | 'manual';
  details?: Record<string, string>;
  error?: string;
}

// 认证状态
export interface AuthStatus {
  douyin_app_id: string;
  douyin_app_secret: string;
  redirect_uri: string;
  authorized: boolean;
  access_token: string;
  refresh_token: string;
  expires_at: number;
  scope: string[];
}

// 仪表盘统计
export interface DashboardStats {
  total_sales_today: number;
  total_sales_yesterday: number;
  total_revenue_today: number;
  total_revenue_yesterday: number;
  total_orders_today: number;
  total_orders_yesterday: number;
  avg_conversion_rate: number;
  avg_conversion_rate_yesterday: number;
  sales_trend: Array<{ date: string; sales: number }> | string;
  top_products: Product[];
  data_source?: 'real' | 'mock' | 'cache';
  products?: { total: number; on_sale?: number; avg_conversion_rate_yesterday?: number };
  orders?: { total: number; total_amount?: number };
  creators?: { total: number; total_followers?: number };
  videos?: { total: number; total_views?: number };
}

// 商品（用于DashboardStats.top_products）
export interface Product {
  product_id: string;
  product_name: string;
  category?: string;
  price: number;
  sales_today: number;
  sales_yesterday: number;
  inventory: number;
  conversion_rate: number;
  status?: string;
  fetched_at?: string;
  [key: string]: unknown;
}

// Mock状态
export interface MockStatusItem {
  is_mock: boolean;
  elapsed_minutes: number;
  alert_threshold: number;
  alert_triggered: boolean;
  alert_sent: boolean;
}

export interface MockStatus {
  products: MockStatusItem;
  orders: MockStatusItem;
  creators: MockStatusItem;
}

// 健康检查响应
export interface HealthResponse {
  status: string;
  last_update: string;
  timestamp: string;
}

/** Wrapper used by dashboardApi.getStats */
export type DashboardStatsResponse = ApiResponse<DashboardStats> | DashboardStats;

/** Wrapper used by other APIs that return direct data */
export type CreatorOverviewResponse = ApiResponse<CreatorOverviewData>;

// Mock状态响应类型
export type MockStatusResponse = ApiResponse<MockStatus> | MockStatus;

// 产品API
export const productApi = {
  getList: (params?: Record<string, unknown>) =>
    apiClient.get<ApiResponse<PaginatedResponse<Product>>>('/products', { params }).then((res) => res.data?.data),
  getStats: (params?: Record<string, unknown>) =>
    apiClient.get<ApiResponse<{ data: Record<string, unknown> }>>('/products/stats', { params }).then((res) => res.data?.data),
  getDetail: (id: string) =>
    apiClient.get<ApiResponse<Product>>(`/products/${id}`).then((res) => res.data?.data),
  create: (data: Partial<Product>) =>
    apiClient.post<ApiResponse<Product>>('/products', data).then((res) => res.data?.data),
  update: (id: string, data: Partial<Product>) =>
    apiClient.put<ApiResponse<Product>>(`/products/${id}`, data).then((res) => res.data?.data),
  delete: (id: string) =>
    apiClient.delete<ApiResponse<unknown>>(`/products/${id}`).then((res) => res.data?.data),
};

// 创作者API
export const creatorApi = {
  getList: (params?: Record<string, unknown>) =>
    apiClient.get<ApiResponse<PaginatedResponse<CreatorWork>>>('/creators', { params }).then((res) => res.data?.data),
  getOverview: (params?: Record<string, unknown>) =>
    apiClient.get<ApiResponse<CreatorOverviewData>>('/creators/overview', { params }).then((res) => res.data?.data),
  getExternalWorks: (params?: Record<string, unknown>) =>
    apiClient.get<ApiResponse<PaginatedResponse<CreatorWork>>>('/creators/works/external', { params }).then((res) => res.data?.data),
  getWorks: (params?: Record<string, unknown>) =>
    apiClient.get<ApiResponse<PaginatedResponse<CreatorWork>>>('/creators/works', { params }).then((res) => res.data?.data),
  getDetail: (id: string) =>
    apiClient.get<ApiResponse<CreatorWork>>(`/creators/${id}`).then((res) => res.data?.data),
  create: (data: Partial<CreatorWork>) =>
    apiClient.post<ApiResponse<CreatorWork>>('/creators', data).then((res) => res.data?.data),
  update: (id: string, data: Partial<CreatorWork>) =>
    apiClient.put<ApiResponse<CreatorWork>>(`/creators/${id}`, data).then((res) => res.data?.data),
  delete: (id: string) =>
    apiClient.delete<ApiResponse<unknown>>(`/creators/${id}`).then((res) => res.data?.data),
};

// 订单API
export const orderApi = {
  getList: (params?: Record<string, unknown>) =>
    apiClient.get<ApiResponse<PaginatedResponse<Order>>>('/orders', { params }).then((res) => res.data?.data),
  getStats: () =>
    apiClient.get<ApiResponse<Record<string, unknown>>>('/orders/stats').then((res) => res.data?.data),
  getDetail: (id: string) =>
    apiClient.get<ApiResponse<Order>>(`/orders/${id}`).then((res) => res.data?.data),
  create: (data: Partial<Order>) =>
    apiClient.post<ApiResponse<Order>>('/orders', data).then((res) => res.data?.data),
  update: (id: string, data: Partial<Order>) =>
    apiClient.put<ApiResponse<Order>>(`/orders/${id}`, data).then((res) => res.data?.data),
  delete: (id: string) =>
    apiClient.delete<ApiResponse<unknown>>(`/orders/${id}`).then((res) => res.data?.data),
};

// 健康检查API
export const healthApi = {
  check: () => apiClient.get<ApiResponse<HealthResponse>>('/health').then((res) => res.data?.data),
  getHealth: () => apiClient.get<ApiResponse<HealthResponse>>('/health').then((res) => res.data?.data),
};

// 同步API
export const syncApi = {
  manualSync: (asyncMode = false) => apiClient.post<ApiResponse<{ success: boolean }>>('/sync/manual', { params: { async: asyncMode } }).then((res) => res.data?.data),
  getHistory: (params?: Record<string, unknown>) =>
    apiClient.get<ApiResponse<PaginatedResponse<SyncHistoryItem>>>('/sync/history', { params }).then((res) => res.data?.data),
};

// Dashboard API
export const dashboardApi = {
  getStats: (params?: Record<string, unknown>) =>
    apiClient.get<ApiResponse<DashboardStats>>('/dashboard/stats', { params }).then((res) => res.data?.data),
  getMockStatus: () => apiClient.get<ApiResponse<MockStatus>>('/mock/status').then((res) => res.data?.data),
};

// 合规API
export const complianceApi = {
  getList: (params?: Record<string, unknown>) =>
    apiClient.get<ApiResponse<PaginatedResponse<ComplianceItem>>>('/compliance', { params }).then((res) => res.data?.data),
  ignore: (id: string) =>
    apiClient.post<ApiResponse<ComplianceItem>>(`/compliance/${id}/ignore`).then((res) => res.data?.data),
  takeDown: (id: string) =>
    apiClient.post<ApiResponse<ComplianceItem>>(`/compliance/${id}/take-down`).then((res) => res.data?.data),
  restore: (id: string) =>
    apiClient.post<ApiResponse<ComplianceItem>>(`/compliance/${id}/restore`).then((res) => res.data?.data),
  getStats: () =>
    apiClient.get<ApiResponse<ComplianceStats>>('/compliance/stats').then((res) => res.data?.data),
  triggerCheck: () =>
    apiClient.post<ApiResponse<ComplianceCheckResult>>('/compliance/check').then((res) => res.data?.data),
  export: (params?: Record<string, unknown>) =>
    apiClient.get('/compliance/export', { params, responseType: 'blob' }).then((res) => res.data),
  getRules: () =>
    apiClient.get<ApiResponse<ComplianceRule[]>>('/compliance/rules').then((res) => res.data?.data),
  createRule: (rule: Partial<ComplianceRule>) =>
    apiClient.post<ApiResponse<ComplianceRule>>('/compliance/rules', rule).then((res) => res.data?.data),
  updateRule: (id: string, rule: Partial<ComplianceRule>) =>
    apiClient.put<ApiResponse<ComplianceRule>>(`/compliance/rules/${id}`, rule).then((res) => res.data?.data),
  deleteRule: (id: string) =>
    apiClient.delete<ApiResponse<unknown>>(`/compliance/rules/${id}`).then((res) => res.data?.data),
  getRuleHistory: (id: string) =>
    apiClient.get<ApiResponse<ComplianceLog[]>>(`/compliance/rules/${id}/history`).then((res) => res.data?.data),
};

// 媒体API
export const mediaApi = {
  getVideoEditList: (params?: Record<string, unknown>) =>
    apiClient.get<ApiResponse<PaginatedResponse<MediaItem>>>('/media/video-edit', { params }).then((res) => res.data?.data),
  getImageEditList: (params?: Record<string, unknown>) =>
    apiClient.get<ApiResponse<PaginatedResponse<MediaItem>>>('/media/image-edit', { params }).then((res) => res.data?.data),
  create: (data: Partial<MediaItem>) =>
    apiClient.post<ApiResponse<MediaItem>>('/media', data).then((res) => res.data?.data),
  update: (id: string, data: Partial<MediaItem>) =>
    apiClient.put<ApiResponse<MediaItem>>(`/media/${id}`, data).then((res) => res.data?.data),
  delete: (id: string) =>
    apiClient.delete<ApiResponse<unknown>>(`/media/${id}`).then((res) => res.data?.data),
};

// 告警API
export const alertDouyinApi = {
  getConfig: () => apiClient.get<ApiResponse<AlertConfig>>('/alerts/douyin/config').then((res) => res.data?.data),
  updateConfig: (alertConfig: AlertConfig) =>
    apiClient.post<ApiResponse<AlertConfig>>('/alerts/douyin/config', alertConfig).then((res) => res.data?.data),
};

export const alertDianApi = {
  getConfig: () => apiClient.get<ApiResponse<AlertConfig>>('/alerts/dian/config').then((res) => res.data?.data),
  updateConfig: (alertConfig: AlertConfig) =>
    apiClient.post<ApiResponse<AlertConfig>>('/alerts/dian/config', alertConfig).then((res) => res.data?.data),
};

// 视频API
export const videoApi = {
  getList: (params?: Record<string, unknown>) =>
    apiClient.get<ApiResponse<PaginatedResponse<Video>>>('/videos', { params }).then((res) => res.data?.data),
  getDetail: (id: string) =>
    apiClient.get<ApiResponse<Video>>(`/videos/${id}`).then((res) => res.data?.data),
  create: (data: Partial<Video>) =>
    apiClient.post<ApiResponse<Video>>('/videos', data).then((res) => res.data?.data),
  update: (id: string, data: Partial<Video>) =>
    apiClient.put<ApiResponse<Video>>(`/videos/${id}`, data).then((res) => res.data?.data),
  delete: (id: string) =>
    apiClient.delete<ApiResponse<unknown>>(`/videos/${id}`).then((res) => res.data?.data),
};

// 账户API
export const accountApi = {
  getList: (params?: Record<string, unknown>) =>
    apiClient.get<ApiResponse<PaginatedResponse<Account>>>('/accounts', { params }).then((res) => res.data?.data),
  getDetail: (id: string) =>
    apiClient.get<ApiResponse<Account>>(`/accounts/${id}`).then((res) => res.data?.data),
  create: (data: Partial<Account>) =>
    apiClient.post<ApiResponse<Account>>('/accounts', data).then((res) => res.data?.data),
  update: (id: string, data: Partial<Account>) =>
    apiClient.put<ApiResponse<Account>>(`/accounts/${id}`, data).then((res) => res.data?.data),
  delete: (id: string) =>
    apiClient.delete<ApiResponse<unknown>>(`/accounts/${id}`).then((res) => res.data?.data),
};

// 认证API
export const authApi = {
  getStatus: () =>
    apiClient.get<ApiResponse<AuthStatus>>('/auth/status').then((res) => res.data?.data),
  login: () =>
    apiClient.get<ApiResponse<{ auth_url: string }>>('/auth/login').then((res) => res.data?.data),
  logout: () =>
    apiClient.post<ApiResponse<unknown>>('/auth/logout').then((res) => res.data?.data),
  getQrCode: () =>
    apiClient.get<ApiResponse<{ auth_url: string }>>('/auth/qr-code').then((res) => res.data?.data),
};

// 导出认证辅助函数
export { setAuthToken, getAuthToken } from '@/utils/apiClient';

// 告警API
export const alertApi = {
  getConfig: () =>
    apiClient.get<ApiResponse<AlertConfig>>('/alerts/config').then((res) => res.data?.data),
  updateConfig: (config: AlertConfig) =>
    apiClient.post<ApiResponse<AlertConfig>>('/alerts/config', config).then((res) => res.data?.data),
  getHistory: (params?: Record<string, unknown>) =>
    apiClient.get<ApiResponse<PaginatedResponse<AlertHistoryItem>>>('/alerts/history', { params }).then((res) => res.data?.data),
  getStats: () =>
    apiClient.get<ApiResponse<AlertStats>>('/alerts/history/stats').then((res) => res.data?.data),
  clearHistory: () =>
    apiClient.post<ApiResponse<{ cleared: number }>>('/alerts/clear-history').then((res) => res.data?.data),
};

// Default export for backward compatibility
export default apiClient;