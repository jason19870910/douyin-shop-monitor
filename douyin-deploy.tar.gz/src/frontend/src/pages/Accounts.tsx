import { useMemo } from 'react';
import { formatDate } from '@/utils/formatters';
import { accountApi, type Account } from '@/api/index';
import { DataTable, type DataTableColumn } from '@/components/common';
import { queryKeys } from '@/hooks';

const Accounts = () => {
  const columns = useMemo<DataTableColumn<Account>[]>(() => [
    {
      title: '账户ID',
      dataIndex: 'account_id',
      key: 'account_id',
      width: 120,
    },
    {
      title: '账户名称',
      dataIndex: 'account_name',
      key: 'account_name',
      width: 200,
    },
    {
      title: '账户类型',
      dataIndex: 'account_type',
      key: 'account_type',
      width: 120,
    },
    {
      title: '手机号',
      dataIndex: 'phone',
      key: 'phone',
      width: 150,
    },
    {
      title: '邮箱',
      dataIndex: 'email',
      key: 'email',
      width: 180,
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: (value: unknown) => {
        const status = value as string;
        const colors: Record<string, string> = { active: '#52c41a', suspended: '#fa8c16', banned: '#f5222d' };
        const labels: Record<string, string> = { active: '正常', suspended: '暂停', banned: '封禁' };
        return (
          <span
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              padding: '2px 8px',
              borderRadius: 4,
              background: `${colors[status] || '#8c8c8c'}15`,
              color: colors[status] || '#8c8c8c',
              fontWeight: 500,
              fontSize: 12,
            }}
          >
            {labels[status] || status}
          </span>
        );
      },
    },
    {
      title: '最后登录',
      dataIndex: 'last_login',
      key: 'last_login',
      width: 160,
      render: (value: unknown) => formatDate(value as string | null | undefined),
    },
    {
      title: '创建时间',
      dataIndex: 'create_time',
      key: 'create_time',
      width: 160,
      render: (value: unknown) => formatDate(value as string | null | undefined),
    },
  ], []);

  return (
    <DataTable<Account>
      title="账户管理"
      queryKey={queryKeys.accounts.list({})}
      queryFn={(params) => accountApi.getList(params) as Promise<{ items: Account[]; total: number }>}
      columns={columns}
      rowKey="account_id"
      search={{ placeholder: '搜索账户ID/名称...' }}
      exportConfig={{
        filenamePrefix: 'accounts',
        columns: [
          { key: 'account_id', label: '账户ID' },
          { key: 'account_name', label: '账户名称' },
          { key: 'account_type', label: '账户类型' },
          { key: 'phone', label: '手机号' },
          { key: 'email', label: '邮箱' },
          { key: 'status', label: '状态' },
          { key: 'last_login', label: '最后登录' },
          { key: 'create_time', label: '创建时间' },
        ],
      }}
    />
  );
};

export default Accounts;