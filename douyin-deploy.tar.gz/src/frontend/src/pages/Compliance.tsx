import { useMemo } from 'react';
import { formatNumber, formatDate } from '@/utils/formatters';
import { complianceApi, type ComplianceItem } from '@/api/index';
import { DataTable, type DataTableColumn } from '@/components/common';
import { queryKeys } from '@/hooks';

const Compliance = () => {
  const columns = useMemo<DataTableColumn<ComplianceItem>[]>(() => [
    {
      title: '商品ID',
      dataIndex: 'product_id',
      key: 'product_id',
      width: 120,
    },
    {
      title: '商品名称',
      dataIndex: 'product_name',
      key: 'product_name',
      width: 240,
      ellipsis: true,
    },
    {
      title: '风险等级',
      dataIndex: 'risk_level',
      key: 'risk_level',
      width: 100,
      render: (value: unknown) => {
        const level = value as 'high' | 'medium' | 'low';
        const colorMap = { high: 'red', medium: 'orange', low: 'green' };
        const labelMap = { high: '高风险', medium: '中风险', low: '低风险' };
        return (
          <span
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              padding: '2px 8px',
              borderRadius: 4,
              background: `${colorMap[level]}15`,
              color: colorMap[level],
              fontWeight: 500,
              fontSize: 12,
            }}
          >
            {labelMap[level]}
          </span>
        );
      },
    },
    {
      title: '违规类型',
      dataIndex: 'violation_type',
      key: 'violation_type',
      width: 160,
    },
    {
      title: '违规详情',
      dataIndex: 'violation_detail',
      key: 'violation_detail',
      width: 280,
    },
    {
      title: '检测时间',
      dataIndex: 'detected_at',
      key: 'detected_at',
      width: 160,
      render: (value: unknown) => formatDate(value as string | null | undefined),
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: (value: unknown) => {
        const status = value as 'pending' | 'ignored' | 'resolved';
        const colorMap = { pending: 'orange', ignored: 'gray', resolved: 'green' };
        const labelMap = { pending: '待处理', ignored: '已忽略', resolved: '已处理' };
        return (
          <span
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              padding: '2px 8px',
              borderRadius: 4,
              background: `${colorMap[status]}15`,
              color: colorMap[status],
              fontWeight: 500,
              fontSize: 12,
            }}
          >
            {labelMap[status]}
          </span>
        );
      },
    },
    {
      title: '合规评分',
      dataIndex: 'compliance_score',
      key: 'compliance_score',
      width: 100,
      align: 'right',
      render: (value: unknown) => {
        const score = value as number | undefined;
        return score !== undefined ? formatNumber(score) + '分' : '-';
      },
    },
    {
      title: '操作',
      dataIndex: '',
      key: 'actions',
      width: 120,
      render: (_value: unknown, _record: ComplianceItem) => { // eslint-disable-line @typescript-eslint/no-unused-vars
        return (
          <>
            <span
              onClick={() => {}}
              style={{ padding: '2px 6px', borderRadius: 4, marginRight: 4, background: '#1890ff15', color: '#1890ff', fontSize: 12, cursor: 'pointer' }}
              title="忽略"
            >
              <svg style={{ marginRight: 4, fontSize: 12 }} viewBox="0 0 1024 1024"><path d="M168 336h688l-8-208H168z"/></svg>忽略
            </span>
            <span
              onClick={() => {}}
              style={{ padding: '2px 6px', borderRadius: 4, marginRight: 4, background: '#f5222d15', color: '#f5222d', fontSize: 12, cursor: 'pointer' }}
              title="下架"
            >
              <svg style={{ marginRight: 4, fontSize: 12 }} viewBox="0 0 1024 1024"><path d="M404 188l-80 584h536l-80-584H404zM96 552l32-196h96l-32-196H96zM96 276l32 196h448l-32-196H96z"/></svg>下架
            </span>
          </>
        );
      },
    },
  ], []);

  return (
    <DataTable<ComplianceItem>
      title="合规管理"
      queryKey={queryKeys.compliance.list({})}
      queryFn={(params) => complianceApi.getList(params) as Promise<{ items: ComplianceItem[]; total: number }>}
      columns={columns}
      rowKey="product_id"
      search={{ placeholder: '搜索商品/违规内容...' }}
      exportConfig={{
        filenamePrefix: 'compliance',
        columns: [
          { key: 'product_id', label: '商品ID' },
          { key: 'product_name', label: '商品名称' },
          { key: 'risk_level', label: '风险等级' },
          { key: 'violation_type', label: '违规类型' },
          { key: 'violation_detail', label: '违规详情' },
          { key: 'detected_at', label: '检测时间' },
          { key: 'status', label: '状态' },
          { key: 'compliance_score', label: '合规评分' },
        ],
      }}
      showDataSourceSwitch={false}
    />
  );
};

export default Compliance;