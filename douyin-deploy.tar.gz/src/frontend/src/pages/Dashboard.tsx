import { useMemo } from 'react';
import { DataTable, type DataTableColumn } from '@/components/common';
import { formatDate } from '@/utils/formatters';
import { dashboardApi, type Product } from '@/api/index';
import { queryKeys } from '@/hooks';

const Dashboard = () => {
  const columns = useMemo<DataTableColumn<Product>[]>(() => [
    { title: '商品ID', dataIndex: 'product_id', key: 'product_id', width: 120 },
    { title: '商品名称', dataIndex: 'product_name', key: 'product_name', width: 240, ellipsis: true },
    { title: '价格', dataIndex: 'price', key: 'price', width: 100, align: 'right' },
    { title: '销量', dataIndex: 'sales_today', key: 'sales_today', width: 80, align: 'right' },
    { title: '更新时间', dataIndex: 'fetched_at', key: 'fetched_at', width: 140, render: (value: unknown) => formatDate(value as string | null | undefined) },
  ], []);

  return (
    <DataTable<Product>
      title="概览"
      queryKey={queryKeys.dashboard.stats({})}
      queryFn={(params) => dashboardApi.getStats(params).then(res => ({ items: res?.top_products || [], total: res?.top_products?.length || 0 })) as Promise<{ items: Product[]; total: number }>}
      columns={columns}
      rowKey="product_id"
      exportConfig={{
        filenamePrefix: 'dashboard',
        columns: [
          { key: 'product_id', label: '商品ID' },
          { key: 'product_name', label: '商品名称' },
          { key: 'price', label: '价格' },
          { key: 'sales_today', label: '销量' },
          { key: 'fetched_at', label: '更新时间' },
        ],
      }}
    />
  );
};

export default Dashboard;