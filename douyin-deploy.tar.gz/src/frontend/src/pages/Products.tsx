import { useMemo } from 'react';
import { formatNumber, formatCurrency, formatPercent, formatDate } from '@/utils/formatters';
import { productApi, type Product } from '@/api/index';
import { DataTable, type DataTableColumn } from '@/components/common';
import { queryKeys } from '@/hooks';

const productImageStyle = { width: 48, height: 48, objectFit: 'cover' as const, borderRadius: 4 };

const Products = () => {
  const columns = useMemo<DataTableColumn<Product>[]>(() => [
    {
      title: '商品ID',
      dataIndex: 'product_id',
      key: 'product_id',
      width: 120,
    },
    {
      title: '封面',
      dataIndex: 'img',
      key: 'img',
      width: 80,
      render: (_value: unknown, record: Product): React.ReactNode => {
        const imgUrl = (record as Record<string, unknown>).img as string | undefined;
        if (!imgUrl) return null;
        return (
          <img
            src={imgUrl}
            alt={record.product_name || '商品封面'}
            loading="lazy"
            style={productImageStyle}
            onError={(e) => {
              e.currentTarget.style.display = 'none';
            }}
          />
        );
      },
    },
    {
      title: '商品名称',
      dataIndex: 'product_name',
      key: 'product_name',
      width: 240,
      ellipsis: true,
      render: (_value: unknown, record: Product): React.ReactNode => (record.product_name || record.name || '-') as React.ReactNode,
    },
    {
      title: '分类',
      dataIndex: 'category',
      key: 'category',
      width: 120,
    },
    {
      title: '价格',
      dataIndex: 'price',
      key: 'price',
      align: 'right',
      width: 120,
      render: (_value: unknown, record: Product) => {
        const price = record.price ?? record.discount_price ?? record.market_price ?? 0;
        return formatCurrency(price);
      },
    },
    {
      title: '今日销量',
      dataIndex: 'sales_today',
      key: 'sales_today',
      align: 'right',
      width: 100,
      render: (value: unknown) => formatNumber(value as number | null | undefined),
    },
    {
      title: '昨日销量',
      dataIndex: 'sales_yesterday',
      key: 'sales_yesterday',
      align: 'right',
      width: 100,
      render: (value: unknown) => formatNumber(value as number | null | undefined),
    },
    {
      title: '销量变化',
      dataIndex: 'sales_change',
      key: 'sales_change',
      align: 'right',
      width: 100,
      render: (_value: unknown, record: Product) => {
        const change = record.sales_today - record.sales_yesterday;
        const color =
          change > 0
            ? 'var(--color-trend-up)'
            : change < 0
            ? 'var(--color-trend-down)'
            : 'var(--color-text-tertiary)';
        const prefix = change > 0 ? '+' : '';
        return (
          <span style={{ color, fontWeight: 500 }}>
            {prefix}
            {formatNumber(change)}
          </span>
        );
      },
    },
    {
      title: '库存',
      dataIndex: 'inventory',
      key: 'inventory',
      align: 'right',
      width: 100,
      render: (value: unknown) => {
        const num = value as number;
        return (
          <span
            style={{
              color: num <= 10 ? 'var(--color-error-500)' : 'var(--color-text-secondary)',
              fontWeight: num <= 10 ? 600 : 400,
            }}
          >
            {formatNumber(num)}
            {num <= 10 && (
              <span style={{ marginLeft: 8, padding: '2px 6px', borderRadius: 4, background: '#fff2f0', color: '#ff4d4f', fontSize: 11 }}>
                低库存
              </span>
            )}
          </span>
        );
      },
    },
    {
      title: '转化率',
      dataIndex: 'conversion_rate',
      key: 'conversion_rate',
      align: 'right',
      width: 100,
      render: (value: unknown) => formatPercent(value as number | null | undefined),
    },
    {
      title: '更新时间',
      dataIndex: 'fetched_at',
      key: 'fetched_at',
      width: 160,
      render: (value: unknown) => formatDate(value as string | null | undefined),
    },
  ], []);

  const fetchProducts = async (params: Record<string, unknown>): Promise<{ items: Product[]; total: number }> => {
    const result = await productApi.getList(params);
    return result || { items: [], total: 0 };
  };

  return (
    <DataTable<Product>
      title="商品管理"
      queryKey={queryKeys.products.list({})}
      queryFn={fetchProducts}
      columns={columns}
      rowKey="product_id"
      search={{ placeholder: '搜索商品名称...' }}
      exportConfig={{
        filenamePrefix: 'products',
        columns: [
          { key: 'product_id', label: '商品ID' },
          { key: 'product_name', label: '商品名称' },
          { key: 'category', label: '分类' },
          { key: 'price', label: '价格' },
          { key: 'market_price', label: '原价' },
          { key: 'discount_price', label: '折扣价' },
          { key: 'sales_today', label: '今日销量' },
          { key: 'sales_yesterday', label: '昨日销量' },
          { key: 'inventory', label: '库存' },
          { key: 'conversion_rate', label: '转化率' },
          { key: 'fetched_at', label: '更新时间' },
          { key: 'product_url', label: '商品链接' },
          { key: 'img', label: '封面图' },
        ],
      }}
      showDataSourceSwitch={false}
    />
  );
};

export default Products;