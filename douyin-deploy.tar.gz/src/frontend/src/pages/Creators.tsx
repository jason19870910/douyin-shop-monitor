import { useMemo } from 'react';
import { formatNumber, formatDate } from '@/utils/formatters';
import { creatorApi, type CreatorWork } from '@/api/index';
import { DataTable, type DataTableColumn } from '@/components/common';
import { queryKeys } from '@/hooks';

const avatarStyle = { width: 32, height: 32, borderRadius: '50%' as const };

const Creators = () => {
  const columns = useMemo<DataTableColumn<CreatorWork>[]>(() => [
    {
      title: '创作者ID',
      dataIndex: 'creator_id',
      key: 'creator_id',
      width: 120,
    },
    {
      title: '头像',
      dataIndex: 'avatar',
      key: 'avatar',
      width: 60,
      render: (_value: unknown, record: CreatorWork): React.ReactNode => {
        const avatarUrl = (record as Record<string, unknown>).avatar as string | undefined;
        return avatarUrl ? (
          <img src={avatarUrl} alt="avatar" style={avatarStyle} />
        ) : (
          <img src="/placeholder.svg" alt="avatar" style={avatarStyle} />
        );
      },
    },
    {
      title: '昵称',
      dataIndex: 'nickname',
      key: 'nickname',
      width: 150,
      render: (_value: unknown, record: CreatorWork) => record.name || record.title || record.creator_name || '-',
    },
    {
      title: '粉丝数',
      dataIndex: 'followers',
      key: 'followers',
      align: 'right',
      width: 100,
      render: (value: unknown) => formatNumber(value as number | null | undefined),
    },
    {
      title: '总销量',
      dataIndex: 'total_sales',
      key: 'total_sales',
      align: 'right',
      width: 100,
      render: (value: unknown) => formatNumber(value as number | null | undefined),
    },
    {
      title: '总收入',
      dataIndex: 'total_revenue',
      key: 'total_revenue',
      align: 'right',
      width: 120,
      render: (value: unknown) => (value !== undefined && value !== null ? '¥' + formatNumber(value as number) : '-'),
    },
    {
      title: '带货商品数',
      dataIndex: 'product_count',
      key: 'product_count',
      align: 'right',
      width: 100,
      render: (value: unknown) => formatNumber(value as number | null | undefined),
    },
    {
      title: '更新时间',
      dataIndex: 'fetched_at',
      key: 'fetched_at',
      width: 160,
      render: (value: unknown) => formatDate(value as string | null | undefined),
    },
  ], []);

  return (
    <DataTable<CreatorWork>
      title="创作者管理"
      queryKey={queryKeys.creators.list({})}
      queryFn={(params) => creatorApi.getList(params) as Promise<{ items: CreatorWork[]; total: number }>}
      columns={columns}
      rowKey="creator_id"
      search={{ placeholder: '搜索创作者昵称/ID...' }}
      exportConfig={{
        filenamePrefix: 'creators',
        columns: [
          { key: 'creator_id', label: '创作者ID' },
          { key: 'nickname', label: '昵称', render: (r: CreatorWork) => r.name || r.title || r.creator_name },
          { key: 'avatar', label: '头像' },
          { key: 'followers', label: '粉丝数' },
          { key: 'total_sales', label: '总销量' },
          { key: 'total_revenue', label: '总收入' },
          { key: 'product_count', label: '带货商品数' },
          { key: 'fetched_at', label: '更新时间' },
        ],
      }}
      showDataSourceSwitch={true}
    />
  );
};

export default Creators;