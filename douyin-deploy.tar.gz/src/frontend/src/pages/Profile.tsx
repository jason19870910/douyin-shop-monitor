import { useMemo } from 'react';
import { DataTable, type DataTableColumn } from '@/components/common';
import { formatDate } from '@/utils/formatters';

interface User {
  user_id: string;
  username: string;
  email: string;
  phone: string;
  role: string;
  create_time: string;
  last_login: string;
  [key: string]: unknown;
}

const Profile = () => {
  const columns = useMemo<DataTableColumn<User>[]>(() => [
    { title: '用户ID', dataIndex: 'user_id', key: 'user_id', width: 120 },
    { title: '用户名', dataIndex: 'username', key: 'username', width: 150 },
    { title: '邮箱', dataIndex: 'email', key: 'email', width: 200 },
    { title: '手机号', dataIndex: 'phone', key: 'phone', width: 150 },
    { title: '角色', dataIndex: 'role', key: 'role', width: 100 },
    { title: '创建时间', dataIndex: 'create_time', key: 'create_time', width: 160, render: (value: unknown) => formatDate(value as string | null | undefined) },
    { title: '最后登录', dataIndex: 'last_login', key: 'last_login', width: 160, render: (value: unknown) => formatDate(value as string | null | undefined) },
  ], []);

  return (
    <DataTable<User>
      title="个人中心"
      queryKey={['profile']}
      queryFn={async () => ({ items: [], total: 0 })}
      columns={columns}
      rowKey="user_id"
      search={{ placeholder: '搜索用户信息...' }}
    />
  );
};

export default Profile;