import sys
sys.path.insert(0, '/app')
from services.fetcher import _fetch_creator_overview_from_api, _fetch_creators_from_api

result = _fetch_creator_overview_from_api()
print('Creator Overview:', result)

creators = _fetch_creators_from_api()
print('Creators:', creators)