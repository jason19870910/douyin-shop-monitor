from flask import jsonify
import psutil

def health():
    try:
        mem = psutil.virtual_memory()
        cpu_percent = psutil.cpu_percent(interval=0.1)
        return jsonify({
            "status": "ok",
            "memory": {
                "total": mem.total,
                "available": mem.available,
                "percent": mem.percent,
                "used": mem.used,
            },
            "cpu_percent": cpu_percent,
            "timestamp": datetime.datetime.utcnow().isoformat() + "Z"
        }), 200
    except Exception as e:
        return jsonify({"status": "error", "error": str(e)}), 500