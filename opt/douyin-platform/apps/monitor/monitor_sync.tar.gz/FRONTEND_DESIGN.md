# 前端设计文档 (Frontend Design)

## 技术栈
- **框架**：React 18 + Vite
- **UI 组件库**：Ant Design
- **状态管理**：React Context + useReducer（对外提供的 API 已经足够，暂不引入 Redux）
- **数据请求**：`fetch` 包装的 `axios`（统一注入 `User-Agent` 与 `Cookie`，在 `src/api/client.ts` 中实现）。
- **路由**：React Router v6
- **图表**：ECharts（用于仪表盘趋势、TOP 商品等可视化）

## 页面结构
| 页面 | 路径 | 主要功能 |
|---|---|---|
| 仪表盘 | `/dashboard` | 总销量、收入、订单数、转化率、7 天趋势、TOP5 商品展示 |
| 商品列表 | `/products` | 商品分页查询、关键字搜索、查看商品详情 |
| 订单列表 | `/orders` | 订单分页、时间范围、状态过滤、统计汇总 |
| 创作者中心 | `/creators` | 创作者列表、单页详情（粉丝、视频、最近互动） |
| 告警配置 | `/alerts` | 查看/编辑阈值、开启/关闭告警 |
| 数据同步 | 页面顶部按钮 | 手动触发 `/api/sync` 同步最新数据 |

## 交互细节
- **统一请求头**：在 `src/api/client.ts` 中统一添加 `User-Agent`（读取自 `.env`），并在需要外部接口时自动注入对应域名的 Cookie（`FXG_COOKIES`、`CREATOR_COOKIES`）。
- **错误处理**：全局拦截器捕获非 2xx 响应，弹出 Ant Design `message.error`，并在控制台记录详细信息。
- **加载状态**：使用 Ant Design `Spin` 包裹列表分页加载，防止页面卡顿。
- **分页**：后端已实现 `page`、`size` 参数，前端通过 `useEffect` 监听分页变量并请求对应 API。
- **告警弹窗**：`/alerts` 页面提供表单编辑阈值，保存后调用 `POST /api/alerts/config`，成功后使用 `notification.success` 提示。

## 代码组织
```
src/
 ├─ api/          # 与后端交互的封装层
 │    └─ client.ts
 ├─ components/   # 可复用 UI 组件（表格、图表、搜索框）
 ├─ pages/        # 各业务页面
 │    ├─ Dashboard.tsx
 │    ├─ Products.tsx
 │    ├─ Orders.tsx
 │    ├─ Creators.tsx
 │    └─ Alerts.tsx
 ├─ routes/       # React Router 配置
 └─ utils/        # 通用工具函数
```

## 运行指南
```bash
# 安装依赖
npm install
# 开发模式（代理至后端 http://localhost:5000）
npm run dev
# 构建生产包
npm run build
# 部署时将 `build/` 目录挂载到 Flask 静态文件目录
```

---

*前端设计会根据实际需求迭代更新，本文档仅提供当前阶段的整体方案。