# 项目设计文档

## 1. 项目概述
本项目是 **抖音数据监控平台**（`monitor`），通过定时抓取商品、订单、创作者等业务数据并提供统一的 RESTful API 给前端展示。原始实现使用抖音开放平台 API，后期改为通过可配置的外部数据服务 URL 进行数据获取，以便在不同业务场景下灵活对接。

## 2. 系统架构
```
+-------------------+      +-------------------+      +-------------------+
|   Frontend React  | <--->|   Flask API（app）| <--->| External Data API |
+-------------------+      +-------------------+      +-------------------+
        ^   ^                     ^   ^                     ^   ^
        |   |                     |   |                     |   |
        |   |                     |   |                     |   +--- HTTP GET (JSON)
        |   |                     |   +--- APScheduler (定时任务)
        |   +--- Nginx 反向代理   +--- Docker / Docker‑Compose
        +--- Systemd service (doudian_monitor.service)
```

- **前端**：React SPA，所有请求均指向 `http://<host>/api/*`，通过 `frontend/src/api/index.js` 设置 `baseURL`。
- **后端**：Flask 应用 (`app.py`) 提供统一的 API 路由，使用 `APScheduler` 每 `Config.SCHEDULE_INTERVAL_MINUTES` 分钟触发一次数据同步。
- **数据同步**：同步逻辑集中在 `fetch_and_store_*` 系列函数，统一使用 `_request` 调用外部服务，结果写入本地 JSON 文件 (`data/` 目录) 并缓存在内存 `data_cache` 中供 API 读取。
- **告警**：基于阈值检查（销量下降、库存不足、转化率下降）在 `check_alerts` 中产生告警并可通过邮件发送（配置 `ALERT_EMAIL`）。
- **部署**：支持 Docker 镜像 (`Dockerfile`)、Docker‑Compose、Systemd service 以及 Nginx 反向代理。

## 3. 数据流
1. **调度触发**：`scheduler` 调用 `scheduled_job` → 依次执行 `fetch_and_store_products`、`fetch_and_store_orders`、`fetch_and_store_creators`。
2. **外部请求**：每个 `fetch_and_store_*` 通过 `_request(endpoint, params)` 向 `Config.EXTERNAL_DATA_BASE_URL` 拼接对应路径（`/products`、`/orders`、`/creators`）发起 GET 请求。
3. **字段标准化**：返回的 JSON 若缺失关键字段（如 `sales_yesterday`、`conversion_rate_today` 等），在函数内部使用 `.get(..., default)` 补全默认值，确保前端始终能读取到有效数值。
4. **持久化**：标准化后的数据写入 `data/` 目录下的 `products.json`、`orders.json`、`creators.json`，并同步到 `data_cache`。
5. **API 提供**：Flask 路由如 `/api/products`、`/api/orders`、`/api/creators` 直接读取 `data_cache` 返回；`/api/dashboard/stats` 进一步聚合统计。

## 4. 配置说明 (`config.py`)
| 配置项 | 含义 | 默认值 | 备注 |
|--------|------|--------|------|
| `EXTERNAL_DATA_BASE_URL` | 外部数据服务根地址 | `https://example.com/monitor` | 通过 `.env` 覆盖 |
| `API_AUTH_TOKEN` | 可选的 Bearer Token | 空 | 如服务需要鉴权则填入 |
| `DATA_DIR` | 本地 JSON 数据目录 | `.../data` | 通过环境变量 `DATA_DIR` 调整 |
| `SCHEDULE_INTERVAL_MINUTES` | 抓取间隔（分钟） | `60` | 通过 `.env` 配置 |
| `ALERT_EMAIL` | 告警邮件收件人 | 空 | 可选 |
| 其余 `DOUYIN_*` 仍保留兼容旧代码，但不再使用 |

## 5. 外部 API 集成细节
- **请求函数** `_request` 统一处理 URL 拼接、Header 注入、异常日志。
- **返回约定**：外部服务必须返回形如 `{"data": {"products": [...]} }` 或相似结构；如字段名称与内部不一致，可在相应 `fetch_and_store_*` 中做映射。
- **示例**：
```bash
curl -H "Authorization: Bearer <token>" \
     "https://api.example.com/monitor/products"
```
返回示例（简化）：
```json
{ "data": { "products": [ { "product_id": "p1", "product_name": "A", "sales_today": 120, "sales_yesterday": 100, "inventory": 30, "conversion_rate": 0.12 } ] } }
```
- 若外部服务不提供 `sales_yesterday` 或 `conversion_rate_yesterday`，函数内部会使用当天值或 `0` 进行填充。

## 6. 调度与告警
- **APScheduler**：在 `app.py` 第 294 行创建 `scheduler`，使用 `IntervalTrigger(minutes=Config.SCHEDULE_INTERVAL_MINUTES)`。
- **告警阈值**：`DEFAULT_ALERT_CONFIG` 中可配置销量下降阈值、转化率下降阈值、库存阈值以及是否开启告警。
- **告警渠道**：当前实现为日志打印及可选的 Email（`send_email` 为占位实现）。

## 7. 部署指南
1. **本地开发**：`npm install && npm start`（前端），`pip install -r requirements.txt && python app.py`（后端）。
2. **Docker**：`docker build -t douyin-monitor .` → `docker compose up -d`（docker‑compose.yml 已配置端口映射 5000）。
3. **Systemd**：`doudian_monitor.service` 包含 `docker-compose up -d` 与 `down`，复制到 `/etc/systemd/system/` 并 `systemctl enable --now doudian_monitor`。
4. **Nginx**：`nginx.conf` 示例已提供，修改 `server_name` 与 `proxy_pass http://monitor:5000;` 即可对外提供 `https://your.domain/`。

## 8. 常见问题
- **为何抓取结果全是 0？** 检查外部 API 是否返回正确字段；若缺失，函数会使用默认值 0，前端会显示 0。请在外部服务确保返回 `sales_today`、`sales_yesterday`、`conversion_rate` 等。
- **修改了 `.env` 后不生效？** 需要重新启动 Flask 应用，使 `load_dotenv()` 重新读取环境变量。
- **如何切换回抖音官方 API？** 将 `fetch_and_store_*` 中的 `_request` 调用改回 `douyin_client.get_*` 并确保 `Config` 中的 `DOUYIN_*` 参数已配置。

---
> 本设计文档已同步至项目根目录 `DESIGN.md`，后续如有架构变更请及时更新，以避免代码与文档不一致。
