# 贡献指南

感谢关注 DouDian Monitor 项目！

## 开发流程

1. Fork 本仓库
2. 克隆到本地：
   ```bash
   git clone https://github.com/yourusername/doudian_monitor.git
   cd doudian_monitor
   ```
3. 创建虚拟环境：
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   # venv\Scripts\activate  # Windows
   pip install -r requirements-dev.txt
   ```
4. 配置 pre-commit hooks：
   ```bash
   pre-commit install
   ```
5. 创建特性分支：
   ```bash
   git checkout -b feature/amazing-feature
   ```
6. 修改代码，确保：
   - 通过 `black` 格式化
   - 通过 `flake8` 检查
   - 通过 `mypy` 类型检查（类型注解）
   - 通过 `pytest` 测试
7. 提交更改：
   ```bash
   git add .
   git commit -m "Add amazing feature"
   ```
8. 推送分支：
   ```bash
   git push origin feature/amazing-feature
   ```
9. 创建 Pull Request，描述变更内容

## 代码规范

- Python 类型注解（PEP 484）
- 遵循 PEP 8（black 自动格式化）
- 函数/变量命名清晰，添加 docstring
- 单元测试覆盖率达 80%+

## 提交信息格式

```
type: short description

optional longer description

Types:
- feat: new feature
- fix: bug fix
- docs: documentation changes
- style: formatting changes (no code change)
- refactor: code restructuring
- test: adding or updating tests
- chore: maintenance tasks
```

示例：
```
feat: add product list pagination support

- Support page and page_size query parameters
- Add total count in response headers
- Update frontend to use paginated API
```

## CI/CD

所有 PR 和 Push 都会触发 GitHub Actions：
- 测试（Python 3.11, 3.12）
- 代码检查（flake8, black, mypy）
- Docker 构建
- 安全扫描（Trivy）

确保 CI 状态全部通过才能合并。

## 发布流程

1. 更新版本号（app.py 或 config.py）
2. 更新 CHANGELOG.md
3. 创建 Git tag：
   ```bash
   git tag -a v1.2.0 -m "Release v1.2.0"
   git push origin v1.2.0
   ```
4. GitHub Actions 自动构建并推送 Docker 镜像

## 问题反馈

- Bug: 请提供复现步骤、环境信息、日志
- Feature: 请描述使用场景和预期行为

谢谢！