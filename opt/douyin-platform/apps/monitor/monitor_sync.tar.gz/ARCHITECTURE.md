# 系统架构概览 (Architecture Overview)

## 整体结构
```
+-------------------+        +-------------------+        +-------------------+
|   前端 (React)    | <----> |   后端 (Flask)    | <----> |   数据存储 (JSON)   |
+-------------------+        +-------------------+        +-------------------+
        |                                 |
        |                                 v
        |                         +-------------------+
        |                         |   调度器 (APScheduler) |
        |                         +-------------------+
        |                                 |
        |                                 v
        |                         +-------------------+
        +----------------------> |   外部 API 调用   |
                                  (FXG / Creator)
```

## 关键组件
- **Flask**：提供 RESTful API，对内服务（`/api/*`）以及对外转发接口。
- **APScheduler**：后台定时任务，每 `SCHEDULE_INTERVAL_MINUTES` 分钟抓取外部数据并检查告警。
- **Config**：统一管理环境变量，包括双域名基础 URL、公共请求头、Cookie、动态签名参数等。
- **外部 API 调用**：通过 `app._request` 函数，使用 `Config.FXG_BASE_URL`、`Config.CREATOR_BASE_URL`、`Config.COMMON_HEADERS`、`Config.FXG_COOKIES`/`Config.CREATOR_COOKIES` 完成安全请求。
- **告警系统**：`check_alerts` 检测销量、转化率、库存阈值，支持邮件通知（可后续接入企业微信）。

## 数据流
1. **定时抓取**：`scheduled_job` 调用 `fetch_and_store_*` 系列函数，从外部 API 拉取商品、订单、创作者数据并写入本地 JSON 文件。
2. **缓存**：抓取结果保存在全局 `data_cache`，供所有 API 路由实时读取。
3. **告警**：抓取后立即执行 `check_alerts`，如满足阈值则触发 `send_alert`（日志 + 邮件）。
4. **前端访问**：前端通过 `/api/*` 调用获取商品列表、订单列表、创作者信息、仪表盘统计等。
5. **外部转发**：`/api/products/external`、`/api/orders/stats`、`/api/products/stats` 等路由直接转发请求至对应外部服务，保持查询参数完整。

## 部署方案
- **Docker**：`Dockerfile` + `docker-compose.yml`，容器化后通过 Nginx 反向代理提供 5000 端口的 Flask 服务。
- **Systemd**：生产环境可使用 `doudian_monitor.service` 管理容器或直接运行 `gunicorn`。
- **日志**：通过 `logging` 模块输出到 stdout，配合 Loki + Grafana 实现集中化日志监控。

---

*架构文档会随功能演进持续更新。