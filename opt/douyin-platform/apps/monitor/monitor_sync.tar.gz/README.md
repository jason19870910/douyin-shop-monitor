# DouDian Monitor 项目文档

## 1. 项目概述

> 详细设计文档请查阅 [DESIGN.md](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/DESIGN.md)
- **背景**：抖音电商店铺缺乏统一的数据监控与告警手段，导致运营决策滞后、异常难以及时发现。
- **核心目标**：构建一套稳健、可维护的抖音店铺监控系统，提供商品、订单、创作者等数据的实时查询、可视化与异常告警，支持每日自动抓取。
- **目标受众**：抖音店铺运营人员、业务分析师、技术运维团队。

## 2. 项目范围 & 约束
### 允许范围（✅）
- 使用 Python 3.11+、Flask、Celery、Redis、PostgreSQL（可选）进行后端开发。
- Docker 化部署、systemd 服务、Nginx 反向代理。
- 通过 `.env` 配置 Cookie、Token、SMTP 等敏感信息。
- 前端可使用任意现代框架展示数据。
### 禁止事项（❌）
- 引入不安全的外部依赖（如暴露的 API Key）。
- 在代码或配置中硬编码敏感信息。
- 将抖音接口迁移至第三方收费服务。
- 对 API 频率做未标注的反爬防护。

## 3. 交付物清单
| 编号 | 交付物 | 形式 | 验收标准 |
|---|---|---|---|
| 1 | 源码 | Git 仓库 | 代码审查通过，所有单元测试通过 |
| 2 | Docker 镜像 | `douyin_monitor:latest` | 能在目标服务器正常启动，提供健康检查接口 |
| 3 | 文档 | Markdown 系列文件 | 完整的 README、部署手册、运维手册、API 说明 |
| 4 | 测试套件 | `tests/` | 覆盖率 ≥ 80%，CI 自动执行 |
| 5 | 运维脚本 | systemd、Nginx 配置 | 一键部署，服务可自动启动与监控 |

## 4. 项目里程碑 (甘特图)
| 里程碑 | 计划完成日期 | 产出 |
|---|---|---|
| 需求梳理 | 2026‑07‑01 | 需求文档 |
| 架构设计 | 2026‑07‑05 | 架构图、技术选型 |
| 核心功能实现 | 2026‑08‑01 | API、前端页面 |
| 自动化测试 & CI/CD | 2026‑08‑05 | 测试覆盖、GitHub Actions |
| Docker 化 & 部署 | 2026‑08‑10 | 镜像、systemd、Nginx 配置 |
| 项目验收 | 2026‑08‑15 | 交付物检查、验收报告 |

## 5. 功能规格（API 与前端）
### 商品管理
- **GET /api/products** `page, size, keyword` → 返回商品列表、总数。
- **GET /api/products/{product_id}** → 返回单个商品详细信息。
### 订单看板
- **GET /api/orders** `page, size, start_date, end_date, status` → 返回订单列表、分页信息。
### 创作者数据
- **GET /api/creators** → 返回创作者列表。
- **GET /api/creators/{creator_id}** → 返回单个创作者详情。
### 告警配置
- **GET /api/alerts/config** → 获取当前阈值配置。
- **POST /api/alerts/config** → 更新阈值（字段：`sales_drop_threshold、conversion_drop_threshold、inventory_low_threshold、notification_email、enabled`）。
### 数据同步
- **POST /api/sync** → 手动触发全量抓取。
### 仪表盘统计
- **GET /api/dashboard/stats** → 返回总销量、收入、订单数、转化率、最近 7 天销售趋势、TOP5 商品等聚合数据。

## 6. 技术架构概览
![架构图](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/architecture.png)
- **后端**：Flask 提供 RESTful API，内部接口 `/api/*` 供前端调用；外部转发接口代理抖音电商后台 API。
- **任务调度**：
  - APScheduler（`app.py`）：定时触发全量同步（默认 60 分钟），用于轻量级定时任务。
  - Celery + Redis（`celery_config.py`、`tasks.py`）：生产级异步任务队列，支持周期性抓取（商品 15 分钟、订单 15 分钟、创作者 1 小时）、告警检查（5 分钟）与重试机制。
- **数据存储**：本地 JSON 文件 (`data/`) 作为缓存，生产环境可切换至 PostgreSQL。
- **告警机制**：`check_alerts` 根据阈值检测销量、转化率、库存异常，支持邮件通知（可扩展企业微信/钉钉）。
- **外部 API 对接**：双域名体系（`fxg.jinritemai.com` 抖店、`creator.douyin.com` 创作者中心），统一 Header 与 Cookie 管理，动态签名参数（`a_bogus`、`msToken`、`verifyFp`、`fp`、`__token`）实时获取。
- **前端**：React + Ant Design，实现 Dashboard、商品、订单、创作者、告警配置页面，所有请求统一走 `/api/*`。
- **部署**：Docker + Docker‑Compose（4 服务：monitor、celery_worker、celery_beat、redis），配合 systemd 与 Nginx 反向代理，实现生产级服务。

## 7. 部署与运维手册
### 7.1 环境准备
```bash
# 安装 Docker 与 Docker‑Compose（推荐 2.20+）
# 如需本地运行 Python，请确保已安装 Python 3.11+ 与 pip
```
创建 `.env`（示例）

> 项目运行所需的全部环境变量已在 **.env.example** 中列出，复制该文件为 `.env` 并填写真实值即可。必须填写的关键变量包括：
> - 双域名基础 URL：`FXG_BASE_URL`、`CREATOR_BASE_URL`
> - 认证签名参数：`__TOKEN`、`MS_TOKEN`、`a_bogus`、`verifyFp`、`fp`
> - 完整 Cookie：`FXG_COOKIES`（抖店）、`CREATOR_COOKIES`（创作者中心）
> - Celery：`CELERY_BROKER_URL`、`CELERY_RESULT_BACKEND`
> - 其他：`DOUYIN_APP_ID`、`DOUYIN_APP_SECRET`、`ALERT_EMAIL` 等

```bash
# 复制示例文件
cp .env.example .env

# 编辑 .env，填写上述真实值（Cookie 请从浏览器开发者工具完整复制）
```

### 7.2 Docker 镜像构建与启动（推荐生产部署）
```bash
cd path/to/monitor
# 构建镜像（会自动读取 Dockerfile）
docker-compose build
# 启动全栈（4 服务：monitor、celery_worker、celery_beat、redis）
docker-compose up -d
```
- 服务端口：`monitor` 在 **5000** 端口提供 Flask API + 静态前端；`redis` 在 **6379** 端口。
- Nginx 已通过 `VIRTUAL_HOST=wlkj-tech.cn` 进行反向代理，可自行修改 `docker-compose.yml` 中的 `VIRTUAL_HOST`。
- 使用 `docker ps` 检查容器状态，`docker logs douyin_monitor` / `docker logs douyin_celery_worker` / `docker logs douyin_celery_beat` 查看各服务日志。
### 7.3 本地直接运行（无需 Docker）
```bash
pip install -r requirements.txt
# 启动 Flask（使用 gunicorn）
gunicorn app:app --bind 0.0.0.0:5000 --workers 4
```
### 7.4 前端运行指引
```bash
cd frontend
npm install
npm start   # 默认 http://localhost:3000 代理至后端 http://localhost:5000
```
如需修改代理，请编辑 `frontend/package.json` 中的 `proxy` 字段。
### 7.5 Systemd 服务（生产部署）
```bash
sudo cp doudian_monitor.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable doudian_monitor   # 开机自启
sudo systemctl start doudian_monitor    # 手动启动
```
- **停止服务**：`sudo systemctl stop doudian_monitor`
- **查看状态**：`sudo systemctl status doudian_monitor`
- **查看日志**：`journalctl -u doudian_monitor -f`
### 7.6 Nginx 反向代理
已在项目根目录提供 `nginx.conf`，示例配置如下：
```nginx
events {}
http {
    server {
        listen 80;
        server_name wlkj-tech.cn;
        location / {
            proxy_pass http://monitor:5000;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        }
    }
}
```
将该文件挂载至宿主机的 Nginx 配置目录后重新加载即可。
### 7.7 日志集中化（Loki + Grafana）
- Loki 配置文件 `loki-config.yaml` 已提供，启动 Loki 容器后即可在 Grafana 中接入。
- 前端与后端日志统一写入 `/var/log/douyin_monitor/`，可通过 Loki 收集并在 Grafana 中可视化。

## 8. 使用说明（快速上手）
1. **环境准备**（见 7.1）
2. **构建并启动**（见 7.2 或 7.3）
3. **访问前端**：浏览器打开 `http://localhost:5000`（Docker）或 `http://localhost:3000`（开发），即看到完整仪表盘。
4. **手动同步**：`curl -X POST http://localhost:5000/api/sync` 或点击仪表盘 “立即同步”。
5. **告警配置**：在左侧菜单的 “告警配置” 页面修改阈值并保存，系统将在下次检查（默认 5 分钟）时生效。
6. **运行单元测试**：`pytest -q`（项目根目录），覆盖率 ≥ 80%。
7. **查看健康**：`curl http://localhost:5000/api/health`，返回 `{ "status": "healthy", ... }`。

## 9. 质量保障 & CI/CD
- **单元测试**：`pytest --cov=.`，覆盖率 ≥ 80%。
- **代码风格**：`flake8`、`black` 自动检查与格式化。
- **CI**：GitHub Actions 自动执行 lint、test、docker build，并在 PR 合并前阻止错误。
- **部署流水线**：通过 GitHub Actions 推送镜像至 Docker Hub，生产服务器执行 `docker-compose pull && docker-compose up -d` 实现滚动升级。

## 10. 风险 & 已知问题
| 风险 | 影响 | 缓解措施 |
|---|---|---|
| Token 失效 | 抖音接口调用失败 | 自动检测失效并通过告警邮件提醒，定期手动更新 `.env`。 |
| 抖音 API 限流 | 抓取速度受限 | 实现指数退避与重试，使用 Celery 重试机制。 |
| Docker 端口冲突 | 服务不可达 | 在 `docker-compose.yml` 中自定义端口映射。 |
| 邮件告警未送达 | 关键异常无法感知 | 确认 SMTP 可达，或改用企业微信 / DingTalk 通知。 |

## 11. 变更管理流程

### 11.1 变更日志模板
```
| 编号 | 变更描述 | 影响范围 | 提出人 | 审批人 | 实施人 | 完成日期 |
|---|---|---|---|---|---|---|
| 001 | 将 Docker 镜像升级到 2.0 版 | 部署环境 | 张三 | 李四 | 王五 | 2026-08-12 |
```

### 11.2 CI 配置示例（GitHub Actions）
```yaml
name: CI

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  lint-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      - name: Install dependencies
        run: |
          pip install -r requirements.txt
          pip install flake8 black pytest pytest-cov
      - name: Lint
        run: |
          flake8 .
          black --check .
      - name: Test
        run: |
          pytest -q --cov=.

  docker-build:
    needs: lint-test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Log in to Docker Hub
        uses: docker/login-action@v2
        with:
          username: ${{ secrets.DOCKER_USERNAME }}
          password: ${{ secrets.DOCKER_PASSWORD }}
      - name: Build and push Docker image
        uses: docker/build-push-action@v5
        with:
          context: .
          push: true
          tags: yourdockerhubuser/douyin_monitor:latest
```
1. **变更提出**：填写《变更请求表》（编号、描述、影响范围、预估工时）。
2. **评审**：项目负责人评估风险、资源、优先级。
3. **批准**：通过后在 README “里程碑” 中添加对应任务并更新状态。
4. **执行**：实施代码、文档、配置变更。
5. **验证**：通过回归测试、手动验收，确认无副作用。
6. **记录**：在 README “变更日志” 中记录 `编号、描述、实施人、完成日期`。

## 12. 文档索引（完整）
| 文档 | 说明 | 链接 |
|---|---|---|
| README.md | 项目总览 | [README](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/README.md) |
| DESIGN.md | 详细设计文档 | [DESIGN.md](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/DESIGN.md) |
| .env.example | 环境变量示例文件 | [.env.example](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/.env.example) |
| .env | 实际环境变量文件（不建议提交） | [.env](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/.env) |
| config.py | 环境变量封装 | [config.py](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/config.py) |
| app.py | 后端入口 | [app.py](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/app.py) |
| requirements.txt | Python 依赖列表 | [requirements.txt](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/requirements.txt) |
| celery_config.py | Celery 配置 | [celery_config.py](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/celery_config.py) |
| tasks.py | Celery 任务实现 | [tasks.py](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/tasks.py) |
| Dockerfile | 镜像构建文件 | [Dockerfile](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/Dockerfile) |
| docker-compose.yml | Docker‑Compose 编排（4 服务） | [docker-compose.yml](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/docker-compose.yml) |
| doudian_monitor.service | systemd 服务文件 | [doudian_monitor.service](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/doudian_monitor.service) |
| nginx.conf | Nginx 反向代理配置 | [nginx.conf](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/nginx.conf) |
| loki-config.yaml | Loki 日志收集配置 | [loki-config.yaml](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/loki-config.yaml) |
| .github/workflows/ci.yml | CI/CD GitHub Actions 工作流 | [ci.yml](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/.github/workflows/ci.yml) |
| FRONTEND_DESIGN.md | 前端页面设计文档 | [FRONTEND_DESIGN.md](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/FRONTEND_DESIGN.md) |
| PROJECT_CHARTER.md | 项目章程文档 | [PROJECT_CHARTER.md](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/PROJECT_CHARTER.md) |
| ARCHITECTURE.md | 系统架构概览 | [ARCHITECTURE.md](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/ARCHITECTURE.md) |
| API-SPEC.md | 外部 API 接口规范文档 | [API-SPEC.md](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/API-SPEC.md) |
| EXTERNAL-API-SPEC.md | 外部 API 详细规范（重构版） | [EXTERNAL-API-SPEC.md](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/EXTERNAL-API-SPEC.md) |
| INTERNAL-API-SPEC.md | 内部 RESTful API 规范 | [INTERNAL-API-SPEC.md](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/INTERNAL-API-SPEC.md) |
| ISSUE_ANALYSIS.md | 前端数据问题分析报告 | [ISSUE_ANALYSIS.md](file:///c:/Users/Administrator/Documents/trae_projects/douyin/opt/douyin-platform/apps/monitor/ISSUE_ANALYSIS.md) |
---

## 13. 当前任务执行状态（实时更新）

| 编号 | 任务 | 状态 | 优先级 | 备注 |
|---|---|---|---|---|
| 1 | 生成 EXTERNAL-API-SPEC.md 完整内容 - 整合所有 6 个接口的规范 | ✅ 已完成 | 🔴 高 | 已重构为结构化 10 章文档 |
| 2 | 更新 config.py - 双域名 BaseURL、Headers、Cookies 分离常量 | ✅ 已完成 | 🔴 高 | 已在 config.py 中加入双域名、公共头部、Cookie 常量 |
| 3 | 重写 app.py 抓取函数 - 使用 _request 调用外部 URL | ✅ 已完成 | 🔴 高 | 已更新 fetch_and_store_* 函数并使用新 _request |
| 4 | 整理 INTERNAL-API-SPEC.md - 移除外部接口 | ✅ 已完成 | 🟡 中 | 已删除外部转发章节，仅保留内部 RESTful 接口 |
| 5 | 创建 .env.example / .env 模板 | ✅ 已完成 | 🔴 高 | 已包含双域名、签名参数、Cookie、Celery 配置及填写示例 |
| 6 | 更新 README.md 文档索引 | ✅ 已完成 | 🟡 中 | 已更新文档索引、架构、部署说明 |
| 7 | 补全 PROJECT_CHARTER.md、ARCHITECTURE.md、FRONTEND_DESIGN.md | ✅ 已完成 | 🟢 低 | 已创建并填充三份文档 |
| 8 | 更新 tasks.py - 使用新外部 API 端点与 Cookie | ✅ 已完成 | 🔴 高 | 三个 Celery 任务均指向正确端点并携带 Cookie |
| 9 | 扩展 docker-compose.yml - 4 服务编排 + 完整环境变量 | ✅ 已完成 | 🔴 高 | monitor、celery_worker、celery_beat、redis 全栈 |
| 10 | 运行测试验证 | ✅ 已完成 | 🔴 高 | pytest 通过、模块导入无误 |

> **更新时间**: 2026-08-12  
> **当前阶段**: 全部核心任务完成，项目可进入部署验收阶段

---

> **请确认以上信息无误**，如需进一步细化或补充其他文档，请告知。