import os
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, asdict
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import requests
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Load environment variables
from dotenv import load_dotenv
load_dotenv()

# Import config
from config import Config

app = Flask(__name__, static_folder='../frontend/build', static_url_path='')
CORS(app)

# Data storage paths
DATA_DIR = Path(Config.DATA_DIR)
DATA_DIR.mkdir(parents=True, exist_ok=True)

PRODUCTS_FILE = DATA_DIR / 'products.json'
ORDERS_FILE = DATA_DIR / 'orders.json'
CREATORS_FILE = DATA_DIR / 'creators.json'
ALERT_CONFIG_FILE = DATA_DIR / 'alert_config.json'

# Default alert configuration
DEFAULT_ALERT_CONFIG = {
    'sales_drop_threshold': 0.3,  # 30% drop
    'conversion_drop_threshold': 0.2,  # 20% drop
    'inventory_low_threshold': 10,
    'notification_email': os.getenv('ALERT_EMAIL', ''),
    'enabled': True
}

# In-memory cache for latest data
data_cache = {
    'products': [],
    'orders': [],
    'creators': [],
    'last_update': None
}

alert_config = DEFAULT_ALERT_CONFIG.copy()


def load_json_file(file_path: Path, default: Any = None) -> Any:
    """Load JSON file, return default if not exists."""
    if file_path.exists():
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except json.JSONDecodeError:
            logger.error(f"Failed to parse JSON from {file_path}")
            return default
    return default


def save_json_file(file_path: Path, data: Any) -> None:
    """Save data to JSON file."""
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"Failed to save JSON to {file_path}: {e}")


def load_all_data() -> None:
    """Load all data files into cache."""
    global data_cache, alert_config
    data_cache['products'] = load_json_file(PRODUCTS_FILE, [])
    data_cache['orders'] = load_json_file(ORDERS_FILE, [])
    data_cache['creators'] = load_json_file(CREATORS_FILE, [])
    alert_config.update(load_json_file(ALERT_CONFIG_FILE, DEFAULT_ALERT_CONFIG))
    data_cache['last_update'] = datetime.now().isoformat()
    logger.info("Data loaded successfully")


def save_all_data() -> None:
    """Save all cached data to files."""
    save_json_file(PRODUCTS_FILE, data_cache['products'])
    save_json_file(ORDERS_FILE, data_cache['orders'])
    save_json_file(CREATORS_FILE, data_cache['creators'])
    save_json_file(ALERT_CONFIG_FILE, alert_config)
    logger.info("Data saved successfully")


# Douyin API integration
class DouyinAPIClient:
    """Client for Douyin Open Platform API."""

    def __init__(self):
        self.app_id = Config.DOUYIN_APP_ID
        self.app_secret = Config.DOUYIN_APP_SECRET
        self.access_token = Config.DOUYIN_ACCESS_TOKEN
        self.base_url = 'https://open.douyin.com'

    def _get_headers(self) -> Dict[str, str]:
        return {
            'Authorization': f'Bearer {self.access_token}',
            'Content-Type': 'application/json'
        }

    def get_product_list(self, page: int = 1, size: int = 20) -> Dict[str, Any]:
        """Get product list from Douyin."""
        url = f'{self.base_url}/product/list'
        params = {'page': page, 'size': size}
        try:
            response = requests.get(url, headers=self._get_headers(), params=params, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            logger.error(f"Failed to fetch product list: {e}")
            return {'data': {'products': []}}

    def get_order_list(self, start_time: int, end_time: int, page: int = 1, size: int = 20) -> Dict[str, Any]:
        """Get order list from Douyin."""
        url = f'{self.base_url}/order/list'
        params = {
            'start_time': start_time,
            'end_time': end_time,
            'page': page,
            'size': size
        }
        try:
            response = requests.get(url, headers=self._get_headers(), params=params, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            logger.error(f"Failed to fetch order list: {e}")
            return {'data': {'orders': []}}

    def get_creator_info(self, creator_id: str) -> Dict[str, Any]:
        """Get creator info from Douyin."""
        url = f'{self.base_url}/creator/info'
        params = {'creator_id': creator_id}
        try:
            response = requests.get(url, headers=self._get_headers(), params=params, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            logger.error(f"Failed to fetch creator info: {e}")
            return {'data': {}}


douyin_client = DouyinAPIClient()


def _request(url: str, params: dict = None, headers: dict = None, cookies: dict = None) -> dict:
    """通用外部请求函数。
    url: 完整的外部 URL（可包含协议、域名及路径）
    params: 查询参数字典
    headers: 可选的请求头，若未提供则使用默认公共头部
    cookies: 可选的 Cookie dict
    """
    # 默认使用公共请求头
    request_headers = Config.COMMON_HEADERS.copy()
    if headers:
        request_headers.update(headers)
    # 添加 API 授权 token（如果有）
    if Config.API_AUTH_TOKEN:
        request_headers['Authorization'] = f'Bearer {Config.API_AUTH_TOKEN}'
    try:
        resp = requests.get(url, params=params, headers=request_headers, cookies=cookies, timeout=30)
        resp.raise_for_status()
        return resp.json()
    except requests.RequestException as e:
        logger.error(f'External API request failed {url}: {e}')
        return {}


def fetch_and_store_products() -> None:
    """Fetch product data from external FXG API and store locally."""
    logger.info("Fetching products from external FXG API...")
    endpoint = f"{Config.FXG_BASE_URL}/product/tproduct/list"
    # 直接转发所有请求参数，示例仅使用空参数
    result = _request(endpoint, params={})
    products = result.get('data', {}).get('products', [])
    for product in products:
        product['fetched_at'] = datetime.now().isoformat()
    data_cache['products'] = products
    save_json_file(PRODUCTS_FILE, products)
    logger.info(f"Fetched and stored {len(products)} products")


def fetch_and_store_orders() -> None:
    """Fetch order data from external FXG API and store locally."""
    logger.info("Fetching orders from external FXG API...")
    endpoint = f"{Config.FXG_BASE_URL}/api/order/searchlist"
    # 示例仅使用最近一天的时间范围
    end_time = int(datetime.now().timestamp())
    start_time = int((datetime.now() - timedelta(days=1)).timestamp())
    params = {'start_time': start_time, 'end_time': end_time}
    result = _request(endpoint, params=params)
    orders = result.get('data', {}).get('orders', [])
    for order in orders:
        order['fetched_at'] = datetime.now().isoformat()
    data_cache['orders'] = orders
    save_json_file(ORDERS_FILE, orders)
    logger.info(f"Fetched and stored {len(orders)} orders")


def fetch_and_store_creators() -> None:
    """Fetch creator data from external Creator API and store locally."""
    logger.info("Fetching creators from external Creator API...")
    endpoint = f"{Config.CREATOR_BASE_URL}/janus/douyin/creator/data/overview/dashboard"
    result = _request(endpoint, params={})
    creators = result.get('data', {}).get('creators', [])
    for creator in creators:
        creator['fetched_at'] = datetime.now().isoformat()
    data_cache['creators'] = creators
    save_json_file(CREATORS_FILE, creators)
    logger.info(f"Fetched and stored {len(creators)} creators")


def check_alerts() -> None:
    """Check alert conditions and send notifications if needed."""
    if not alert_config.get('enabled', True):
        return
    
    logger.info("Checking alert conditions...")
    
    # Check sales drop
    products = data_cache['products']
    for product in products:
        sales_today = product.get('sales_today', 0)
        sales_yesterday = product.get('sales_yesterday', 0)
        
        if sales_yesterday > 0:
            drop_rate = (sales_yesterday - sales_today) / sales_yesterday
            if drop_rate >= alert_config['sales_drop_threshold']:
                send_alert(
                    'sales_drop',
                    f"Product {product.get('product_name', 'Unknown')} sales dropped by {drop_rate:.1%}",
                    product
                )
        
        # Check inventory
        inventory = product.get('inventory', 0)
        if inventory <= alert_config['inventory_low_threshold']:
            send_alert(
                'low_inventory',
                f"Product {product.get('product_name', 'Unknown')} inventory low: {inventory}",
                product
            )
    
    # Check conversion rate drop
    for product in products:
        conv_today = product.get('conversion_rate_today', 0)
        conv_yesterday = product.get('conversion_rate_yesterday', 0)
        
        if conv_yesterday > 0:
            drop_rate = (conv_yesterday - conv_today) / conv_yesterday
            if drop_rate >= alert_config['conversion_drop_threshold']:
                send_alert(
                    'conversion_drop',
                    f"Product {product.get('product_name', 'Unknown')} conversion rate dropped by {drop_rate:.1%}",
                    product
                )


def send_alert(alert_type: str, message: str, data: Dict[str, Any]) -> None:
    """Send alert notification."""
    alert = {
        'type': alert_type,
        'message': message,
        'data': data,
        'timestamp': datetime.now().isoformat()
    }
    
    logger.warning(f"ALERT: {alert}")
    
    # Send email if configured
    email = alert_config.get('notification_email')
    if email:
        try:
            send_email(email, f"Douyin Monitor Alert: {alert_type}", message)
        except Exception as e:
            logger.error(f"Failed to send alert email: {e}")


def send_email(to: str, subject: str, body: str) -> None:
    """Send email notification (placeholder - implement with SMTP)."""
    # In production, use smtplib or a service like SendGrid
    logger.info(f"Would send email to {to}: {subject} - {body}")


def scheduled_job() -> None:
    """Main scheduled job to fetch all data and check alerts."""
    logger.info("Running scheduled job...")
    fetch_and_store_products()
    fetch_and_store_orders()
    fetch_and_store_creators()
    check_alerts()
    data_cache['last_update'] = datetime.now().isoformat()
    logger.info("Scheduled job completed")


# Initialize scheduler
scheduler = BackgroundScheduler()
scheduler.add_job(
    scheduled_job,
    trigger=IntervalTrigger(minutes=Config.SCHEDULE_INTERVAL_MINUTES),
    id='douyin_data_fetch',
    name='Fetch Douyin data and check alerts',
    replace_existing=True
)


# API Routes
@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint."""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'last_update': data_cache['last_update']
    })

@app.route('/api/products/stats', methods=['GET'])
def get_product_stats():
    """获取商品统计信息（调用外部 API）。"""
    endpoint = f"{Config.FXG_BASE_URL}/products/stats"
    params = {
        'tab': request.args.get('tab', 'onSale'),
        'appid': request.args.get('appid', '1')
    }
    headers = Config.COMMON_HEADERS.copy()
    cookies = {}
    if Config.FXG_COOKIES:
        for pair in Config.FXG_COOKIES.split(';'):
            if '=' in pair:
                k, v = pair.strip().split('=', 1)
                cookies[k] = v
    result = _request(endpoint, params=params, headers=headers, cookies=cookies)
    return jsonify({
        'success': True,
        'data': result.get('data', {}),
        'message': 'Product stats fetched from external service'
    })


@app.route('/api/products', methods=['GET'])
def get_products():
    """Get product list from internal cache with optional filtering."""
    page = int(request.args.get('page', 1))
    size = int(request.args.get('size', 20))
    keyword = request.args.get('keyword', '').lower()
    
    products = data_cache['products']
    
    if keyword:
        products = [p for p in products if keyword in p.get('product_name', '').lower()]
    
    total = len(products)
    start = (page - 1) * size
    end = start + size
    
    return jsonify({
        'data': products[start:end],
        'total': total,
        'page': page,
        'size': size
    })

# -------------------------------------------------------------------
# 新增：外部商品列表转发接口（完整参数透传）
@app.route('/api/products/external', methods=['GET'])
def get_external_product_list():
    """转发商品列表请求到外部 API，使用 fxg 基础 URL、统一 Header 与 Cookie。"""
    params = request.args.to_dict(flat=True)
    endpoint = f"{Config.FXG_BASE_URL}/product/tproduct/list"
    # 使用统一请求头和 Cookie
    headers = Config.COMMON_HEADERS.copy()
    cookies = {}
    if Config.FXG_COOKIES:
        # 将 Cookie 字符串解析为 dict（简单分号分割）
        for pair in Config.FXG_COOKIES.split(';'):
            if '=' in pair:
                k, v = pair.strip().split('=', 1)
                cookies[k] = v
    result = _request(endpoint, params=params)
    # Note: _request currently does not attach headers/cookies; we will extend it later if needed.
    return jsonify({
        'success': True,
        'data': result.get('data', {}),
        'message': 'Product list fetched from external service'
    })


@app.route('/api/products/<product_id>', methods=['GET'])
def get_product(product_id: str):
    """Get single product details."""
    product = next((p for p in data_cache['products'] if p.get('product_id') == product_id), None)
    if not product:
        return jsonify({'error': 'Product not found'}), 404
    return jsonify({'data': product})


@app.route('/api/orders', methods=['GET'])
def get_orders():
    """Get order list with optional filtering and summary statistics."""
    page = int(request.args.get('page', 1))
    size = int(request.args.get('size', 20))
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    status_filter = request.args.get('status')
    
    orders = data_cache['orders']
    
    # 过滤时间范围
    if start_date:
        orders = [o for o in orders if o.get('create_time', '') >= start_date]
    if end_date:
        orders = [o for o in orders if o.get('create_time', '') <= end_date]
    
    # 过滤状态（保持向后兼容）
    if status_filter:
        orders = [o for o in orders if o.get('status') == status_filter]
    
    total = len(orders)
    start = (page - 1) * size
    end = start + size
    
    # 统计汇总（示例实现，仅返回 all，其他分类默认 0）
    summary = {
        'abnormal': {'amount': 0, 'count': 0},
        'after_sale': {'amount': 0, 'count': 0},
        'all': {'amount': sum(o.get('amount', 0) for o in orders), 'count': total},
        'closed': {'amount': 0, 'count': 0},
        'done': {'amount': 0, 'count': 0},
        'sent': {'amount': 0, 'count': 0},
        'timeout_send': {'amount': 0, 'count': 0},
        'urgent_send': {'amount': 0, 'count': 0},
        'wait_pay': {'amount': 0, 'count': 0},
        'wait_send': {'amount': 0, 'count': 0},
    }
    
    return jsonify({
        'success': True,
        'data': summary,
        'list': orders[start:end],
        'total': total,
        'page': page,
        'size': size
    })

# -------------------------------------------------------------------
# 新增：外部订单统计转发接口（完整参数透传）
@app.route('/api/orders/stats', methods=['GET'])
def get_external_order_stats():
    """转发订单统计请求到外部 API，使用 fxg 基础 URL、统一 Header 与 Cookie。"""
    params = request.args.to_dict(flat=True)
    endpoint = f"{Config.FXG_BASE_URL}/api/order/tabcnt"
    headers = Config.COMMON_HEADERS.copy()
    cookies = {}
    if Config.FXG_COOKIES:
        for pair in Config.FXG_COOKIES.split(';'):
            if '=' in pair:
                k, v = pair.strip().split('=', 1)
                cookies[k] = v
    result = _request(endpoint, params=params, headers=headers, cookies=cookies)
    return jsonify({
        'success': True,
        'data': result.get('data', {}),
        'message': 'Order stats fetched from external service'
    })


@app.route('/api/creators', methods=['GET'])
def get_creators():
    """Get creator list."""
    return jsonify({
        'data': data_cache['creators'],
        'total': len(data_cache['creators'])
    })


@app.route('/api/creators/<creator_id>', methods=['GET'])
def get_creator(creator_id: str):
    """Get single creator details."""
    creator = next((c for c in data_cache['creators'] if c.get('creator_id') == creator_id), None)
    if not creator:
        return jsonify({'error': 'Creator not found'}), 404
    return jsonify({'data': creator})


@app.route('/api/dashboard/stats', methods=['GET'])
def get_dashboard_stats():
    """Get dashboard statistics."""
    products = data_cache['products']
    orders = data_cache['orders']
    
    total_sales_today = sum(p.get('sales_today', 0) for p in products)
    total_sales_yesterday = sum(p.get('sales_yesterday', 0) for p in products)
    total_revenue_today = sum(o.get('amount', 0) for o in orders)
    # 没有历史订单数据，暂时使用今天的金额作为昨天的占位
    total_revenue_yesterday = total_revenue_today
    total_orders_today = len(orders)
    total_orders_yesterday = total_orders_today
    avg_conversion_today = sum(p.get('conversion_rate', 0) for p in products) / len(products) if products else 0
    avg_conversion_yesterday = sum(p.get('conversion_rate_yesterday', p.get('conversion_rate',0)) for p in products) / len(products) if products else 0
    
    # Sales trend (last 7 天) - 模拟
    sales_trend = [
        {'date': (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d'), 'sales': total_sales_today - i * 10}
        for i in range(6, -1, -1)
    ]
    
    # TOP 商品
    top_products = sorted(products, key=lambda p: p.get('sales_today', 0), reverse=True)[:5]
    
    return jsonify({
        'data': {
            'total_sales_today': total_sales_today,
            'total_sales_yesterday': total_sales_yesterday,
            'total_revenue_today': total_revenue_today,
            'total_revenue_yesterday': total_revenue_yesterday,
            'total_orders_today': total_orders_today,
            'total_orders_yesterday': total_orders_yesterday,
            'avg_conversion_rate': round(avg_conversion_today, 4),
            'avg_conversion_rate_yesterday': round(avg_conversion_yesterday, 4),
            'sales_trend': sales_trend,
            'top_products': top_products
        }
    })


@app.route('/api/alerts/config', methods=['GET'])
def get_alert_config():
    """Get alert configuration."""
    return jsonify({'data': alert_config})


@app.route('/api/alerts/config', methods=['POST'])
def update_alert_config():
    """Update alert configuration."""
    global alert_config
    new_config = request.get_json()
    
    if not new_config:
        return jsonify({'error': 'Invalid config'}), 400
    
    # Validate required fields
    allowed_fields = [
        'sales_drop_threshold',
        'conversion_drop_threshold',
        'inventory_low_threshold',
        'notification_email',
        'enabled'
    ]
    
    for key, value in new_config.items():
        if key in allowed_fields:
            alert_config[key] = value
    
    save_json_file(ALERT_CONFIG_FILE, alert_config)
    return jsonify({'data': alert_config, 'message': 'Alert config updated'})


@app.route('/api/sync', methods=['POST'])
def manual_sync():
    """Manually trigger data synchronization."""
    scheduled_job()
    return jsonify({'message': 'Sync completed', 'last_update': data_cache['last_update']})


# Serve React frontend
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_frontend(path):
    """Serve React frontend for all non-API routes."""
    if path.startswith('api/'):
        return jsonify({'error': 'Not found'}), 404
    
    if path and (app.static_folder / path).exists():
        return send_from_directory(app.static_folder, path)
    
    return send_from_directory(app.static_folder, 'index.html')


def create_app() -> Flask:
    """Application factory."""
    load_all_data()
    scheduler.start()
    logger.info("Application started")
    return app


if __name__ == '__main__':
    app = create_app()
    app.run(host='0.0.0.0', port=5000, debug=False)