# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial project structure
- Flask API server with endpoints: shop-stats, products, creator, orders, refresh
- APScheduler for periodic data fetching (0,6,12,18 UTC)
- Email alert system via SMTP
- Docker support with multi-stage build
- GitHub Actions CI pipeline
- Pre-commit hooks (black, flake8, mypy)
- Comprehensive documentation

### Changed
- Improved cookie parsing to support Netscape format
- Enhanced error handling with fallback to mock data

### Fixed
- N/A (initial release)

## [0.1.0] - 2024-06-15

### Added
- Basic data fetching from Douyin/Doudian APIs
- Configuration management via .env
- Systemd service file for production deployment

[Unreleased]: https://github.com/yourusername/doudian_monitor/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/yourusername/doudian_monitor/releases/tag/v0.1.0