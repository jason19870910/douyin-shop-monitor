import json
import logging
import os
import requests
from datetime import datetime, timedelta
from pathlib import Path
from celery import shared_task
from celery_config import celery_app

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load environment variables
from dotenv import load_dotenv
load_dotenv()

# Data storage paths
DATA_DIR = Path(os.getenv('DATA_DIR', '/data'))

PRODUCTS_FILE = DATA_DIR / 'products.json'
ORDERS_FILE = DATA_DIR / 'orders.json'
CREATORS_FILE = DATA_DIR / 'creators.json'
ALERT_CONFIG_FILE = DATA_DIR / 'alert_config.json'

# External API Configuration (from .env)
FXG_BASE_URL = os.getenv('FXG_BASE_URL', 'https://fxg.jinritemai.com')
CREATOR_BASE_URL = os.getenv('CREATOR_BASE_URL', 'https://creator.douyin.com')

# Common headers for external API
COMMON_HEADERS = {
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
    "Priority": "u=1, i",
    "User-Agent": os.getenv('USER_AGENT', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36')
}

# Default alert configuration
DEFAULT_ALERT_CONFIG = {
    'sales_drop_threshold': 0.3,
    'conversion_drop_threshold': 0.2,
    'inventory_low_threshold': 10,
    'notification_email': os.getenv('ALERT_EMAIL', ''),
    'enabled': True
}


def load_json_file(file_path: Path, default=None):
    """Load JSON file, return default if not exists."""
    if file_path.exists():
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except json.JSONDecodeError:
            logger.error(f"Failed to parse JSON from {file_path}")
            return default
    return default


def save_json_file(file_path: Path, data):
    """Save data to JSON file."""
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"Failed to save JSON to {file_path}: {e}")


def get_alert_config():
    """Get current alert configuration."""
    return load_json_file(ALERT_CONFIG_FILE, DEFAULT_ALERT_CONFIG)


def parse_cookies(cookie_str: str) -> dict:
    """Parse cookie string to dict."""
    cookies = {}
    if not cookie_str:
        return cookies
    for pair in cookie_str.split(';'):
        pair = pair.strip()
        if '=' in pair:
            k, v = pair.split('=', 1)
            cookies[k.strip()] = v.strip()
    return cookies


def get_fxg_cookies() -> dict:
    """Get fxg.jinritemai.com cookies."""
    return parse_cookies(os.getenv('FXG_COOKIES', ''))


def get_creator_cookies() -> dict:
    """Get creator.douyin.com cookies."""
    return parse_cookies(os.getenv('CREATOR_COOKIES', ''))


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def fetch_products_task(self):
    """Celery task to fetch products from external FXG API."""
    logger.info("Fetching products from external FXG API...")
    
    try:
        url = f'{FXG_BASE_URL}/product/tproduct/list'
        params = {'page': 1, 'pageSize': 100}
        cookies = get_fxg_cookies()
        
        response = requests.get(url, headers=COMMON_HEADERS, params=params, cookies=cookies, timeout=30)
        response.raise_for_status()
        result = response.json()
        
        products = result.get('data', {}).get('products', [])
        
        # Transform and store
        for product in products:
            product['fetched_at'] = datetime.now().isoformat()
            product['sales_today'] = product.get('sales_today', 0)
            product['sales_yesterday'] = product.get('sales_yesterday', 0)
            product['inventory'] = product.get('inventory', 0)
            product['conversion_rate'] = product.get('conversion_rate', 0.0)
            product['conversion_rate_today'] = product.get('conversion_rate_today', 0.0)
            product['conversion_rate_yesterday'] = product.get('conversion_rate_yesterday', 0.0)
        
        save_json_file(PRODUCTS_FILE, products)
        logger.info(f"Fetched and stored {len(products)} products")
        
        return {'status': 'success', 'count': len(products)}
        
    except requests.RequestException as e:
        logger.error(f"Failed to fetch products: {e}")
        raise self.retry(exc=e)


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def fetch_orders_task(self):
    """Celery task to fetch orders from external FXG API."""
    logger.info("Fetching orders from external FXG API...")
    
    try:
        end_time = int(datetime.now().timestamp())
        start_time = int((datetime.now() - timedelta(days=1)).timestamp())
        
        url = f'{FXG_BASE_URL}/api/order/searchlist'
        params = {
            'start_time': start_time,
            'end_time': end_time,
            'page': 1,
            'size': 100
        }
        cookies = get_fxg_cookies()
        
        response = requests.get(url, headers=COMMON_HEADERS, params=params, cookies=cookies, timeout=30)
        response.raise_for_status()
        result = response.json()
        
        orders = result.get('data', {}).get('orders', [])
        
        # Transform and store
        for order in orders:
            order['fetched_at'] = datetime.now().isoformat()
        
        save_json_file(ORDERS_FILE, orders)
        logger.info(f"Fetched and stored {len(orders)} orders")
        
        return {'status': 'success', 'count': len(orders)}
        
    except requests.RequestException as e:
        logger.error(f"Failed to fetch orders: {e}")
        raise self.retry(exc=e)


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def fetch_creators_task(self):
    """Celery task to fetch creator data from external Creator API."""
    logger.info("Fetching creators from external Creator API...")
    
    try:
        url = f'{CREATOR_BASE_URL}/janus/douyin/creator/data/overview/dashboard'
        # POST 请求，body 包含 recent_days
        payload = {"recent_days": 7}
        cookies = get_creator_cookies()
        
        # Creator API 需要 POST
        response = requests.post(url, headers=COMMON_HEADERS, json=payload, cookies=cookies, timeout=30)
        response.raise_for_status()
        result = response.json()
        
        creators = result.get('data', {}).get('creators', [])
        
        # Ensure each creator has fetched_at timestamp
        for creator in creators:
            creator['fetched_at'] = datetime.now().isoformat()
        
        save_json_file(CREATORS_FILE, creators)
        logger.info(f"Fetched and stored {len(creators)} creators")
        
        return {'status': 'success', 'count': len(creators)}
        
    except requests.RequestException as e:
        logger.error(f"Failed to fetch creators: {e}")
        raise self.retry(exc=e)


@shared_task
def check_alerts_task():
    """Celery task to check alert conditions."""
    logger.info("Checking alert conditions...")
    
    alert_config = get_alert_config()
    
    if not alert_config.get('enabled', True):
        return {'status': 'skipped', 'reason': 'alerts disabled'}
    
    products = load_json_file(PRODUCTS_FILE, [])
    alerts_triggered = []
    
    for product in products:
        product_name = product.get('product_name', 'Unknown')
        product_id = product.get('product_id', '')
        
        # Check sales drop
        sales_today = product.get('sales_today', 0)
        sales_yesterday = product.get('sales_yesterday', 0)
        
        if sales_yesterday > 0:
            drop_rate = (sales_yesterday - sales_today) / sales_yesterday
            if drop_rate >= alert_config['sales_drop_threshold']:
                alert = {
                    'type': 'sales_drop',
                    'product_id': product_id,
                    'product_name': product_name,
                    'message': f"Product {product_name} sales dropped by {drop_rate:.1%}",
                    'drop_rate': drop_rate,
                    'threshold': alert_config['sales_drop_threshold'],
                    'timestamp': datetime.now().isoformat()
                }
                alerts_triggered.append(alert)
                send_alert_notification(alert)
        
        # Check inventory
        inventory = product.get('inventory', 0)
        if inventory <= alert_config['inventory_low_threshold']:
            alert = {
                'type': 'low_inventory',
                'product_id': product_id,
                'product_name': product_name,
                'message': f"Product {product_name} inventory low: {inventory}",
                'inventory': inventory,
                'threshold': alert_config['inventory_low_threshold'],
                'timestamp': datetime.now().isoformat()
            }
            alerts_triggered.append(alert)
            send_alert_notification(alert)
        
        # Check conversion rate drop
        conv_today = product.get('conversion_rate_today', 0)
        conv_yesterday = product.get('conversion_rate_yesterday', 0)
        
        if conv_yesterday > 0:
            drop_rate = (conv_yesterday - conv_today) / conv_yesterday
            if drop_rate >= alert_config['conversion_drop_threshold']:
                alert = {
                    'type': 'conversion_drop',
                    'product_id': product_id,
                    'product_name': product_name,
                    'message': f"Product {product_name} conversion rate dropped by {drop_rate:.1%}",
                    'drop_rate': drop_rate,
                    'threshold': alert_config['conversion_drop_threshold'],
                    'timestamp': datetime.now().isoformat()
                }
                alerts_triggered.append(alert)
                send_alert_notification(alert)
    
    logger.info(f"Alert check completed. Triggered {len(alerts_triggered)} alerts")
    return {'status': 'success', 'alerts_triggered': len(alerts_triggered)}


def send_alert_notification(alert):
    """Send alert notification via email."""
    alert_config = get_alert_config()
    email = alert_config.get('notification_email')
    
    if email:
        try:
            # In production, use smtplib or email service
            logger.info(f"ALERT EMAIL to {email}: {alert['message']}")
            # send_email(email, f"Douyin Monitor Alert: {alert['type']}", alert['message'])
        except Exception as e:
            logger.error(f"Failed to send alert email: {e}")


@shared_task
def full_sync_task():
    """Celery task to run full data synchronization."""
    logger.info("Running full synchronization...")
    
    # Chain tasks
    fetch_products_task.delay()
    fetch_orders_task.delay()
    fetch_creators_task.delay()
    
    # Check alerts after a short delay
    check_alerts_task.apply_async(countdown=10)
    
    return {'status': 'started', 'message': 'Full sync initiated'}


# Register tasks
celery_app.tasks.register(fetch_products_task)
celery_app.tasks.register(fetch_orders_task)
celery_app.tasks.register(fetch_creators_task)
celery_app.tasks.register(check_alerts_task)
celery_app.tasks.register(full_sync_task)