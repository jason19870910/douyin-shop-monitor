import React, { useState } from 'react';
import { Card, Table, Input, Button, Select, Space, Spin, Tag, Popconfirm, message } from 'antd';
import { SearchOutlined, ReloadOutlined, DownloadOutlined } from '@ant-design/icons';
import { productApi } from '../api';
import { useApi } from '../hooks/useApi';
import { formatNumber, formatCurrency, formatPercent, formatDateTime } from '../utils/formatters';

const columns = [
  {
    title: '商品ID',
    dataIndex: 'product_id',
    key: 'product_id',
    width: 120,
  },
  {
    title: '商品名称',
    dataIndex: 'product_name',
    key: 'product_name',
    width: 200,
    ellipsis: true,
  },
  {
    title: '分类',
    dataIndex: 'category',
    key: 'category',
    width: 120,
  },
  {
    title: '价格',
    dataIndex: 'price',
    key: 'price',
    align: 'right',
    width: 100,
    render: formatCurrency,
  },
  {
    title: '今日销量',
    dataIndex: 'sales_today',
    key: 'sales_today',
    align: 'right',
    width: 100,
    render: formatNumber,
  },
  {
    title: '昨日销量',
    dataIndex: 'sales_yesterday',
    key: 'sales_yesterday',
    align: 'right',
    width: 100,
    render: formatNumber,
  },
  {
    title: '销量变化',
    dataIndex: 'sales_change',
    key: 'sales_change',
    align: 'right',
    width: 100,
    render: (_, record) => {
      const change = record.sales_today - record.sales_yesterday;
      const color = change > 0 ? '#ff4d4f' : change < 0 ? '#52c41a' : '#595959';
      const prefix = change > 0 ? '+' : '';
      return <span style={{ color, fontWeight: 500 }}>{prefix}{formatNumber(change)}</span>;
    },
  },
  {
    title: '库存',
    dataIndex: 'inventory',
    key: 'inventory',
    align: 'right',
    width: 100,
    render: (value, record) => (
      <span style={{ color: value <= 10 ? '#ff4d4f' : '#595959', fontWeight: value <= 10 ? 600 : 400 }}>
        {formatNumber(value)}
        {value <= 10 && <Tag style={{ marginLeft: 4, fontSize: 10 }}>低库存</Tag>}
      </span>
    ),
  },
  {
    title: '转化率',
    dataIndex: 'conversion_rate',
    key: 'conversion_rate',
    align: 'right',
    width: 100,
    render: formatPercent,
  },
  {
    title: '更新时间',
    dataIndex: 'fetched_at',
    key: 'fetched_at',
    width: 160,
    render: formatDateTime,
  },
];

const Products = () => {
  const [searchText, setSearchText] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [sortOrder, setSortOrder] = useState('descend');

  const { data, loading, error, refetch } = useApi(
    () => productApi.getList({ page, size: pageSize, keyword: searchText }),
    [page, pageSize, searchText]
  );

  const handleSearch = (e) => {
    setSearchText(e.target.value);
    setPage(1);
  };

  const handleTableChange = (pagination, filters, sorter) => {
    if (pagination) {
      setPage(pagination.current);
      setPageSize(pagination.pageSize);
    }
    if (sorter && sorter.order) {
      setSortOrder(sorter.order === 'ascend' ? 'ascend' : 'descend');
    }
  };

  const handleExport = async () => {
    try {
      message.loading('导出中...', 0);
      const result = await productApi.getList({ page: 1, size: 10000, keyword: searchText });
      message.destroy();
      
      const csvContent = [
        ['商品ID', '商品名称', '分类', '价格', '今日销量', '昨日销量', '库存', '转化率', '更新时间'],
        ...(result.data || []).map(p => [
          p.product_id,
          p.product_name,
          p.category,
          p.price,
          p.sales_today,
          p.sales_yesterday,
          p.inventory,
          p.conversion_rate,
          p.fetched_at,
        ]),
      ].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
      
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `products_${new Date().toISOString().split('T')[0]}.csv`;
      link.click();
      message.success('导出成功');
    } catch (err) {
      message.destroy();
      message.error('导出失败');
    }
  };

  if (loading && !data) {
    return <Spin size="large" tip="加载商品数据..." />;
  }

  if (error) {
    return (
      <Card>
        <div style={{ textAlign: 'center', padding: 40 }}>
          <p style={{ color: '#ff4d4f' }}>加载失败: {error.message}</p>
          <Button type="primary" onClick={refetch} icon={<ReloadOutlined />}>
            重试
          </Button>
        </div>
      </Card>
    );
  }

  const products = data?.data || [];
  const total = data?.total || 0;

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">商品管理</h1>
        <Space>
          <Input
            placeholder="搜索商品名称..."
            value={searchText}
            onChange={handleSearch}
            prefix={<SearchOutlined />}
            style={{ width: 250 }}
            allowClear
          />
          <Button icon={<DownloadOutlined />} onClick={handleExport}>导出 CSV</Button>
          <Button icon={<ReloadOutlined />} onClick={refetch} loading={loading}>刷新</Button>
        </Space>
      </div>

      <Card className="table-container">
        <Table
          columns={columns}
          dataSource={products}
          pagination={{
            current: page,
            pageSize,
            total,
            showSizeChanger: true,
            showQuickJumper: true,
            showTotal: (total) => `共 ${total} 条`,
          }}
          onChange={handleTableChange}
          rowKey="product_id"
          loading={loading}
          scroll={{ x: 1300 }}
        />
      </Card>
    </div>
  );
};

export default Products;