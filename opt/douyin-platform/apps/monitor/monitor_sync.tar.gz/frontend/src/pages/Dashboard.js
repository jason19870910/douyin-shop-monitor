import React, { useState, useEffect, useCallback } from 'react';
import { Card, Row, Col, Statistic, Spin, Alert, Empty, Button, Table, Tag } from 'antd';
import {
  DashboardOutlined,
  ShoppingOutlined,
  ShoppingCartOutlined,
  UserOutlined,
  SettingOutlined,
  SyncOutlined,
  ClockCircleOutlined,
  TeamOutlined,
  DollarOutlined,
  RiseOutlined,
  FallOutlined,
} from '@ant-design/icons';
import { dashboardApi, syncApi, healthApi, productApi, orderApi } from '../api';
import { useApi, usePolling } from '../hooks/useApi';
import { formatNumber, formatCurrency, formatPercent, formatDateTime } from '../utils/formatters';

// 数据统计卡片
const StatCard = ({ label, value, trend, trendLabel, prefix, suffix, loading, error }) => (
  <Card className="stat-card">
    <div className="label">{label}</div>
    <Statistic
      value={value}
      prefix={prefix}
      suffix={suffix}
      loading={loading}
      valueStyle={{ fontSize: 28, fontWeight: 600 }}
    />
    {trend !== undefined && (
      <div className={`trend ${trend > 0 ? 'up' : trend < 0 ? 'down' : ''}`}>
        {trend > 0 ? '↑' : trend < 0 ? '↓' : '→'} {Math.abs(trend).toFixed(1)}% {trendLabel}
      </div>
    )}
    {error && <Alert message="加载失败" description={error.message} type="error" />}
  </Card>
);

// 销售趋势图表
const SalesTrendChart = ({ data }) => {
  if (!data || data.length === 0) return null;

  return (
    <Card className="chart-container">
      <div className="chart-title">销售趋势 (近7天)</div>
      <ResponsiveContainer width="100%" height={280}>
        <AreaChart data={data}>
          <defs>
            <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#1890ff" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#1890ff" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
          <XAxis dataKey="date" stroke="#999" fontSize={12} />
          <YAxis stroke="#999" fontSize={12} formatter={(value) => formatNumber(value)} />
          <Tooltip formatter={(value) => [formatNumber(value), '销量']} />
          <Area
            type="monotone"
            dataKey="sales"
            stroke="#1890ff"
            fillOpacity={1}
            fill="url(#colorSales)"
            strokeWidth={2}
            dot={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </Card>
  );
};

// 商品统计卡
const ProductStat = ({ product, label, icon }) => (
  <Card className="stat-card">
    <div className="label">{label}</div>
    <Statistic
      value={icon}
      valueStyle={{ fontSize: 24, color: '#1890ff' }}
    />
  </Card>
);

const Dashboard = () => {
  const { data: stats, loading: statsLoading, error: statsError, refetch: refetchStats } = useApi(dashboardApi.getStats);
  const { data: products, loading: productsLoading, error: productsError, refetch: refetchProducts } = useApi(productApi.getList);
  const { data: orders, loading: ordersLoading, error: ordersError, refetch: refetchOrders } = useApi(orderApi.getList);

  const [selectedPeriod, setSelectedPeriod] = useState('7d');
  const [refreshLoading, setRefreshLoading] = useState(false);

-  // handleRefresh functionality removed for simplicity
+  // Refresh button handler
+  const handleRefresh = async () => {
+    setRefreshLoading(true);
+    await Promise.all([
+      refetchStats(),
+      refetchProducts(),
+      refetchOrders(),
+    ]);
+    setRefreshLoading(false);
+  };


  // 计算统计
  const totalSales = stats?.data?.total_sales_today || 0;
  const totalRevenue = stats?.data?.total_revenue_today || 0;
  const totalOrders = stats?.data?.total_orders_today || 0;
  const avgConversion = stats?.data?.avg_conversion_rate || 0;

  const salesTrend = stats?.data?.sales_trend || [];
  const topProducts = stats?.data?.top_products || [];

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">📊 仪表盘</h1>
        <Space wrap>
          <Button icon={<SyncOutlined />} onClick={handleRefresh} loading={refreshLoading}>
            立即同步
          </Button>
        </Space>
      </div>

      {/* 统计卡片 */}
      <Row gutter={[16, 16]} className="card-grid">
        <Col xs={24} sm={12} lg={6}>
          <StatCard
            label="今日总销量"
            value={formatNumber(totalSales)}
            trend={calculateGrowth(totalSales, null)}
            trendLabel="较昨日"
          />
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <StatCard
            label="今日总收入"
            value={formatCurrency(totalRevenue)}
            prefix="¥"
            trend={calculateGrowth(totalRevenue, null)}
            trendLabel="较昨日"
          />
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <StatCard
            label="今日订单数"
            value={formatNumber(totalOrders)}
            trend={calculateGrowth(totalOrders, stats?.data?.total_orders_yesterday)}
            trendLabel="较昨日"
          />
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <StatCard
            label="平均转化率"
            value={formatPercent(avgConversion)}
            trend={calculateGrowth(avgConversion, stats?.data?.avg_conversion_rate_yesterday)}
            trendLabel="较昨日"
          />
        </Col>
      </Row>

      {/* 销售趋势图 */}
      <SalesTrendChart data={salesTrend} />

      {/* 产品列表 */}
      <Card className="chart-container">
        <div className="chart-title">热销商品 TOP 5</div>
        {productsLoading ? (
          <Spin size="large" tip="加载商品数据..." />
        ) : productsError ? (
          <Alert message="加载失败" description={productsError.message} type="error" />
        ) : (
          <Row gutter={[16, 16]}>
            {topProducts.slice(0, 5).map((product) => (
              <Col key={product.product_id} xs={24} sm={12} md={8} lg={8}>
                <Card>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontWeight: 500 }}>{product.product_name}</span>
                    {product.inventory <= 10 && (
                      <Tag color="red" style={{ fontSize: 10 }}>低库存</Tag>
                    )}
                  </div>
                  <div style={{ display: 'flex', gap: 16, marginTop: 8 }}>
                    <span style={{ color: '#1890ff', fontWeight: 500 }}>
                      {formatNumber(product.sales_today)}
                    </span>
                    <span style={{ color: '#595959' }}>{formatNumber(product.sales_yesterday)} 昨日</span>
                  </div>
                  <div style={{ fontSize: 12, color: '#8c8c8c', marginTop: 4 }}>
                    转化率: {formatPercent(product.conversion_rate)} | 库存: {formatNumber(product.inventory)}件
                  </div>
                </Card>
              </Col>
            ))}
          </Row>
        )}
      </Card>

      {/* 订单看板 */}
      <Card className="chart-container">
        <div className="chart-title">订单看板</div>
        {ordersLoading ? (
          <Spin size="large" tip="加载订单数据..." />
        ) : ordersError ? (
          <Alert message="加载失败" description={ordersError.message} type="error" />
        ) : (
          <Table
            dataSource={orders}
            columns={[
              { title: '订单ID', dataIndex: 'order_id', key: 'order_id', width: 120 },
              { title: '商品名称', dataIndex: 'product_name', key: 'product_name', ellipsis: true },
              { title: '金额', dataIndex: 'amount', key: 'amount', align: 'right', render: formatCurrency },
              { title: '状态', dataIndex: 'status', key: 'status', align: 'center', render: (status) => {
                const statusMap = {
                  'completed': { color: 'green', text: '已完成' },
                  'pending': { color: 'orange', text: '待处理' },
                };
                return <Tag color={statusMap[status]?.color || 'default'}>{statusMap[status]?.text || status}</Tag>;
              }},
              { title: '下单时间', dataIndex: 'create_time', key: 'create_time', width: 180, render: formatDateTime },
            ]}
            pagination={{
              pageSize: 10,
              showSizeChanger: false,
              showTotal: (total) => `共 ${total} 条`,
              showQuickJumper: true,
            }}
            loading={ordersLoading}
          />
        )}
      </Card>
    </div>
  );
};

function calculateGrowth(current, previous) {
  if (!previous || previous === 0) return 0;
  return ((current - previous) / previous) * 100;
}

export default Dashboard;