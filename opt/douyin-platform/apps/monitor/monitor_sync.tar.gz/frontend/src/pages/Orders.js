import React, { useState } from 'react';
import { Card, Table, Input, Button, Select, Space, Spin, DatePicker, message, Tag } from 'antd';
import { SearchOutlined, ReloadOutlined, DownloadOutlined } from '@ant-design/icons';
import { orderApi } from '../api';
import { useApi } from '../hooks/useApi';
import { formatNumber, formatCurrency, formatDateTime } from '../utils/formatters';

const { RangePicker } = DatePicker;

const columns = [
  {
    title: '订单ID',
    dataIndex: 'order_id',
    key: 'order_id',
    width: 150,
  },
  {
    title: '商品名称',
    dataIndex: 'product_name',
    key: 'product_name',
    width: 200,
    ellipsis: true,
  },
  {
    title: '创作者',
    dataIndex: 'creator_name',
    key: 'creator_name',
    width: 150,
  },
  {
    title: '金额',
    dataIndex: 'amount',
    key: 'amount',
    align: 'right',
    width: 120,
    render: formatCurrency,
  },
  {
    title: '数量',
    dataIndex: 'quantity',
    key: 'quantity',
    align: 'right',
    width: 80,
    render: formatNumber,
  },
  {
    title: '状态',
    dataIndex: 'status',
    key: 'status',
    width: 100,
    align: 'center',
    render: (status) => {
      const statusMap = {
        'completed': { color: 'green', text: '已完成' },
        'pending': { color: 'orange', text: '待处理' },
        'cancelled': { color: 'red', text: '已取消' },
        'refunded': { color: 'blue', text: '已退款' },
      };
      const s = statusMap[status] || { color: 'default', text: status };
      return <Tag color={s.color}>{s.text}</Tag>;
    },
  },
  {
    title: '下单时间',
    dataIndex: 'create_time',
    key: 'create_time',
    width: 180,
    render: formatDateTime,
  },
  {
    title: '更新时间',
    dataIndex: 'update_time',
    key: 'update_time',
    width: 180,
    render: formatDateTime,
  },
];

const Orders = () => {
  const [searchText, setSearchText] = useState('');
  const [dateRange, setDateRange] = useState([]);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [statusFilter, setStatusFilter] = useState('');

  const { data, loading, error, refetch } = useApi(
    () => orderApi.getList({ 
      page, 
      size: pageSize, 
      keyword: searchText,
      start_date: dateRange[0]?.format('YYYY-MM-DD'),
      end_date: dateRange[1]?.format('YYYY-MM-DD'),
      status: statusFilter,
    }),
    [page, pageSize, searchText, dateRange, statusFilter]
  );

  const handleSearch = (e) => {
    setSearchText(e.target.value);
    setPage(1);
  };

  const handleDateChange = (dates) => {
    setDateRange(dates);
    setPage(1);
  };

  const handleStatusChange = (value) => {
    setStatusFilter(value);
    setPage(1);
  };

  const handleTableChange = (pagination) => {
    if (pagination) {
      setPage(pagination.current);
      setPageSize(pagination.pageSize);
    }
  };

  const handleExport = async () => {
    try {
      message.loading('导出中...', 0);
      const result = await orderApi.getList({ 
        page: 1, 
        size: 10000, 
        keyword: searchText,
        start_date: dateRange[0]?.format('YYYY-MM-DD'),
        end_date: dateRange[1]?.format('YYYY-MM-DD'),
        status: statusFilter,
      });
      message.destroy();
      
      const csvContent = [
        ['订单ID', '商品名称', '创作者', '金额', '数量', '状态', '下单时间', '更新时间'],
        ...(result.data || []).map(o => [
          o.order_id,
          o.product_name,
          o.creator_name,
          o.amount,
          o.quantity,
          o.status,
          o.create_time,
          o.update_time,
        ]),
      ].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
      
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `orders_${new Date().toISOString().split('T')[0]}.csv`;
      link.click();
      message.success('导出成功');
    } catch (err) {
      message.destroy();
      message.error('导出失败');
    }
  };

  if (loading && !data) {
    return <Spin size="large" tip="加载订单数据..." />;
  }

  if (error) {
    return (
      <Card>
        <div style={{ textAlign: 'center', padding: 40 }}>
          <p style={{ color: '#ff4d4f' }}>加载失败: {error.message}</p>
          <Button type="primary" onClick={refetch} icon={<ReloadOutlined />}>
            重试
          </Button>
        </div>
      </Card>
    );
  }

  const orders = data?.data || [];
  const total = data?.total || 0;

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">订单管理</h1>
        <Space wrap>
          <Input
            placeholder="搜索商品/创作者..."
            value={searchText}
            onChange={handleSearch}
            prefix={<SearchOutlined />}
            style={{ width: 250 }}
            allowClear
          />
          <RangePicker
            value={dateRange}
            onChange={handleDateChange}
            placeholder={['开始日期', '结束日期']}
            style={{ width: 300 }}
            allowClear
          />
          <Select
            placeholder="订单状态"
            value={statusFilter}
            onChange={handleStatusChange}
            allowClear
            style={{ width: 140 }}
            options={[
              { value: 'completed', label: '已完成' },
              { value: 'pending', label: '待处理' },
              { value: 'cancelled', label: '已取消' },
              { value: 'refunded', label: '已退款' },
            ]}
          />
          <Button icon={<DownloadOutlined />} onClick={handleExport}>导出 CSV</Button>
          <Button icon={<ReloadOutlined />} onClick={refetch} loading={loading}>刷新</Button>
        </Space>
      </div>

      <Card className="table-container">
        <Table
          columns={columns}
          dataSource={orders}
          pagination={{
            current: page,
            pageSize,
            total,
            showSizeChanger: true,
            showQuickJumper: true,
            showTotal: (total) => `共 ${total} 条`,
          }}
          onChange={handleTableChange}
          rowKey="order_id"
          loading={loading}
          scroll={{ x: 1200 }}
        />
      </Card>
    </div>
  );
};

export default Orders;