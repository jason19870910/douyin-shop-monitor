import React, { useState } from 'react';
import { Layout, Menu, Avatar, Dropdown, Button, Space } from 'antd';
import { Link, Routes, Route, Navigate } from 'react-router-dom';
import {
  DashboardOutlined,
  ShoppingOutlined,
  ShoppingCartOutlined,
  UserOutlined,
  SettingOutlined,
  SyncOutlined,
  ClockCircleOutlined,
  MenuUnfoldOutlined,
  MenuFoldOutlined,
  UsergroupAddOutlined,
} from '@ant-design/icons';
import { dashboardApi, syncApi, healthApi } from './api';
import { useApi, usePolling } from './hooks/useApi';
import { formatDateTime } from './utils/formatters';
import Dashboard from './pages/Dashboard';
import Products from './pages/Products';
import Orders from './pages/Orders';
import Creators from './pages/Creators';
import AlertConfig from './pages/AlertConfig';

const { Header, Sider, Content } = Layout;
const { SubMenu } = Menu;

const menuItems = [
  { key: '/dashboard', icon: <DashboardOutlined />, label: '仪表盘' },
  { key: '/products', icon: <ShoppingOutlined />, label: '商品管理' },
  { key: '/orders', icon: <ShoppingCartOutlined />, label: '订单管理' },
  { key: '/creators', icon: <UsergroupAddOutlined />, label: '创作者' },
  { key: '/alerts', icon: <SettingOutlined />, label: '告警配置' },
];

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [lastUpdate, setLastUpdate] = useState(null);
  
  const { data: healthData, refetch: checkHealth } = useApi(healthApi.check, []);
  const { data: syncData, loading: syncLoading } = useApi(syncApi.manualSync, []);

  const handleSync = async () => {
    try {
      await syncApi.manualSync();
      checkHealth();
    } catch (err) {
      console.error('Sync failed:', err);
    }
  };

  const userMenu = (
    <Menu>
      <Menu.Item key="profile">
        <Link to="/profile">个人中心</Link>
      </Menu.Item>
      <Menu.Item key="logout" onClick={() => window.location.href = '/logout'}>
        退出登录
      </Menu.Item>
    </Menu>
  );

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Header className="ant-layout-header">
        <div className="logo">
          <span className="logo-icon">📊</span>
          抖音电商数据监控
        </div>
        <div className="user-menu">
          <Space>
            <span className="last-update">
              最后更新: {lastUpdate ? formatDateTime(lastUpdate) : '未知'}
            </span>
            <Button
              className="btn-sync"
              icon={<SyncOutlined />}
              onClick={handleSync}
              loading={syncLoading}
              type="primary"
            >
              立即同步
            </Button>
            <Dropdown menu={userMenu} placement="bottomRight">
              <Space>
                <Avatar size={28} icon={<UserOutlined />} />
              </Space>
            </Dropdown>
          </Space>
        </div>
      </Header>
      <Layout>
        <Sider
          trigger={null}
          collapsible
          collapsed={collapsed}
          className="ant-layout-sider"
        >
          <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <div style={{ padding: '16px 20px' }}>
              <Button
                type="text"
                icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
                onClick={() => setCollapsed(!collapsed)}
                style={{ width: '100%', justifyContent: 'flex-start' }}
              />
            </div>
            <Menu
              theme="dark"
              mode="inline"
              selectedKeys={[window.location.pathname]}
              items={menuItems}
              onClick={({ key }) => window.location.href = key}
            />
          </div>
        </Sider>
        <Layout>
          <Content className="ant-layout-content">
            <Routes>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/products" element={<Products />} />
              <Route path="/orders" element={<Orders />} />
              <Route path="/creators" element={<Creators />} />
              <Route path="/alerts" element={<AlertConfig />} />
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route path="*" element={<Navigate to="/dashboard" replace />} />
            </Routes>
          </Content>
        </Layout>
      </Layout>
    </Layout>
  );
}

export default App;