import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

api.interceptors.response.use(
  (response) => response.data,
  (error) => {
    console.error('API Error:', error);
    return Promise.reject(error);
  }
);

export const productApi = {
  getList: (params) => api.get('/products', { params }),
  getDetail: (id) => api.get(`/products/${id}`),
};

export const orderApi = {
  getList: (params) => api.get('/orders', { params }),
};

export const creatorApi = {
  getList: () => api.get('/creators'),
  getDetail: (id) => api.get(`/creators/${id}`),
};

export const dashboardApi = {
  getStats: () => api.get('/dashboard/stats'),
};

export const alertApi = {
  getConfig: () => api.get('/alerts/config'),
  updateConfig: (config) => api.post('/alerts/config', config),
};

export const syncApi = {
  manualSync: () => api.post('/sync'),
};

export const healthApi = {
  check: () => api.get('/health'),
};

export default api;