export function formatNumber(num) {
  if (num === null || num === undefined) return '0';
  if (num >= 100000000) {
    return (num / 100000000).toFixed(2) + '亿';
  }
  if (num >= 10000) {
    return (num / 10000).toFixed(2) + '万';
  }
  return num.toLocaleString();
}

export function formatCurrency(num) {
  if (num === null || num === undefined) return '¥0';
  return '¥' + formatNumber(num);
}

export function formatPercent(num) {
  if (num === null || num === undefined) return '0%';
  return (num * 100).toFixed(2) + '%';
}

export function formatDate(dateString) {
  if (!dateString) return '-';
  const date = new Date(dateString);
  return date.toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  });
}

export function formatDateTime(dateString) {
  if (!dateString) return '-';
  const date = new Date(dateString);
  return date.toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function getTrendClass(current, previous) {
  if (previous === 0) return '';
  return current > previous ? 'up' : current < previous ? 'down' : '';
}

export function calculateGrowth(current, previous) {
  if (previous === 0) return current > 0 ? 100 : 0;
  return ((current - previous) / previous) * 100;
}