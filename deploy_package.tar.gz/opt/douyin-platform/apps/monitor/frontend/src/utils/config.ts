import { isBrowser } from './env';

export interface AppConfig {
  apiBaseUrl: string;
  isDevelopment: boolean;
  isProduction: boolean;
  enableDevTools: boolean;
  logLevel: 'debug' | 'info' | 'warn' | 'error';
}

const getApiBaseUrl = (): string => {
  // Explicit env var takes highest priority
  const envUrl = import.meta.env.VITE_API_URL;
  if (envUrl) return envUrl;

  // In production, use relative URL (same origin)
  if (import.meta.env.PROD) {
    return '/api';
  }

  // Development: check if we're on localhost or a different host
  if (isBrowser()) {
    const { hostname, port } = window.location;
    if (hostname === 'localhost' || hostname === '127.0.0.1') {
      const devPort = port || '5000';
      return `http://${hostname}:${devPort}/api`;
    }
    // Non-localhost development: use relative URL
    return '/api';
  }

  // Server-side rendering fallback
  return '/api';
};

const getConfig = (): AppConfig => {
  const isDev = import.meta.env.DEV;
  const isProd = import.meta.env.PROD;

  return {
    apiBaseUrl: getApiBaseUrl(),
    isDevelopment: isDev,
    isProduction: isProd,
    enableDevTools: isDev,
    logLevel: isDev ? 'debug' : 'warn',
  };
};

export const config = getConfig();

export const getApiBaseUrlPublic = (): string => config.apiBaseUrl;

export const isDevelopment = (): boolean => config.isDevelopment;

export const isProduction = (): boolean => config.isProduction;

export const log = (level: AppConfig['logLevel'], ...args: unknown[]): void => {
  const levels = { debug: 0, info: 1, warn: 2, error: 3 };
  if (levels[level] >= levels[config.logLevel]) {
    const prefix = `[${level.toUpperCase()}]`;
    switch (level) {
      case 'debug':
        console.debug(prefix, ...args);
        break;
      case 'info':
        console.info(prefix, ...args);
        break;
      case 'warn':
        console.warn(prefix, ...args);
        break;
      case 'error':
        console.error(prefix, ...args);
        break;
    }
  }
};