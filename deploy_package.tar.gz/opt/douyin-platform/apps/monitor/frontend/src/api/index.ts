import { apiClient, NormalizedError, setAuthToken, getAuthToken } from '@/utils/apiClient';
import { config } from '@/utils/config';

// Re-export types from the new apiClient
export type { NormalizedError };

// 通用响应类型 - 后端实际返回的格式
export interface ApiResponse<T = unknown> {
  success?: boolean;
  data?: T;
  message?: string;
  error?: string;
}

// 分页响应 - 后端 /api/products, /api/creators 等返回的格式
export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  size: number;
  data_source?: 'real' | 'mock';
}

// 订单列表响应 - 后端 /api/orders 返回的特殊格式
export interface OrderListResponse {
  success?: boolean;
  data?: Record<string, unknown>; // summary data
  list: Order[];
  total: number;
  page: number;
  size: number;
  data_source?: 'real' | 'mock';
}

// 仪表盘统计响应
export interface DashboardStatsResponse {
  data: DashboardStats;
  data_source?: 'real' | 'mock';
}

// Mock 状态响应
export interface MockStatusResponse {
  data: MockStatus;
}

export interface Product {
  product_id: string;
  product_name: string;
  sales_today: number;
  sales_yesterday: number;
  conversion_rate: number;
  conversion_rate_yesterday: number;
  inventory: number;
  status: string;
  create_time: string;
  category?: string;
  price?: number;
  fetched_at?: string;
  [key: string]: unknown;
}

export interface Order {
  order_id: string;
  product_name: string;
  amount: number;
  status: string;
  create_time: string;
  creator_name?: string;
  quantity?: number;
  update_time?: string;
  [key: string]: unknown;
}

export interface Creator {
  creator_id: string;
  creator_name: string;
  follower_count: number;
  nickname?: string;
  avatar?: string;
  followers?: number;
  total_sales?: number;
  total_revenue?: number;
  product_count?: number;
  avg_conversion_rate?: number;
  fetched_at?: string;
  [key: string]: unknown;
}

export interface CreatorWork {
  work_id: string;
  title: string;
  creator_name: string;
  creator_id: string;
  cover_url: string;
  play_count: number;
  like_count: number;
  comment_count: number;
  share_count: number;
  status: number; // 0: all, 1: published, 2: draft, etc.
  create_time: string;
  update_time: string;
  duration?: number;
  video_url?: string;
  fetched_at?: string;
  [key: string]: unknown;
}

export interface Video {
  video_id: string;
  title: string;
  creator_name: string;
  play_count: number;
  like_count: number;
  comment_count: number;
  share_count: number;
  status: string;
  create_time: string;
  [key: string]: unknown;
}

export interface Account {
  account_id: string;
  account_name: string;
  account_type: string;
  phone: string;
  email: string;
  status: string;
  last_login: string | null;
  create_time: string;
  [key: string]: unknown;
}

export interface ComplianceItem {
  product_id: string;
  product_name: string;
  risk_level: 'high' | 'medium' | 'low';
  violation_type: string;
  violation_detail: string;
  detected_at: string;
  status: 'pending' | 'ignored' | 'resolved';
  compliance_score?: number;
  violations?: ComplianceViolation[];
  check_batch_id?: string;
  ignored_at?: string;
  resolved_at?: string;
  restored_at?: string;
  resolution?: string;
  [key: string]: unknown;
}

export interface ComplianceViolation {
  rule_id: string;
  rule_name: string;
  violation_type: string;
  violation_detail: string;
  matched_keywords: string[];
  severity: string;
  category: string;
}

export interface MediaItem {
  media_id: string;
  type: 'video' | 'image';
  title: string;
  status: string;
  source_url: string;
  output_url: string;
  create_time: string;
  [key: string]: unknown;
}

export interface AlertConfig {
  sales_drop_threshold?: number;
  conversion_drop_threshold?: number;
  inventory_low_threshold?: number;
  notification_email?: string;
  enabled?: boolean;
  video_view_drop_threshold?: number;
  video_like_drop_threshold?: number;
  creator_follower_drop_threshold?: number;
  product_sales_drop_threshold?: number;
  order_refund_rate_threshold?: number;
  compliance_risk_threshold?: string;
}

export interface AuthStatus {
  douyin_app_id: string;
  douyin_app_secret: string;
  redirect_uri: string;
  authorized: boolean;
  access_token: string;
  refresh_token: string;
  expires_at: number;
  scope: string[];
}

export interface DashboardStats {
  total_sales_today: number;
  total_sales_yesterday: number;
  total_revenue_today: number;
  total_revenue_yesterday: number;
  total_orders_today: number;
  total_orders_yesterday: number;
  avg_conversion_rate: number;
  avg_conversion_rate_yesterday: number;
  sales_trend: Array<{ date: string; sales: number }>;
  top_products: Product[];
  data_source?: 'real' | 'mock';
}

export interface MockStatusItem {
  is_mock: boolean;
  elapsed_minutes: number;
  alert_threshold: number;
  alert_triggered: boolean;
  alert_sent: boolean;
}

export interface MockStatus {
  products: MockStatusItem;
  orders: MockStatusItem;
  creators: MockStatusItem;
}

export interface HealthResponse {
  status: string;
  timestamp: string;
  last_update: string | null;
}

// Auth token management
export { setAuthToken, getAuthToken };

// Config
export { config };

// API wrapper functions using the new client
// Directly extract data from axios response
export const productApi = {
  getList: (params?: Record<string, unknown>) =>
    apiClient.get<PaginatedResponse<Product>>('/products', { params }).then((res) => res.data),
  getDetail: (id: string) =>
    apiClient.get<Product>(`/products/${id}`).then((res) => res.data),
  getStats: (params?: Record<string, unknown>) =>
    apiClient.get<unknown>('/products/stats', { params }).then((res) => res.data),
  getExternal: (params?: Record<string, unknown>) =>
    apiClient.get<unknown>('/products/external', { params }).then((res) => res.data),
};

export const orderApi = {
  getList: (params?: Record<string, unknown>) =>
    apiClient.get<OrderListResponse>('/orders', { params }).then((res) => res.data),
  getStats: (params?: Record<string, unknown>) =>
    apiClient.get<unknown>('/orders/stats', { params }).then((res) => res.data),
};

// 外部 API 响应格式
export interface ExternalApiResponse<T = unknown> {
  success?: boolean;
  data?: T;
  message?: string;
}

export const creatorApi = {
  getList: (params?: Record<string, unknown>) =>
    apiClient.get<PaginatedResponse<Creator>>('/creators', { params }).then((res) => res.data),
  getDetail: (id: string) =>
    apiClient.get<Creator>(`/creators/${id}`).then((res) => res.data),
  getWorks: (params?: Record<string, unknown>) =>
    apiClient.get<PaginatedResponse<CreatorWork>>('/creators/works', { params }).then((res) => res.data),
  getExternalWorks: (params?: Record<string, unknown>) =>
    apiClient.get<ExternalApiResponse<{ list: CreatorWork[]; total: number }>>('/creators/works/external', { params })
      .then((res) => ({
        data: res.data?.data?.list || [],
        total: res.data?.data?.total || 0,
        page: params?.page as number || 1,
        size: params?.size as number || 20,
      } as PaginatedResponse<CreatorWork>)),
};

export const dashboardApi = {
  getStats: (params?: Record<string, unknown>) =>
    apiClient.get<DashboardStatsResponse>('/dashboard/stats', { params }).then((res) => res.data),
  getMockStatus: () =>
    apiClient.get<MockStatusResponse>('/mock/status').then((res) => res.data),
};

export const alertApi = {
  getConfig: () =>
    apiClient.get<AlertConfig>('/alerts/config').then((res) => res.data),
  updateConfig: (alertConfig: AlertConfig) =>
    apiClient.post<AlertConfig>('/alerts/config', alertConfig).then((res) => res.data),
};

export const syncApi = {
  manualSync: () =>
    apiClient.post<{ last_update: string }>('/sync').then((res) => res.data),
};

export const healthApi = {
  check: () =>
    apiClient.get<HealthResponse>('/health').then((res) => res.data),
  getHealth: () =>
    apiClient.get<HealthResponse>('/health').then((res) => res.data),
};

export const videoApi = {
  getList: (params?: Record<string, unknown>) =>
    apiClient.get<PaginatedResponse<Video>>('/videos', { params }).then((res) => res.data),
  getDetail: (id: string) =>
    apiClient.get<Video>(`/videos/${id}`).then((res) => res.data),
  create: (data: Partial<Video>) =>
    apiClient.post<Video>('/videos', data).then((res) => res.data),
  update: (id: string, data: Partial<Video>) =>
    apiClient.put<Video>(`/videos/${id}`, data).then((res) => res.data),
  delete: (id: string) =>
    apiClient.delete<unknown>(`/videos/${id}`).then((res) => res.data),
};

export const authApi = {
  getStatus: () =>
    apiClient.get<AuthStatus>('/auth/status').then((res) => res.data),
  login: () =>
    apiClient.get<{ auth_url: string }>('/auth/login').then((res) => res.data),
  logout: () =>
    apiClient.post<unknown>('/auth/logout').then((res) => res.data),
  getQrCode: () =>
    apiClient.get<{ qr_code: string }>('/auth/qr-code').then((res) => res.data),
};

export const accountApi = {
  getList: (params?: Record<string, unknown>) =>
    apiClient.get<PaginatedResponse<Account>>('/accounts', { params }).then((res) => res.data),
  getDetail: (id: string) =>
    apiClient.get<Account>(`/accounts/${id}`).then((res) => res.data),
  create: (data: Partial<Account>) =>
    apiClient.post<Account>('/accounts', data).then((res) => res.data),
  update: (id: string, data: Partial<Account>) =>
    apiClient.put<Account>(`/accounts/${id}`, data).then((res) => res.data),
  delete: (id: string) =>
    apiClient.delete<unknown>(`/accounts/${id}`).then((res) => res.data),
};

// Compliance types
export interface ComplianceStats {
  total_products: number;
  checked_products: number;
  pass_count: number;
  warning_count: number;
  fail_count: number;
  compliance_rate: number;
  risk_distribution: { high: number; medium: number; low: number };
  status_distribution: { pending: number; ignored: number; resolved: number };
  category_distribution: Record<string, number>;
  recent_checks: ComplianceItem[];
}

export interface ComplianceCheckResult {
  checked: number;
  pass: number;
  warning: number;
  fail: number;
  details: Array<{
    product_id: string;
    product_name: string;
    compliance_status: string;
    compliance_score: number;
    violations: Array<{
      rule_id: string;
      rule_name: string;
      violation_type: string;
      violation_detail: string;
      matched_keywords: string[];
      severity: string;
      category: string;
    }>;
    violation_count: number;
    checked_at: string;
    rules_checked: number;
  }>;
  batch_id: string;
}

export interface ComplianceRule {
  id: string;
  rule_name: string;
  rule_description?: string;
  rule_type: 'KEYWORD' | 'REGEX' | 'ML_MODEL' | 'CUSTOM_SCRIPT';
  rule_content: Record<string, unknown>;
  is_active: boolean;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  category: string;
  created_at: string;
  updated_at: string;
  created_by: string;
}

export interface ComplianceLog {
  id: string;
  check_batch_id: string;
  product_id: string;
  rule_id: string;
  violation_detail: string;
  severity: string;
  category: string;
  checked_at: string;
}

export const complianceApi = {
  getList: (params?: Record<string, unknown>) =>
    apiClient.get<PaginatedResponse<ComplianceItem>>('/compliance', { params }).then((res) => res.data),
  ignore: (id: string) =>
    apiClient.post<ComplianceItem>(`/compliance/${id}/ignore`).then((res) => res.data),
  takeDown: (id: string) =>
    apiClient.post<ComplianceItem>(`/compliance/${id}/take-down`).then((res) => res.data),
  restore: (id: string) =>
    apiClient.post<ComplianceItem>(`/compliance/${id}/restore`).then((res) => res.data),
  getStats: () =>
    apiClient.get<{ data: ComplianceStats }>('/compliance/stats').then((res) => res.data),
  triggerCheck: () =>
    apiClient.post<{ data: ComplianceCheckResult }>('/compliance/check').then((res) => res.data),
  export: (params?: Record<string, unknown>) =>
    apiClient.get('/compliance/export', { params, responseType: 'blob' }).then((res) => res.data),
  getRules: () =>
    apiClient.get<{ data: ComplianceRule[] }>('/compliance/rules').then((res) => res.data),
  createRule: (rule: Partial<ComplianceRule>) =>
    apiClient.post<{ data: ComplianceRule }>('/compliance/rules', rule).then((res) => res.data),
  updateRule: (id: string, rule: Partial<ComplianceRule>) =>
    apiClient.put<{ data: ComplianceRule }>(`/compliance/rules/${id}`, rule).then((res) => res.data),
  deleteRule: (id: string) =>
    apiClient.delete<unknown>(`/compliance/rules/${id}`).then((res) => res.data),
  getRuleHistory: (id: string) =>
    apiClient.get<{ data: ComplianceLog[] }>(`/compliance/rules/${id}/history`).then((res) => res.data),
};

export const mediaApi = {
  getVideoEditList: (params?: Record<string, unknown>) =>
    apiClient.get<PaginatedResponse<MediaItem>>('/media/video-edit', { params }).then((res) => res.data),
  getImageEditList: (params?: Record<string, unknown>) =>
    apiClient.get<PaginatedResponse<MediaItem>>('/media/image-edit', { params }).then((res) => res.data),
  create: (data: Partial<MediaItem>) =>
    apiClient.post<MediaItem>('/media', data).then((res) => res.data),
  update: (id: string, data: Partial<MediaItem>) =>
    apiClient.put<MediaItem>(`/media/${id}`, data).then((res) => res.data),
};

export const alertDouyinApi = {
  getConfig: () =>
    apiClient.get<AlertConfig>('/alerts/douyin/config').then((res) => res.data),
  updateConfig: (alertConfig: AlertConfig) =>
    apiClient.post<AlertConfig>('/alerts/douyin/config', alertConfig).then((res) => res.data),
};

export const alertDianApi = {
  getConfig: () =>
    apiClient.get<AlertConfig>('/alerts/dian/config').then((res) => res.data),
  updateConfig: (alertConfig: AlertConfig) =>
    apiClient.post<AlertConfig>('/alerts/dian/config', alertConfig).then((res) => res.data),
};

// Default export for backward compatibility
export default apiClient;