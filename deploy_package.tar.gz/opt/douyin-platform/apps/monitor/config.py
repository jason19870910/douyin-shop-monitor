import os
from pathlib import Path
from datetime import datetime

# ... existing code ...

# Minimal Config class for API usage
class Config:
    """Compatibility wrapper exposing expected attributes for Flask app."""
    DOUYIN_APP_ID = os.getenv('DOUYIN_APP_ID', '')
    DOUYIN_APP_SECRET = os.getenv('DOUYIN_APP_SECRET', '')
    DOUYIN_ACCESS_TOKEN = os.getenv('DOUYIN_ACCESS_TOKEN', '')
    SCHEDULE_INTERVAL_MINUTES = int(os.getenv('SCHEDULE_INTERVAL_MINUTES', '60'))
    ALERT_EMAIL = os.getenv('ALERT_EMAIL', '')
    DATA_DIR = os.getenv('DATA_DIR', str(Path(__file__).parent / 'data'))
    EXTERNAL_DATA_BASE_URL = os.getenv('EXTERNAL_DATA_BASE_URL', 'https://example.com/monitor')
    API_AUTH_TOKEN = os.getenv('API_AUTH_TOKEN', '')
    # 双域名基础 URL
    FXG_BASE_URL = os.getenv('FXG_BASE_URL', 'https://fxg.jinritemai.com')
    CREATOR_BASE_URL = os.getenv('CREATOR_BASE_URL', 'https://creator.douyin.com')
    # 创作者中心内容管理 API
    CREATOR_WORK_LIST_URL = os.getenv('CREATOR_WORK_LIST_URL', 'https://creator.douyin.com/janus/douyin/creator/pc/work_list')
    # 公共请求头中的 User-Agent（顶层属性供 sign_request 使用）
    USER_AGENT = os.getenv('USER_AGENT', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36')
    # 公共请求头模板（可根据需求覆盖）
    COMMON_HEADERS = {
        "Accept": "application/json, text/plain, */*",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
        "Priority": "u=1, i",
        "User-Agent": USER_AGENT
    }
    # 双域名 Cookie 变量（示例，实际请在 .env 中配置）
    FXG_COOKIES = os.getenv('FXG_COOKIES', '')
    CREATOR_COOKIES = os.getenv('CREATOR_COOKIES', '')
    # 抖店 Shop ID 与 Log ID（多店铺场景需配置）
    FXG_SHOP_ID = int(os.getenv('FXG_SHOP_ID', '4272'))
    FXG_LOG_ID = os.getenv('FXG_LOG_ID', '104476165896')
    # 认证与签名参数
    TOKEN = os.getenv('__TOKEN', '')
    MS_TOKEN = os.getenv('MS_TOKEN', '')
    a_bogus = os.getenv('a_bogus', '')
    verifyFp = os.getenv('verifyFp', '')
    fp = os.getenv('fp', '')
    # Add any other attributes referenced in app.py
    KEEP_ALIVE_TIMEOUT = int(os.getenv('KEEP_ALIVE_TIMEOUT', '30'))
    TIMEOUT = int(os.getenv('TIMEOUT', '30'))
    API_KEY = os.getenv('API_KEY', '')

# End of file