# 前端设计文档 (Frontend Design)

## 技术栈
- **框架**：React 18 (Create React App)
- **UI 组件库**：Ant Design 5.x
- **状态管理**：React Hooks + Context（暂不引入 Redux）
- **数据请求**：`axios` 封装（统一注入 `User-Agent`，在 `src/api/index.js` 中实现）
- **路由**：React Router v6
- **图表**：Recharts（用于仪表盘趋势、TOP 商品等可视化）

## 页面结构（沿用旧版 EJS 架构的侧边栏导航设计）

### 侧边栏导航（根据当前路由动态切换）

| 侧边栏类型 | 显示路由 | 菜单项 |
|-----------|---------|--------|
| **home** (首页) | `/` | 🏠 首页、🎵 抖音管理、🏪 抖店管理、⚠️ 告警设置 |
| **douyin** (抖音管理) | `/douyin/*`, `/auth` | 🏠 首页、📺 视频管理、👤 创作者中心、🔐 授权管理 |
| **dian** (抖店管理) | `/dian/*` | 🏠 首页、📦 商品管理、📊 数据中心、⚠️ 合规管理、🎬 视频编辑、🖼️ 图片编辑、🔑 账号管理 |
| **alerts** (告警设置) | `/alerts/*` | 🏠 首页、🎵 抖音告警设置、🏪 抖店告警设置 |

### 路由映射表

| 路由路径 | 页面组件 | 侧边栏 | 说明 |
|---------|---------|--------|------|
| `/` | 重定向 → `/dashboard` | home | 入口重定向 |
| `/dashboard` | Dashboard | home | 仪表盘统计 |
| `/douyin` | 重定向 → `/douyin/videos` | douyin | 抖音管理入口 |
| `/douyin/videos` | Videos | douyin | 视频管理列表 |
| `/douyin/creator` | Creator | douyin | 创作者中心 |
| `/auth` | Auth | douyin | 授权管理 (OAuth) |
| `/dian` | 重定向 → `/dian/products` | dian | 抖店管理入口 |
| `/dian/products` | Products | dian | 商品列表 |
| `/dian/orders` | Orders | dian | 数据中心 (订单) |
| `/dian/compliance` | Compliance | dian | 合规管理 |
| `/dian/video-edit` | VideoEdit | dian | 视频编辑 |
| `/dian/image-edit` | ImageEdit | dian | 图片编辑 |
| `/dian/account` | Account | dian | 账号管理 |
| `/alerts` | 重定向 → `/alerts/douyin` | alerts | 告警设置入口 |
| `/alerts/douyin` | AlertsDouyin | alerts | 抖音告警配置 |
| `/alerts/dian` | AlertsDian | alerts | 抖店告警配置 |

## API 接口对应表
| 前端 API 调用 | 后端端点 | 说明 |
|---|---|---|
| `dashboardApi.getStats()` | `GET /api/dashboard/stats` | 仪表盘统计数据 |
| `productApi.getList(params)` | `GET /api/products` | 商品分页列表（内部缓存） |
| `productApi.getStats(params)` | `GET /api/products/stats` | 商品统计（外部 API 转发） |
| `productApi.getExternal(params)` | `GET /api/products/external` | 外部商品列表透传 |
| `productApi.getDetail(id)` | `GET /api/products/:id` | 商品详情 |
| `orderApi.getList(params)` | `GET /api/orders` | 订单分页列表（内部缓存） |
| `orderApi.getStats(params)` | `GET /api/orders/stats` | 订单统计（外部 API 转发） |
| `creatorApi.getList(params)` | `GET /api/creators` | 创作者列表 |
| `creatorApi.getDetail(id)` | `GET /api/creators/:id` | 创作者详情 |
| `alertApi.getConfig()` | `GET /api/alerts/config` | 获取告警配置 |
| `alertApi.updateConfig(config)` | `POST /api/alerts/config` | 更新告警配置 |
| `syncApi.manualSync()` | `POST /api/sync` | 手动触发同步 |
| `healthApi.check()` | `GET /api/health` | 健康检查 |

## 交互细节
- **统一请求头**：在 `src/api/index.js` 中统一添加 `User-Agent`（读取自 `.env` REACT_APP_USER_AGENT）
- **错误处理**：全局拦截器捕获非 2xx 响应，弹出 Ant Design `message.error`，并在控制台记录详细信息
- **加载状态**：使用 Ant Design `Spin` 包裹列表分页加载，防止页面卡顿
- **分页**：后端已实现 `page`、`size` 参数，前端通过 `useEffect` 监听分页变量并请求对应 API
- **告警弹窗**：`/alerts` 页面提供表单编辑阈值，保存后调用 `POST /api/alerts/config`，成功后使用 `notification.success` 提示
- **侧边栏折叠**：支持 Sider 折叠/展开，折叠时仅显示图标
- **动态侧边栏**：根据当前路由自动切换对应的侧边栏菜单（home/douyin/dian/alerts）
- **高亮当前菜单**：基于 `location.pathname` 自动高亮当前选中的菜单项

## 代码组织
```
src/
 ├─ api/          # 与后端交互的封装层
 │    └─ index.js
 ├─ components/   # 可复用 UI 组件
 │    └─ Layout/  # 布局组件 (Layout.jsx, Layout.module.css)
 ├─ pages/        # 各业务页面
 │    ├─ Dashboard.js
 │    ├─ Products.js
 │    ├─ Orders.js
 │    ├─ Creators.js
 │    ├─ AlertConfig.js
 │    ├─ Videos.js          # 视频管理 (/douyin/videos)
 │    ├─ Creator.js         # 创作者中心 (/douyin/creator)
 │    ├─ Auth.js            # 授权管理 (/auth)
 │    ├─ Compliance.js      # 合规管理 (/dian/compliance)
 │    ├─ VideoEdit.js       # 视频编辑 (/dian/video-edit)
 │    ├─ ImageEdit.js       # 图片编辑 (/dian/image-edit)
 │    ├─ Account.js         # 账号管理 (/dian/account)
 │    ├─ AlertsDouyin.js    # 抖音告警配置 (/alerts/douyin)
 │    └─ AlertsDian.js      # 抖店告警配置 (/alerts/dian)
 ├─ hooks/        # 自定义 Hooks
 │    └─ useApi.js
 ├─ utils/        # 通用工具函数
 │    └─ formatters.js
 └─ Layout/       # 布局目录 (Layout.jsx, Layout.module.css, api/, hooks/, utils/)
```

## 运行指南
```bash
# 安装依赖
npm install
# 开发模式（代理至后端 http://localhost:5000）
npm run dev
# 构建生产包
npm run build
# 部署时将 `build/` 目录挂载到 Flask 静态文件目录
```

---

*前端设计会根据实际需求迭代更新，本文档最后更新：2026-08-16*