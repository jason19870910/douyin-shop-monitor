import os
import json
import logging
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, asdict
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import requests
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger

# 导入签名模块
from douyin_sign import sign_request

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Load environment variables
from dotenv import load_dotenv
load_dotenv()

# Import config
from config import Config

app = Flask(__name__, static_folder='frontend/build/static', static_url_path='/static')
CORS(app)

# Flasgger / Swagger UI（可选，未安装时跳过）
try:
    from flasgger import Swagger
    swagger = Swagger(app, template={
        "swagger": "2.0",
        "info": {
            "title": "Douyin Monitor API",
            "description": "抖音电商数据监控平台 API 文档",
            "version": "1.0.0",
            "contact": {
                "name": "Douyin Monitor Team"
            }
        },
        "basePath": "/api",
        "schemes": ["http", "https"],
        "consumes": ["application/json"],
        "produces": ["application/json"],
        "securityDefinitions": {
            "Bearer": {
                "type": "apiKey",
                "name": "Authorization",
                "in": "header",
                "description": "JWT Authorization header using the Bearer scheme. Example: \"Authorization: Bearer {token}\""
            }
        }
    })
except ImportError:
    swagger = None
    logger.warning("flasgger not installed, Swagger UI disabled")

# Data storage paths
DATA_DIR = Path(Config.DATA_DIR)
DATA_DIR.mkdir(parents=True, exist_ok=True)

PRODUCTS_FILE = DATA_DIR / 'products.json'
ORDERS_FILE = DATA_DIR / 'orders.json'
CREATORS_FILE = DATA_DIR / 'creators.json'
ALERT_CONFIG_FILE = DATA_DIR / 'alert_config.json'
VIDEOS_FILE = DATA_DIR / 'videos.json'
ACCOUNTS_FILE = DATA_DIR / 'accounts.json'
COMPLIANCE_FILE = DATA_DIR / 'compliance.json'
MEDIA_FILE = DATA_DIR / 'media.json'
ALERT_DOUYIN_CONFIG_FILE = DATA_DIR / 'alert_douyin_config.json'
ALERT_DIAN_CONFIG_FILE = DATA_DIR / 'alert_dian_config.json'
AUTH_FILE = DATA_DIR / 'auth.json'
CREATOR_WORKS_FILE = DATA_DIR / 'creator_works.json'

# Default alert configuration
DEFAULT_ALERT_CONFIG = {
    'sales_drop_threshold': 0.3,  # 30% drop
    'conversion_drop_threshold': 0.2,  # 20% drop
    'inventory_low_threshold': 10,
    'notification_email': os.getenv('ALERT_EMAIL', ''),
    'enabled': True
}

# Douyin-specific alert config
DEFAULT_ALERT_DOUYIN_CONFIG = {
    'video_view_drop_threshold': 0.3,
    'video_like_drop_threshold': 0.2,
    'creator_follower_drop_threshold': 0.1,
    'notification_email': os.getenv('ALERT_EMAIL', ''),
    'enabled': True
}

# Dian-specific alert config
DEFAULT_ALERT_DIAN_CONFIG = {
    'product_sales_drop_threshold': 0.3,
    'order_refund_rate_threshold': 0.15,
    'compliance_risk_threshold': 'medium',
    'notification_email': os.getenv('ALERT_EMAIL', ''),
    'enabled': True
}

# Default auth config
DEFAULT_AUTH_CONFIG = {
    'douyin_app_id': '',
    'douyin_app_secret': '',
    'redirect_uri': '',
    'authorized': False,
    'access_token': '',
    'refresh_token': '',
    'expires_at': 0,
    'scope': []
}

# Default video data
DEFAULT_VIDEOS = []

# Default account data
DEFAULT_ACCOUNTS = []

# Default compliance data
DEFAULT_COMPLIANCE = []

# Default media data
DEFAULT_MEDIA = []

# In-memory cache for latest data
data_cache = {
    'products': [],
    'orders': [],
    'creators': [],
    'videos': [],
    'accounts': [],
    'compliance': [],
    'media': [],
    'auth': {},
    'creator_works': [],
    'last_update': None
}

# Mock data for fallback when API fetch returns empty
MOCK_PRODUCTS = [
    {'product_id': 'mock_p_001', 'product_name': '模拟商品-爆款T恤', 'category': '服饰', 'price': 99.9, 'sales_today': 156, 'sales_yesterday': 134, 'inventory': 234, 'conversion_rate': 0.032, 'fetched_at': datetime.now().isoformat()},
    {'product_id': 'mock_p_002', 'product_name': '模拟商品-无线耳机', 'category': '电子', 'price': 299.0, 'sales_today': 89, 'sales_yesterday': 95, 'inventory': 67, 'conversion_rate': 0.045, 'fetched_at': datetime.now().isoformat()},
    {'product_id': 'mock_p_003', 'product_name': '模拟商品-智能水杯', 'category': '家居', 'price': 159.0, 'sales_today': 203, 'sales_yesterday': 187, 'inventory': 12, 'conversion_rate': 0.028, 'fetched_at': datetime.now().isoformat()},
    {'product_id': 'mock_p_004', 'product_name': '模拟商品-便携风扇', 'category': '家电', 'price': 79.9, 'sales_today': 312, 'sales_yesterday': 298, 'inventory': 456, 'conversion_rate': 0.051, 'fetched_at': datetime.now().isoformat()},
    {'product_id': 'mock_p_005', 'product_name': '模拟商品-防晒喷雾', 'category': '美妆', 'price': 59.9, 'sales_today': 178, 'sales_yesterday': 165, 'inventory': 89, 'conversion_rate': 0.038, 'fetched_at': datetime.now().isoformat()},
]

MOCK_ORDERS = [
    {'order_id': 'mock_o_001', 'product_name': '模拟商品-爆款T恤', 'amount': 99.9, 'status': 'completed', 'create_time': (datetime.now() - timedelta(hours=2)).isoformat()},
    {'order_id': 'mock_o_002', 'product_name': '模拟商品-无线耳机', 'amount': 299.0, 'status': 'completed', 'create_time': (datetime.now() - timedelta(hours=5)).isoformat()},
    {'order_id': 'mock_o_003', 'product_name': '模拟商品-智能水杯', 'amount': 159.0, 'status': 'shipped', 'create_time': (datetime.now() - timedelta(hours=8)).isoformat()},
    {'order_id': 'mock_o_004', 'product_name': '模拟商品-便携风扇', 'amount': 79.9, 'status': 'pending', 'create_time': (datetime.now() - timedelta(hours=12)).isoformat()},
    {'order_id': 'mock_o_005', 'product_name': '模拟商品-防晒喷雾', 'amount': 59.9, 'status': 'completed', 'create_time': (datetime.now() - timedelta(hours=24)).isoformat()},
]

MOCK_CREATORS = [
    {'creator_id': 'mock_c_001', 'creator_name': '模拟达人-美妆博主', 'follower_count': 125000, 'fetched_at': datetime.now().isoformat()},
    {'creator_id': 'mock_c_002', 'creator_name': '模拟达人-数码评测', 'follower_count': 89000, 'fetched_at': datetime.now().isoformat()},
    {'creator_id': 'mock_c_003', 'creator_name': '模拟达人-家居好物', 'follower_count': 56000, 'fetched_at': datetime.now().isoformat()},
]

import redis
import json
import time
import random
from functools import wraps
from threading import Lock

# HTTP 请求重试装饰器（指数退避 + 抖动）
def _http_retry(max_retries=3, base_delay=1.0, max_delay=10.0, timeout=30):
    """HTTP 请求重试装饰器（指数退避 + 抖动）"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except (requests.ConnectionError, requests.Timeout, requests.RequestException) as e:
                    last_exception = e
                    if attempt < max_retries - 1:
                        delay = min(base_delay * (2 ** attempt) + random.uniform(0, 1), max_delay)
                        logger.warning(f"HTTP 请求失败 (尝试 {attempt + 1}/{max_retries}): {e}, {delay:.2f}s 后重试")
                        time.sleep(delay)
                    else:
                        logger.error(f"HTTP 请求最终失败 (已重试 {max_retries} 次): {e}")
            raise last_exception
        return wrapper
    return decorator


# Redis 连接池配置（支持重试、熔断、连接池）
_redis_pool = None
_redis_client = None
_redis_lock = Lock()
_circuit_breaker = {
    'failure_count': 0,
    'last_failure_time': 0,
    'state': 'closed',  # closed, open, half-open
    'failure_threshold': 5,
    'recovery_timeout': 30,  # seconds
}
_circuit_lock = Lock()


def _get_redis_pool():
    """获取或创建 Redis 连接池（单例模式，线程安全）"""
    global _redis_pool
    if _redis_pool is None:
        with _redis_lock:
            if _redis_pool is None:
                _redis_pool = redis.ConnectionPool(
                    host='redis',
                    port=6379,
                    db=0,
                    decode_responses=True,
                    max_connections=20,
                    retry_on_timeout=True,
                    socket_connect_timeout=5,
                    socket_timeout=5,
                    health_check_interval=30,
                )
    return _redis_pool


def _get_redis_client():
    """获取 Redis 客户端（带连接池）"""
    global _redis_client
    if _redis_client is None:
        _redis_client = redis.Redis(connection_pool=_get_redis_pool())
    return _redis_client


def _circuit_breaker_check():
    """熔断器检查"""
    global _circuit_breaker
    with _circuit_lock:
        now = time.time()
        if _circuit_breaker['state'] == 'open':
            if now - _circuit_breaker['last_failure_time'] > _circuit_breaker['recovery_timeout']:
                _circuit_breaker['state'] = 'half-open'
                logger.info("Redis 熔断器进入半开状态，尝试恢复连接")
                return True
            return False
        return True


def _circuit_breaker_record_success():
    """记录成功，重置熔断器"""
    global _circuit_breaker
    with _circuit_lock:
        _circuit_breaker['failure_count'] = 0
        _circuit_breaker['state'] = 'closed'


def _circuit_breaker_record_failure():
    """记录失败，可能触发熔断"""
    global _circuit_breaker
    with _circuit_lock:
        _circuit_breaker['failure_count'] += 1
        _circuit_breaker['last_failure_time'] = time.time()
        if _circuit_breaker['failure_count'] >= _circuit_breaker['failure_threshold']:
            _circuit_breaker['state'] = 'open'
            logger.error(f"Redis 熔断器触发，连续失败 {_circuit_breaker['failure_count']} 次，进入开启状态")


def _redis_retry(max_retries=3, base_delay=0.5, max_delay=5.0):
    """Redis 操作重试装饰器（指数退避 + 抖动）"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if not _circuit_breaker_check():
                raise redis.ConnectionError("Redis 熔断器开启，拒绝请求")
            
            last_exception = None
            for attempt in range(max_retries):
                try:
                    result = func(*args, **kwargs)
                    _circuit_breaker_record_success()
                    return result
                except (redis.ConnectionError, redis.TimeoutError, redis.RedisError) as e:
                    last_exception = e
                    _circuit_breaker_record_failure()
                    if attempt < max_retries - 1:
                        delay = min(base_delay * (2 ** attempt) + (time.time() % 1), max_delay)
                        logger.warning(f"Redis 操作失败 (尝试 {attempt + 1}/{max_retries}): {e}, {delay:.2f}s 后重试")
                        time.sleep(delay)
                    else:
                        logger.error(f"Redis 操作最终失败 (已重试 {max_retries} 次): {e}")
            
            raise last_exception
        return wrapper
    return decorator

@_redis_retry(max_retries=3, base_delay=0.5, max_delay=5.0)
def _get_redis_tracker() -> dict:
    """从 Redis 获取 tracker 状态"""
    client = _get_redis_client()
    data = client.get('mock_usage_tracker')
    if data:
        try:
            return json.loads(data)
        except json.JSONDecodeError:
            pass
    return {
        'products': {'is_mock': False, 'start_time': None},
        'orders': {'is_mock': False, 'start_time': None},
        'creators': {'is_mock': False, 'start_time': None},
    }


@_redis_retry(max_retries=3, base_delay=0.5, max_delay=5.0)
def _save_redis_tracker(tracker: dict) -> None:
    """保存 tracker 状态到 Redis"""
    client = _get_redis_client()
    client.set('mock_usage_tracker', json.dumps(tracker, default=str))


@_redis_retry(max_retries=3, base_delay=0.5, max_delay=5.0)
def _get_redis_alert_sent() -> dict:
    """从 Redis 获取 alert_sent 状态"""
    client = _get_redis_client()
    data = client.get('mock_alert_sent')
    if data:
        try:
            return json.loads(data)
        except json.JSONDecodeError:
            pass
    return {'products': False, 'orders': False, 'creators': False}


@_redis_retry(max_retries=3, base_delay=0.5, max_delay=5.0)
def _save_redis_alert_sent(alert_sent: dict) -> None:
    """保存 alert_sent 状态到 Redis"""
    client = _get_redis_client()
    client.set('mock_alert_sent', json.dumps(alert_sent))


def get_mock_status() -> dict:
    """获取所有数据源的 Mock 状态（用于前端展示）"""
    tracker = _get_redis_tracker()
    alert_sent = _get_redis_alert_sent()
    result = {}
    now = datetime.now()
    for key in ['products', 'orders', 'creators']:
        t = tracker.get(key, {})
        if t.get('is_mock') and t.get('start_time'):
            start_time = datetime.fromisoformat(t['start_time'])
            elapsed = int((now - start_time).total_seconds() / 60)
            result[key] = {
                'is_mock': True,
                'elapsed_minutes': elapsed,
                'alert_threshold': MOCK_ALERT_THRESHOLD_MINUTES,
                'alert_triggered': elapsed >= MOCK_ALERT_THRESHOLD_MINUTES,
                'alert_sent': alert_sent.get(key, False),
            }
        else:
            result[key] = {
                'is_mock': False,
                'elapsed_minutes': 0,
                'alert_threshold': MOCK_ALERT_THRESHOLD_MINUTES,
                'alert_triggered': False,
                'alert_sent': False,
            }
    return result


MOCK_ALERT_THRESHOLD_MINUTES = 30  # 持续使用模拟数据超过此阈值触发告警


def get_data_with_fallback(cache_key: str, mock_data: list) -> tuple[list, str]:
    """
    获取数据，如果缓存为空则返回模拟数据
    返回: (data_list, data_source)  data_source: 'real' 或 'mock'
    """
    data = data_cache.get(cache_key, [])
    if data and len(data) > 0:
        # 数据恢复真实，记录日志并重置告警状态
        tracker = _get_redis_tracker()
        if tracker.get(cache_key, {}).get('is_mock'):
            logger.info(f"[Fallback] {cache_key} 数据源已恢复: mock -> real")
            tracker[cache_key] = {'is_mock': False, 'start_time': None}
            _save_redis_tracker(tracker)
            alert_sent = _get_redis_alert_sent()
            alert_sent[cache_key] = False
            _save_redis_alert_sent(alert_sent)
        return data, 'real'
    
    # 使用模拟数据
    tracker = _get_redis_tracker()
    now = datetime.now()
    
    if not tracker.get(cache_key, {}).get('is_mock'):
        # 首次切换到 mock，记录开始时间
        tracker[cache_key] = {'is_mock': True, 'start_time': now.isoformat()}
        _save_redis_tracker(tracker)
        logger.warning(f"[Fallback] {cache_key} 数据源切换: real -> mock (外部 API 无数据，启用模拟数据)")
    else:
        # 持续使用 mock，检查是否超过阈值需告警
        start_time = datetime.fromisoformat(tracker[cache_key]['start_time'])
        elapsed_minutes = (now - start_time).total_seconds() / 60
        alert_sent = _get_redis_alert_sent()
        if elapsed_minutes >= MOCK_ALERT_THRESHOLD_MINUTES and not alert_sent.get(cache_key, False):
            logger.error(f"[Fallback Alert] {cache_key} 持续使用模拟数据超过 {MOCK_ALERT_THRESHOLD_MINUTES} 分钟，请检查外部 API 凭证！")
            # 发送告警邮件
            send_mock_fallback_alert(cache_key, int(elapsed_minutes))
            alert_sent[cache_key] = True
            _save_redis_alert_sent(alert_sent)
    
    return mock_data, 'mock'


def send_mock_fallback_alert(cache_key: str, elapsed_minutes: int) -> None:
    """发送持续使用模拟数据告警邮件"""
    try:
        subject = f"[告警] {cache_key} 持续使用模拟数据超过 {MOCK_ALERT_THRESHOLD_MINUTES} 分钟"
        body = f"""
监控平台检测到 {cache_key} 数据源持续使用模拟数据已达 {elapsed_minutes} 分钟。

可能原因：
1. 外部 API Cookie/Token 已过期
2. 外部 API 接口变更或限流
3. 网络连接异常
4. 签名参数失效

建议操作：
1. 登录抖店/创作者中心重新获取 Cookie 和签名参数
2. 更新服务器 .env 配置文件
4. 重启 monitor 服务：docker compose restart monitor

数据源: {cache_key}
持续时间: {elapsed_minutes} 分钟
阈值: {MOCK_ALERT_THRESHOLD_MINUTES} 分钟
检测时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        """
        send_email(Config.ALERT_EMAIL, subject, body)
        logger.info(f"[Fallback Alert] 已发送告警邮件至 {Config.ALERT_EMAIL}")
    except Exception as e:
        logger.error(f"[Fallback Alert] 发送告警邮件失败: {e}")

alert_config = DEFAULT_ALERT_CONFIG.copy()
alert_douyin_config = DEFAULT_ALERT_DOUYIN_CONFIG.copy()
alert_dian_config = DEFAULT_ALERT_DIAN_CONFIG.copy()
auth_config = DEFAULT_AUTH_CONFIG.copy()


def load_json_file(file_path: Path, default: Any = None) -> Any:
    """Load JSON file, return default if not exists."""
    if file_path.exists():
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except json.JSONDecodeError:
            logger.error(f"Failed to parse JSON from {file_path}")
            return default
    return default


def save_json_file(file_path: Path, data: Any) -> None:
    """Save data to JSON file."""
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"Failed to save JSON to {file_path}: {e}")


def load_all_data() -> None:
    """Load all data files into cache."""
    global data_cache, alert_config, alert_douyin_config, alert_dian_config, auth_config
    data_cache['products'] = load_json_file(PRODUCTS_FILE, [])
    data_cache['orders'] = load_json_file(ORDERS_FILE, [])
    data_cache['creators'] = load_json_file(CREATORS_FILE, [])
    data_cache['videos'] = load_json_file(VIDEOS_FILE, DEFAULT_VIDEOS)
    data_cache['accounts'] = load_json_file(ACCOUNTS_FILE, DEFAULT_ACCOUNTS)
    data_cache['compliance'] = load_json_file(COMPLIANCE_FILE, DEFAULT_COMPLIANCE)
    data_cache['media'] = load_json_file(MEDIA_FILE, DEFAULT_MEDIA)
    data_cache['auth'] = load_json_file(AUTH_FILE, DEFAULT_AUTH_CONFIG)
    data_cache['creator_works'] = load_json_file(CREATOR_WORKS_FILE, [])
    alert_config.update(load_json_file(ALERT_CONFIG_FILE, DEFAULT_ALERT_CONFIG))
    alert_douyin_config.update(load_json_file(ALERT_DOUYIN_CONFIG_FILE, DEFAULT_ALERT_DOUYIN_CONFIG))
    alert_dian_config.update(load_json_file(ALERT_DIAN_CONFIG_FILE, DEFAULT_ALERT_DIAN_CONFIG))
    auth_config.update(data_cache['auth'])
    data_cache['last_update'] = datetime.now().isoformat()
    
    # Initialize compliance data (rules, logs, mock data)
    init_compliance_data()
    
    logger.info("Data loaded successfully")


def save_all_data() -> None:
    """Save all cached data to files."""
    save_json_file(PRODUCTS_FILE, data_cache['products'])
    save_json_file(ORDERS_FILE, data_cache['orders'])
    save_json_file(CREATORS_FILE, data_cache['creators'])
    save_json_file(VIDEOS_FILE, data_cache['videos'])
    save_json_file(ACCOUNTS_FILE, data_cache['accounts'])
    save_json_file(COMPLIANCE_FILE, data_cache['compliance'])
    save_json_file(MEDIA_FILE, data_cache['media'])
    save_json_file(AUTH_FILE, data_cache['auth'])
    save_json_file(CREATOR_WORKS_FILE, data_cache['creator_works'])
    save_json_file(ALERT_CONFIG_FILE, alert_config)
    save_json_file(ALERT_DOUYIN_CONFIG_FILE, alert_douyin_config)
    save_json_file(ALERT_DIAN_CONFIG_FILE, alert_dian_config)
    logger.info("Data saved successfully")


# Douyin API integration
class DouyinAPIClient:
    """Client for Douyin Open Platform API."""

    def __init__(self):
        self.app_id = Config.DOUYIN_APP_ID
        self.app_secret = Config.DOUYIN_APP_SECRET
        self.access_token = Config.DOUYIN_ACCESS_TOKEN
        self.base_url = 'https://open.douyin.com'

    def _get_headers(self) -> Dict[str, str]:
        return {
            'Authorization': f'Bearer {self.access_token}',
            'Content-Type': 'application/json'
        }

    def get_product_list(self, page: int = 1, size: int = 20) -> Dict[str, Any]:
        """Get product list from Douyin."""
        url = f'{self.base_url}/product/list'
        params = {'page': page, 'size': size}
        try:
            response = requests.get(url, headers=self._get_headers(), params=params, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            logger.error(f"Failed to fetch product list: {e}")
            return {'data': {'products': []}}

    def get_order_list(self, start_time: int, end_time: int, page: int = 1, size: int = 20) -> Dict[str, Any]:
        """Get order list from Douyin."""
        url = f'{self.base_url}/order/list'
        params = {
            'start_time': start_time,
            'end_time': end_time,
            'page': page,
            'size': size
        }
        try:
            response = requests.get(url, headers=self._get_headers(), params=params, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            logger.error(f"Failed to fetch order list: {e}")
            return {'data': {'orders': []}}

    def get_creator_info(self, creator_id: str) -> Dict[str, Any]:
        """Get creator info from Douyin."""
        url = f'{self.base_url}/creator/info'
        params = {'creator_id': creator_id}
        try:
            response = requests.get(url, headers=self._get_headers(), params=params, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            logger.error(f"Failed to fetch creator info: {e}")
            return {'data': {}}


douyin_client = DouyinAPIClient()


@_http_retry(max_retries=3, base_delay=1.0, max_delay=10.0)
def _request(url: str, params: dict = None, headers: dict = None, cookies: dict = None) -> dict:
    """通用外部 GET 请求函数（带重试、超时、熔断）。
    url: 完整的外部 URL（可包含协议、域名及路径）
    params: 查询参数字典
    headers: 可选的请求头，若未提供则使用默认公共头部
    cookies: 可选的 Cookie dict
    """
    request_headers = Config.COMMON_HEADERS.copy()
    if headers:
        request_headers.update(headers)
    if Config.API_AUTH_TOKEN:
        request_headers['Authorization'] = f'Bearer {Config.API_AUTH_TOKEN}'
    resp = requests.get(url, params=params, headers=request_headers, cookies=cookies, timeout=30)
    resp.raise_for_status()
    return resp.json()


@_http_retry(max_retries=3, base_delay=1.0, max_delay=10.0)
def _request_post(url: str, json_data: dict = None, params: dict = None, headers: dict = None, cookies: dict = None) -> dict:
    """通用外部 POST 请求函数（带重试、超时、熔断）。"""
    request_headers = Config.COMMON_HEADERS.copy()
    if headers:
        request_headers.update(headers)
    if Config.API_AUTH_TOKEN:
        request_headers['Authorization'] = f'Bearer {Config.API_AUTH_TOKEN}'
    resp = requests.post(url, json=json_data, params=params, headers=request_headers, cookies=cookies, timeout=30)
    resp.raise_for_status()
    return resp.json()


def fetch_and_store_products() -> None:
    """Fetch product data from external FXG API and store locally."""
    logger.info("Fetching products from external FXG API...")
    endpoint = f"{Config.FXG_BASE_URL}/product/tproduct/list"
    base_params = {
        'page': 1,
        'pageSize': 20,
        'appid': 1,
        '_bid': 'ffa_product',
        'aid': Config.FXG_SHOP_ID,  # Shop ID - 从环境变量读取
        '_lid': Config.FXG_LOG_ID,  # Log ID - 从环境变量读取
    }
    # 使用签名模块动态生成签名参数
    existing_tokens = {
        '__token': Config.TOKEN,
        'msToken': Config.MS_TOKEN,
        'verifyFp': Config.verifyFp,
        'fp': Config.fp,
    }
    # 合并基础参数和动态签名参数
    sign_params = sign_request(endpoint, base_params, existing_tokens, Config.USER_AGENT)
    params = {**base_params, **sign_params}
    
    headers = Config.COMMON_HEADERS.copy()
    cookies = {}
    if Config.FXG_COOKIES:
        for pair in Config.FXG_COOKIES.split(';'):
            if '=' in pair:
                k, v = pair.strip().split('=', 1)
                cookies[k] = v
    result = _request(endpoint, params=params, headers=headers, cookies=cookies)
    # 兼容外部 API 返回 list 或 dict：优先尝试 dict 取值，失败则视为 list
    try:
        products = result.get('data', {}).get('products', [])
    except AttributeError:
        products = result if isinstance(result, list) else []
    for product in products:
        product['fetched_at'] = datetime.now().isoformat()
    data_cache['products'] = products
    save_json_file(PRODUCTS_FILE, products)
    logger.info(f"Fetched and stored {len(products)} products")


def fetch_and_store_orders() -> None:
    """Fetch order data from external FXG API and store locally."""
    logger.info("Fetching orders from external FXG API...")
    endpoint = f"{Config.FXG_BASE_URL}/api/order/searchlist"
    end_time = int(datetime.now().timestamp())
    start_time = int((datetime.now() - timedelta(days=1)).timestamp())
    base_params = {
        'start_time': start_time,
        'end_time': end_time,
        'page': 1,
        'pageSize': 20,
        'appid': 1,
        '_bid': 'ffa_order',
        'aid': Config.FXG_SHOP_ID,
        '_lid': Config.FXG_LOG_ID,
    }
    # 使用签名模块动态生成签名参数
    existing_tokens = {
        '__token': Config.TOKEN,
        'msToken': Config.MS_TOKEN,
        'verifyFp': Config.verifyFp,
        'fp': Config.fp,
    }
    # 合并基础参数和动态签名参数
    sign_params = sign_request(endpoint, base_params, existing_tokens, Config.USER_AGENT)
    params = {**base_params, **sign_params}
    
    headers = Config.COMMON_HEADERS.copy()
    cookies = {}
    if Config.FXG_COOKIES:
        for pair in Config.FXG_COOKIES.split(';'):
            if '=' in pair:
                k, v = pair.strip().split('=', 1)
                cookies[k] = v
    result = _request(endpoint, params=params, headers=headers, cookies=cookies)
    # 兼容外部 API 返回 list 或 dict
    try:
        orders = result.get('data', {}).get('orders', [])
    except AttributeError:
        orders = result if isinstance(result, list) else []
    for order in orders:
        order['fetched_at'] = datetime.now().isoformat()
    data_cache['orders'] = orders
    save_json_file(ORDERS_FILE, orders)
    logger.info(f"Fetched and stored {len(orders)} orders")


def fetch_and_store_creators() -> None:
    """Fetch creator data from external Creator API and store locally."""
    logger.info("Fetching creators from external Creator API...")
    endpoint = f"{Config.CREATOR_BASE_URL}/janus/douyin/creator/data/overview/dashboard"
    # 使用签名模块动态生成签名参数
    existing_tokens = {
        '__token': Config.TOKEN,
        'msToken': Config.MS_TOKEN,
        'verifyFp': Config.verifyFp,
        'fp': Config.fp,
    }
    sign_params = sign_request(endpoint, {}, existing_tokens, Config.USER_AGENT)
    payload = {"recent_days": 7, **sign_params}
    
    headers = Config.COMMON_HEADERS.copy()
    headers['Content-Type'] = 'application/json'
    cookies = {}
    if Config.CREATOR_COOKIES:
        for pair in Config.CREATOR_COOKIES.split(';'):
            if '=' in pair:
                k, v = pair.strip().split('=', 1)
                cookies[k] = v
    # Use POST for creator dashboard (使用带重试的 _request_post)
    try:
        result = _request_post(endpoint, json_data=payload, headers=headers, cookies=cookies)
    except requests.RequestException as e:
        logger.error(f'External API request failed {endpoint}: {e}')
        # 兼容外部 API 返回 list 或 dict
        creators = []
    else:
        # 兼容外部 API 返回 list 或 dict
        try:
            creators = result.get('data', {}).get('creators', [])
        except AttributeError:
            creators = result if isinstance(result, list) else []
    for creator in creators:
        creator['fetched_at'] = datetime.now().isoformat()
    data_cache['creators'] = creators
    save_json_file(CREATORS_FILE, creators)
    logger.info(f"Fetched and stored {len(creators)} creators")


def fetch_and_store_creator_works() -> None:
    """Fetch creator work list (content management) from external Creator API and store locally."""
    logger.info("Fetching creator works from external Creator API...")
    endpoint = Config.CREATOR_WORK_LIST_URL
    # 查询参数：status=0(全部), count=12, max_cursor=0, scene=star_atlas, device_platform=android, aid=1128
    base_params = {
        'status': 0,
        'count': 12,
        'max_cursor': 0,
        'scene': 'star_atlas',
        'device_platform': 'android',
        'aid': 1128,
    }
    # 使用签名模块动态生成签名参数
    existing_tokens = {
        '__token': Config.TOKEN,
        'msToken': Config.MS_TOKEN,
        'verifyFp': Config.verifyFp,
        'fp': Config.fp,
    }
    sign_params = sign_request(endpoint, base_params, existing_tokens, Config.USER_AGENT)
    params = {**base_params, **sign_params}
    
    headers = Config.COMMON_HEADERS.copy()
    # 需要添加特定的 Referer 和其他头部
    headers.update({
        'Referer': 'https://creator.douyin.com/creator-micro/content/manage',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
    })
    cookies = {}
    if Config.CREATOR_COOKIES:
        for pair in Config.CREATOR_COOKIES.split(';'):
            if '=' in pair:
                k, v = pair.strip().split('=', 1)
                cookies[k] = v
    try:
        result = _request(endpoint, params=params, headers=headers, cookies=cookies)
    except requests.RequestException as e:
        logger.error(f'External API request failed {endpoint}: {e}')
        works = []
    else:
        # 兼容外部 API 返回格式
        try:
            works = result.get('data', {}).get('list', [])
        except AttributeError:
            works = result if isinstance(result, list) else []
    for work in works:
        work['fetched_at'] = datetime.now().isoformat()
    data_cache['creator_works'] = works
    # 保存到文件
    WORKS_FILE = DATA_DIR / 'creator_works.json'
    save_json_file(WORKS_FILE, works)
    logger.info(f"Fetched and stored {len(works)} creator works")


# =============================================================================
# COMPLIANCE CHECK ENGINE
# =============================================================================

# Default compliance rules
DEFAULT_COMPLIANCE_RULES = [
    {
        'id': 'rule_001',
        'rule_name': '广告法禁用词检测',
        'rule_description': '检测商品标题/描述中是否包含广告法禁用词',
        'rule_type': 'KEYWORD',
        'rule_content': {
            'keywords': ['最', '第一', '顶级', '极致', '完美', '绝对', '全网', '全国', '世界级', '顶尖', '王牌', '冠军', '首创', '唯一', '独家', '祖传', '秘方', '神效', '特效', '立竿见影', '根治', '百年', '千年', '万年', '永久', '终身', '终生', '全效', '全能', '全方位', '全面', '完全', '全部', '所有', '一切', '任意', '随意', '自由', '无限', '无边', '无底', '无穷', '无尽', '无数', '无量', '无度']
        },
        'is_active': True,
        'severity': 'HIGH',
        'category': '广告法',
        'created_at': datetime.now().isoformat(),
        'updated_at': datetime.now().isoformat(),
        'created_by': 'system'
    },
    {
        'id': 'rule_002',
        'rule_name': '虚假宣传关键词检测',
        'rule_description': '检测涉及虚假宣传的关键词',
        'rule_type': 'KEYWORD',
        'rule_content': {
            'keywords': ['包治百病', '治愈率100%', '零风险', '无副作用', '不反弹', '永久有效', '一次见效', '立竿见影', '神药', '灵药', '仙药', '祖传秘方', '独家配方', '绝密配方', '特供', '内部', '专供', '定制版', '限量版', '珍藏版', '典藏版', '纪念版', '绝版', '停产', '清仓', '亏本', '白菜价', '跳楼价', '亏本甩卖', '老板疯了', '老板娘跑了', '公司倒闭', '厂家直销', '源头直供', '一手货源', '零利润', '不赚钱', '交个朋友', '福利价', '福利款', '福利群', '内部价', '团购价', '批发价', '出厂价', '成本价']
        },
        'is_active': True,
        'severity': 'HIGH',
        'category': '广告法',
        'created_at': datetime.now().isoformat(),
        'updated_at': datetime.now().isoformat(),
        'created_by': 'system'
    },
    {
        'id': 'rule_003',
        'rule_name': '医疗器械/药品违规宣传',
        'rule_description': '检测普通商品是否宣传医疗功效',
        'rule_type': 'KEYWORD',
        'rule_content': {
            'keywords': ['治疗', '治愈', '康复', '缓解', '消除', '根除', '调理', '改善', '预防', '抑制', '杀菌', '抗菌', '抗病毒', '增强免疫', '调节免疫', '辅助治疗', '康复辅助', '医疗器械', '药品', '处方药', 'OTC', '国药准字', '卫食健字', '消字号', '械字号', '妆字号', '食字号']
        },
        'is_active': True,
        'severity': 'CRITICAL',
        'category': '医疗广告',
        'created_at': datetime.now().isoformat(),
        'updated_at': datetime.now().isoformat(),
        'created_by': 'system'
    },
    {
        'id': 'rule_004',
        'rule_name': '知识产权侵权风险',
        'rule_description': '检测可能涉及知识产权侵权的关键词',
        'rule_type': 'KEYWORD',
        'rule_content': {
            'keywords': ['大牌同款', '大牌平替', '品牌同款', '原单', '真标', '公司级', '纯原', '顶级复刻', '高仿', '精仿', 'A货', '真标原单', '原厂', '原版', '正品同款', '专柜同款', '专柜品质', '专柜质量', '品质对版', '细节对版', '版本对版', '原版开模', '原版皮', '原版五金', '原版包装', '全套包装', '防伪码', '防伪查询', '官网可查', '支持专柜验货', '支持鉴定', '可过毒瞳', '可过得物', '可过鉴别', '支持专柜', '专柜验货', '专柜鉴定']
        },
        'is_active': True,
        'severity': 'HIGH',
        'category': '知识产权',
        'created_at': datetime.now().isoformat(),
        'updated_at': datetime.now().isoformat(),
        'created_by': 'system'
    },
    {
        'id': 'rule_005',
        'rule_name': '食品安全违规宣传',
        'rule_description': '检测食品类商品的违规宣传',
        'rule_type': 'KEYWORD',
        'rule_content': {
            'keywords': ['特供', '专供', '定制', '限量', '珍藏', '典藏', '纪念', '纪念版', '典藏版', '珍藏版', '特制', '特选', '精选', '优选', '臻选', '甄选', '严选', '独家', '首发', '首发款', '首发版', '新品首发', '抢先', '抢购', '秒杀', '限时', '限量抢购', '手慢无', '售罄', '断货', '缺货', '补货', '到货', '现货', '现货速发', '闪电发货', '极速发货', '当日发', '次日达', '包邮', '免邮', '运费险', '退货包运费', '七天无理由', '假一赔十', '假一赔三', '支持验货', '不满意退款', '无理由退款']
        },
        'is_active': True,
        'severity': 'MEDIUM',
        'category': '食品安全',
        'created_at': datetime.now().isoformat(),
        'updated_at': datetime.now().isoformat(),
        'created_by': 'system'
    },
    {
        'id': 'rule_006',
        'rule_name': '价格欺诈风险',
        'rule_description': '检测可能涉及价格欺诈的宣传',
        'rule_type': 'REGEX',
        'rule_content': {
            'patterns': ['原价\\s*[¥¥]?\\s*\\d+\\s*现价\\s*[¥¥]?\\s*\\d+', '划线价', '吊牌价', '专柜价', '市场价', '零售价', '建议零售价', 'MSRP', '折扣', '打折', '特价', '优惠', '立减', '满减', '满折', '买赠', '买一送一', '第二件半价', '第二件0元', '免费送', '赠品', '礼品', '赠送', '加赠', '额外赠送']
        },
        'is_active': True,
        'severity': 'MEDIUM',
        'category': '价格宣传',
        'created_at': datetime.now().isoformat(),
        'updated_at': datetime.now().isoformat(),
        'created_by': 'system'
    }
]

# Compliance rules file path
COMPLIANCE_RULES_FILE = DATA_DIR / 'compliance_rules.json'

# Compliance logs file path
COMPLIANCE_LOGS_FILE = DATA_DIR / 'compliance_logs.json'

# In-memory cache for compliance rules and logs
data_cache['compliance_rules'] = []
data_cache['compliance_logs'] = []


def load_compliance_rules() -> list:
    """Load compliance rules from file."""
    return load_json_file(COMPLIANCE_RULES_FILE, DEFAULT_COMPLIANCE_RULES)


def save_compliance_rules(rules: list) -> None:
    """Save compliance rules to file."""
    save_json_file(COMPLIANCE_RULES_FILE, rules)


def load_compliance_logs() -> list:
    """Load compliance logs from file."""
    return load_json_file(COMPLIANCE_LOGS_FILE, [])


def save_compliance_logs(logs: list) -> None:
    """Save compliance logs to file."""
    save_json_file(COMPLIANCE_LOGS_FILE, logs)


def check_product_compliance(product: dict, rules: list = None) -> dict:
    """
    Check a single product against compliance rules.
    Returns compliance result with violations.
    """
    if rules is None:
        rules = data_cache['compliance_rules']
    
    violations = []
    product_text = ' '.join([
        str(product.get('product_name', '')),
        str(product.get('product_description', '')),
        str(product.get('category', '')),
        str(product.get('brand', '')),
        str(product.get('tags', '')),
    ]).lower()
    
    for rule in rules:
        if not rule.get('is_active', True):
            continue
            
        rule_type = rule.get('rule_type', 'KEYWORD')
        rule_content = rule.get('rule_content', {})
        severity = rule.get('severity', 'MEDIUM')
        category = rule.get('category', '通用')
        
        matched_keywords = []
        
        if rule_type == 'KEYWORD':
            keywords = rule_content.get('keywords', [])
            for keyword in keywords:
                if keyword.lower() in product_text:
                    matched_keywords.append(keyword)
        
        elif rule_type == 'REGEX':
            import re
            patterns = rule_content.get('patterns', [])
            for pattern in patterns:
                matches = re.findall(pattern, product_text, re.IGNORECASE)
                if matches:
                    matched_keywords.extend(matches)
        
        if matched_keywords:
            violations.append({
                'rule_id': rule['id'],
                'rule_name': rule['rule_name'],
                'violation_type': category,
                'violation_detail': f"命中关键词: {', '.join(matched_keywords[:5])}{'...' if len(matched_keywords) > 5 else ''}",
                'matched_keywords': matched_keywords,
                'severity': severity,
                'category': category
            })
    
    # Calculate compliance score
    if violations:
        max_severity = max(v['severity'] for v in violations)
        severity_scores = {'CRITICAL': 0, 'HIGH': 30, 'MEDIUM': 60, 'LOW': 85}
        compliance_score = severity_scores.get(max_severity, 50)
        compliance_status = 'FAIL' if max_severity in ['CRITICAL', 'HIGH'] else 'WARNING'
    else:
        compliance_score = 100
        compliance_status = 'PASS'
    
    return {
        'product_id': product.get('product_id'),
        'product_name': product.get('product_name'),
        'compliance_status': compliance_status,
        'compliance_score': compliance_score,
        'violations': violations,
        'violation_count': len(violations),
        'checked_at': datetime.now().isoformat(),
        'rules_checked': len([r for r in rules if r.get('is_active', True)])
    }


def fetch_and_check_compliance() -> dict:
    """
    Run compliance check on all products.
    Returns summary of check results.
    """
    logger.info("Running compliance check on all products...")
    
    products = data_cache['products']
    rules = data_cache['compliance_rules']
    
    if not products:
        logger.warning("No products to check for compliance")
        return {'checked': 0, 'pass': 0, 'warning': 0, 'fail': 0, 'details': []}
    
    if not rules:
        logger.warning("No compliance rules configured")
        return {'checked': 0, 'pass': 0, 'warning': 0, 'fail': 0, 'details': []}
    
    check_batch_id = f"check_{int(datetime.now().timestamp())}"
    results = []
    stats = {'checked': 0, 'pass': 0, 'warning': 0, 'fail': 0}
    
    for product in products:
        result = check_product_compliance(product, rules)
        results.append(result)
        stats['checked'] += 1
        stats[result['compliance_status'].lower()] += 1
        
        # Update compliance data in cache
        compliance_item = {
            'product_id': product.get('product_id'),
            'product_name': product.get('product_name'),
            'risk_level': 'high' if result['compliance_status'] == 'FAIL' else ('medium' if result['compliance_status'] == 'WARNING' else 'low'),
            'violation_type': violations[0]['violation_type'] if (violations := result['violations']) else '合规',
            'violation_detail': '; '.join([v['violation_detail'] for v in result['violations']]) if result['violations'] else '无违规',
            'detected_at': result['checked_at'],
            'status': 'pending',
            'compliance_score': result['compliance_score'],
            'violations': result['violations'],
            'check_batch_id': check_batch_id
        }
        
        # Update or add to compliance cache
        existing_idx = next((i for i, c in enumerate(data_cache['compliance']) if c.get('product_id') == product.get('product_id')), None)
        if existing_idx is not None:
            data_cache['compliance'][existing_idx] = compliance_item
        else:
            data_cache['compliance'].append(compliance_item)
        
        # Add to logs
        for violation in result['violations']:
            log_entry = {
                'id': f"log_{int(datetime.now().timestamp())}_{len(data_cache['compliance_logs'])}",
                'check_batch_id': check_batch_id,
                'product_id': product.get('product_id'),
                'rule_id': violation['rule_id'],
                'violation_detail': violation['violation_detail'],
                'severity': violation['severity'],
                'category': violation['category'],
                'checked_at': result['checked_at']
            }
            data_cache['compliance_logs'].append(log_entry)
    
    # Save to files
    save_json_file(COMPLIANCE_FILE, data_cache['compliance'])
    save_compliance_logs(data_cache['compliance_logs'])
    
    logger.info(f"Compliance check completed: {stats}")
    return {'checked': stats['checked'], 'pass': stats['pass'], 'warning': stats['warning'], 'fail': stats['fail'], 'details': results, 'batch_id': check_batch_id}


def get_compliance_stats() -> dict:
    """Get compliance statistics for dashboard."""
    compliance = data_cache['compliance']
    products = data_cache['products']
    
    total_products = len(products)
    total_checked = len(compliance)
    
    if total_checked == 0:
        return {
            'total_products': total_products,
            'checked_products': 0,
            'pass_count': 0,
            'warning_count': 0,
            'fail_count': 0,
            'compliance_rate': 0,
            'risk_distribution': {'high': 0, 'medium': 0, 'low': 0},
            'status_distribution': {'pending': 0, 'ignored': 0, 'resolved': 0},
            'category_distribution': {},
            'recent_checks': []
        }
    
    pass_count = len([c for c in compliance if c.get('risk_level') == 'low'])
    warning_count = len([c for c in compliance if c.get('risk_level') == 'medium'])
    fail_count = len([c for c in compliance if c.get('risk_level') == 'high'])
    
    compliance_rate = round((pass_count / total_checked) * 100, 2) if total_checked > 0 else 0
    
    risk_distribution = {
        'high': fail_count,
        'medium': warning_count,
        'low': pass_count
    }
    
    status_distribution = {
        'pending': len([c for c in compliance if c.get('status') == 'pending']),
        'ignored': len([c for c in compliance if c.get('status') == 'ignored']),
        'resolved': len([c for c in compliance if c.get('status') == 'resolved'])
    }
    
    # Category distribution
    category_distribution = {}
    for c in compliance:
        cat = c.get('violation_type', '合规')
        category_distribution[cat] = category_distribution.get(cat, 0) + 1
    
    # Recent checks (last 7 days)
    from datetime import timedelta
    seven_days_ago = (datetime.now() - timedelta(days=7)).isoformat()
    recent_checks = [c for c in compliance if c.get('detected_at', '') >= seven_days_ago]
    recent_checks.sort(key=lambda x: x.get('detected_at', ''), reverse=True)
    
    return {
        'total_products': total_products,
        'checked_products': total_checked,
        'pass_count': pass_count,
        'warning_count': warning_count,
        'fail_count': fail_count,
        'compliance_rate': compliance_rate,
        'risk_distribution': risk_distribution,
        'status_distribution': status_distribution,
        'category_distribution': category_distribution,
        'recent_checks': recent_checks[:10]
    }


def init_compliance_data() -> None:
    """Initialize compliance data (rules, mock data)."""
    # Load rules
    data_cache['compliance_rules'] = load_compliance_rules()
    save_compliance_rules(data_cache['compliance_rules'])
    
    # Load logs
    data_cache['compliance_logs'] = load_compliance_logs()
    
    # Generate mock compliance data if empty
    if not data_cache['compliance'] and data_cache['products']:
        logger.info("Generating mock compliance data...")
        mock_compliance = []
        import random
        risk_levels = ['low', 'medium', 'high']
        violation_types = ['广告法', '医疗广告', '知识产权', '食品安全', '价格宣传', '合规']
        statuses = ['pending', 'ignored', 'resolved']
        
        for product in data_cache['products'][:20]:  # Generate for first 20 products
            risk = random.choice(risk_levels)
            violation_type = random.choice(violation_types)
            status = random.choice(statuses)
            
            if risk == 'high':
                violation_detail = '命中关键词: 最, 顶级, 绝对, 全网, 世界级'
            elif risk == 'medium':
                violation_detail = '命中关键词: 特价, 促销, 限时, 限量'
            else:
                violation_detail = '无违规'
            
            mock_compliance.append({
                'product_id': product.get('product_id'),
                'product_name': product.get('product_name'),
                'risk_level': risk,
                'violation_type': violation_type,
                'violation_detail': violation_detail,
                'detected_at': (datetime.now() - timedelta(days=random.randint(0, 30))).isoformat(),
                'status': status,
                'compliance_score': random.randint(60, 100) if risk == 'low' else (random.randint(30, 60) if risk == 'medium' else random.randint(0, 30)),
                'violations': [],
                'check_batch_id': 'mock_init'
            })
        
        data_cache['compliance'] = mock_compliance
        save_json_file(COMPLIANCE_FILE, mock_compliance)
        logger.info(f"Generated {len(mock_compliance)} mock compliance records")


def check_alerts() -> None:
    """Check alert conditions and send notifications if needed."""
    if not alert_config.get('enabled', True):
        return
    
    logger.info("Checking alert conditions...")
    
    # Check sales drop
    products = data_cache['products']
    for product in products:
        sales_today = product.get('sales_today', 0)
        sales_yesterday = product.get('sales_yesterday', 0)
        
        if sales_yesterday > 0:
            drop_rate = (sales_yesterday - sales_today) / sales_yesterday
            if drop_rate >= alert_config['sales_drop_threshold']:
                send_alert(
                    'sales_drop',
                    f"Product {product.get('product_name', 'Unknown')} sales dropped by {drop_rate:.1%}",
                    product
                )
        
        # Check inventory
        inventory = product.get('inventory', 0)
        if inventory <= alert_config['inventory_low_threshold']:
            send_alert(
                'low_inventory',
                f"Product {product.get('product_name', 'Unknown')} inventory low: {inventory}",
                product
            )
    
    # Check conversion rate drop
    for product in products:
        conv_today = product.get('conversion_rate_today', 0)
        conv_yesterday = product.get('conversion_rate_yesterday', 0)
        
        if conv_yesterday > 0:
            drop_rate = (conv_yesterday - conv_today) / conv_yesterday
            if drop_rate >= alert_config['conversion_drop_threshold']:
                send_alert(
                    'conversion_drop',
                    f"Product {product.get('product_name', 'Unknown')} conversion rate dropped by {drop_rate:.1%}",
                    product
                )


def send_alert(alert_type: str, message: str, data: Dict[str, Any]) -> None:
    """Send alert notification."""
    alert = {
        'type': alert_type,
        'message': message,
        'data': data,
        'timestamp': datetime.now().isoformat()
    }
    
    logger.warning(f"ALERT: {alert}")
    
    # Send email if configured
    email = alert_config.get('notification_email')
    if email:
        try:
            send_email(email, f"Douyin Monitor Alert: {alert_type}", message)
        except Exception as e:
            logger.error(f"Failed to send alert email: {e}")


def send_email(to: str, subject: str, body: str) -> None:
    """Send email notification (placeholder - implement with SMTP)."""
    # In production, use smtplib or a service like SendGrid
    logger.info(f"Would send email to {to}: {subject} - {body}")


def scheduled_job() -> None:
    """Main scheduled job to fetch all data and check alerts."""
    logger.info("Running scheduled job...")
    fetch_and_store_products()
    fetch_and_store_orders()
    fetch_and_store_creators()
    fetch_and_store_creator_works()
    fetch_and_check_compliance()
    check_alerts()
    data_cache['last_update'] = datetime.now().isoformat()
    logger.info("Scheduled job completed")


# Initialize scheduler
scheduler = BackgroundScheduler()
scheduler.add_job(
    scheduled_job,
    trigger=IntervalTrigger(minutes=Config.SCHEDULE_INTERVAL_MINUTES),
    id='douyin_data_fetch',
    name='Fetch Douyin data and check alerts',
    replace_existing=True
)


# API Routes
@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint."""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'last_update': data_cache['last_update']
    })

@app.route('/api/products/stats', methods=['GET'])
def get_product_stats():
    """获取商品统计信息（调用外部 API）。"""
    endpoint = f"{Config.FXG_BASE_URL}/products/stats"
    params = {
        'tab': request.args.get('tab', 'onSale'),
        'appid': request.args.get('appid', '1')
    }
    headers = Config.COMMON_HEADERS.copy()
    cookies = {}
    if Config.FXG_COOKIES:
        for pair in Config.FXG_COOKIES.split(';'):
            if '=' in pair:
                k, v = pair.strip().split('=', 1)
                cookies[k] = v
    result = _request(endpoint, params=params, headers=headers, cookies=cookies)
    return jsonify({
        'success': True,
        'data': result.get('data', {}),
        'message': 'Product stats fetched from external service'
    })


@app.route('/api/products', methods=['GET'])
def get_products():
    """Get product list from internal cache with optional filtering."""
    page = int(request.args.get('page', 1))
    size = int(request.args.get('size', 20))
    keyword = request.args.get('keyword', '').lower()
    
    products, data_source = get_data_with_fallback('products', MOCK_PRODUCTS)
    
    if keyword:
        products = [p for p in products if keyword in p.get('product_name', '').lower()]
    
    total = len(products)
    start = (page - 1) * size
    end = start + size
    
    return jsonify({
        'data': products[start:end],
        'total': total,
        'page': page,
        'size': size,
        'data_source': data_source
    })

# -------------------------------------------------------------------
# 新增：外部商品列表转发接口（完整参数透传）
@app.route('/api/products/external', methods=['GET'])
def get_external_product_list():
    """转发商品列表请求到外部 API，使用 fxg 基础 URL、统一 Header 与 Cookie。"""
    params = request.args.to_dict(flat=True)
    endpoint = f"{Config.FXG_BASE_URL}/product/tproduct/list"
    # 使用统一请求头和 Cookie
    headers = Config.COMMON_HEADERS.copy()
    cookies = {}
    if Config.FXG_COOKIES:
        # 将 Cookie 字符串解析为 dict（简单分号分割）
        for pair in Config.FXG_COOKIES.split(';'):
            if '=' in pair:
                k, v = pair.strip().split('=', 1)
                cookies[k] = v
    result = _request(endpoint, params=params)
    # Note: _request currently does not attach headers/cookies; we will extend it later if needed.
    return jsonify({
        'success': True,
        'data': result.get('data', {}),
        'message': 'Product list fetched from external service'
    })


@app.route('/api/products/<product_id>', methods=['GET'])
def get_product(product_id: str):
    """Get single product details."""
    product = next((p for p in data_cache['products'] if p.get('product_id') == product_id), None)
    if not product:
        return jsonify({'error': 'Product not found'}), 404
    return jsonify({'data': product})


@app.route('/api/orders', methods=['GET'])
def get_orders():
    """Get order list with optional filtering and summary statistics."""
    page = int(request.args.get('page', 1))
    size = int(request.args.get('size', 20))
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    status_filter = request.args.get('status')
    
    orders, data_source = get_data_with_fallback('orders', MOCK_ORDERS)
    
    # 过滤时间范围
    if start_date:
        orders = [o for o in orders if o.get('create_time', '') >= start_date]
    if end_date:
        orders = [o for o in orders if o.get('create_time', '') <= end_date]
    
    # 过滤状态（保持向后兼容）
    if status_filter:
        orders = [o for o in orders if o.get('status') == status_filter]
    
    total = len(orders)
    start = (page - 1) * size
    end = start + size
    
    # 统计汇总（示例实现，仅返回 all，其他分类默认 0）
    summary = {
        'abnormal': {'amount': 0, 'count': 0},
        'after_sale': {'amount': 0, 'count': 0},
        'all': {'amount': sum(o.get('amount', 0) for o in orders), 'count': total},
        'closed': {'amount': 0, 'count': 0},
        'done': {'amount': 0, 'count': 0},
        'sent': {'amount': 0, 'count': 0},
        'timeout_send': {'amount': 0, 'count': 0},
        'urgent_send': {'amount': 0, 'count': 0},
        'wait_pay': {'amount': 0, 'count': 0},
        'wait_send': {'amount': 0, 'count': 0},
    }
    
    return jsonify({
        'success': True,
        'data': summary,
        'list': orders[start:end],
        'total': total,
        'page': page,
        'size': size,
        'data_source': data_source
    })

# -------------------------------------------------------------------
# 新增：外部订单统计转发接口（完整参数透传）
@app.route('/api/orders/stats', methods=['GET'])
def get_external_order_stats():
    """转发订单统计请求到外部 API，使用 fxg 基础 URL、统一 Header 与 Cookie。"""
    params = request.args.to_dict(flat=True)
    endpoint = f"{Config.FXG_BASE_URL}/api/order/tabcnt"
    headers = Config.COMMON_HEADERS.copy()
    cookies = {}
    if Config.FXG_COOKIES:
        for pair in Config.FXG_COOKIES.split(';'):
            if '=' in pair:
                k, v = pair.strip().split('=', 1)
                cookies[k] = v
    result = _request(endpoint, params=params, headers=headers, cookies=cookies)
    return jsonify({
        'success': True,
        'data': result.get('data', {}),
        'message': 'Order stats fetched from external service'
    })


@app.route('/api/creators', methods=['GET'])
def get_creators():
    """Get creator list."""
    creators, data_source = get_data_with_fallback('creators', MOCK_CREATORS)
    return jsonify({
        'data': creators,
        'total': len(creators),
        'data_source': data_source
    })


@app.route('/api/creators/<creator_id>', methods=['GET'])
def get_creator(creator_id: str):
    """Get single creator details."""
    creator = next((c for c in data_cache['creators'] if c.get('creator_id') == creator_id), None)
    if not creator:
        return jsonify({'error': 'Creator not found'}), 404
    return jsonify({'data': creator})


@app.route('/api/creators/works', methods=['GET'])
def get_creator_works():
    """Get creator work list (content management)."""
    page = int(request.args.get('page', 1))
    size = int(request.args.get('size', 20))
    keyword = request.args.get('keyword', '').lower()
    status_filter = request.args.get('status')
    
    works = data_cache['creator_works']
    
    if keyword:
        works = [w for w in works if keyword in w.get('title', '').lower() or keyword in w.get('creator_name', '').lower()]
    if status_filter:
        works = [w for w in works if w.get('status') == status_filter]
    
    total = len(works)
    start = (page - 1) * size
    end = start + size
    
    return jsonify({
        'data': works[start:end],
        'total': total,
        'page': page,
        'size': size
    })


@app.route('/api/creators/works/external', methods=['GET'])
def get_external_creator_works():
    """转发创作者作品列表请求到外部 API，使用 creator 基础 URL、统一 Header 与 Cookie。"""
    params = request.args.to_dict(flat=True)
    # 设置默认参数
    params.setdefault('status', '0')
    params.setdefault('count', '12')
    params.setdefault('max_cursor', '0')
    params.setdefault('scene', 'star_atlas')
    params.setdefault('device_platform', 'android')
    params.setdefault('aid', '1128')
    
    endpoint = Config.CREATOR_WORK_LIST_URL
    headers = Config.COMMON_HEADERS.copy()
    headers.update({
        'Referer': 'https://creator.douyin.com/creator-micro/content/manage',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
    })
    cookies = {}
    if Config.CREATOR_COOKIES:
        for pair in Config.CREATOR_COOKIES.split(';'):
            if '=' in pair:
                k, v = pair.strip().split('=', 1)
                cookies[k] = v
    
    # 使用签名模块动态生成签名参数
    existing_tokens = {
        '__token': Config.TOKEN,
        'msToken': Config.MS_TOKEN,
        'verifyFp': Config.verifyFp,
        'fp': Config.fp,
    }
    sign_params = sign_request(endpoint, params, existing_tokens, Config.USER_AGENT)
    # 合并参数和签名
    final_params = {**params, **sign_params}
    
    result = _request(endpoint, params=final_params, headers=headers, cookies=cookies)
    
    return jsonify({
        'success': True,
        'data': result.get('data', {}),
        'message': 'Creator works fetched from external service'
    })


@app.route('/api/mock/status', methods=['GET'])
def get_mock_status_api():
    """获取 Mock 数据源状态（用于前端告警展示）"""
    return jsonify({'data': get_mock_status()})


@app.route('/api/dashboard/stats', methods=['GET'])
@app.route('/api/stats', methods=['GET'])
def get_dashboard_stats():
    """Get dashboard statistics."""
    products, products_source = get_data_with_fallback('products', MOCK_PRODUCTS)
    orders, orders_source = get_data_with_fallback('orders', MOCK_ORDERS)
    
    # 如果任一数据源为 mock，整体标记为 mock
    data_source = 'real' if products_source == 'real' and orders_source == 'real' else 'mock'
    
    total_sales_today = sum(p.get('sales_today', 0) for p in products)
    total_sales_yesterday = sum(p.get('sales_yesterday', 0) for p in products)
    total_revenue_today = sum(o.get('amount', 0) for o in orders)
    # 没有历史订单数据，暂时使用今天的金额作为昨天的占位
    total_revenue_yesterday = total_revenue_today
    total_orders_today = len(orders)
    total_orders_yesterday = total_orders_today
    avg_conversion_today = sum(p.get('conversion_rate', 0) for p in products) / len(products) if products else 0
    avg_conversion_yesterday = sum(p.get('conversion_rate_yesterday', p.get('conversion_rate',0)) for p in products) / len(products) if products else 0
    
    # Sales trend (last 7 天) - 模拟
    base_sales = max(total_sales_today, 100)  # 确保基础值至少100，避免负数
    sales_trend = [
        {'date': (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d'), 'sales': base_sales - i * 10}
        for i in range(6, -1, -1)
    ]
    
    # TOP 商品
    top_products = sorted(products, key=lambda p: p.get('sales_today', 0), reverse=True)[:5]
    
    return jsonify({
        'data': {
            'total_sales_today': total_sales_today,
            'total_sales_yesterday': total_sales_yesterday,
            'total_revenue_today': total_revenue_today,
            'total_revenue_yesterday': total_revenue_yesterday,
            'total_orders_today': total_orders_today,
            'total_orders_yesterday': total_orders_yesterday,
            'avg_conversion_rate': round(avg_conversion_today, 4),
            'avg_conversion_rate_yesterday': round(avg_conversion_yesterday, 4),
            'sales_trend': sales_trend,
            'top_products': top_products
        },
        'data_source': data_source
    })


@app.route('/api/alerts/config', methods=['GET'])
def get_alert_config():
    """Get alert configuration."""
    return jsonify({'data': alert_config})


@app.route('/api/alerts/config', methods=['POST'])
def update_alert_config():
    """Update alert configuration."""
    global alert_config
    new_config = request.get_json()
    
    if not new_config:
        return jsonify({'error': 'Invalid config'}), 400
    
    # Validate required fields
    allowed_fields = [
        'sales_drop_threshold',
        'conversion_drop_threshold',
        'inventory_low_threshold',
        'notification_email',
        'enabled'
    ]
    
    for key, value in new_config.items():
        if key in allowed_fields:
            alert_config[key] = value
    
    save_json_file(ALERT_CONFIG_FILE, alert_config)
    return jsonify({'data': alert_config, 'message': 'Alert config updated'})


@app.route('/api/sync', methods=['POST'])
def manual_sync():
    """Manually trigger data synchronization."""
    scheduled_job()
    return jsonify({'message': 'Sync completed', 'last_update': data_cache['last_update']})


# =============================================================================
# NEW API ENDPOINTS FOR MISSING PAGES
# =============================================================================

# --- Video Management API ---
@app.route('/api/videos', methods=['GET'])
def get_videos():
    """Get video list with filtering."""
    page = int(request.args.get('page', 1))
    size = int(request.args.get('size', 20))
    keyword = request.args.get('keyword', '').lower()
    status_filter = request.args.get('status')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    videos = data_cache['videos']
    
    if keyword:
        videos = [v for v in videos if keyword in v.get('title', '').lower() or keyword in v.get('creator_name', '').lower()]
    if status_filter:
        videos = [v for v in videos if v.get('status') == status_filter]
    if start_date:
        videos = [v for v in videos if v.get('create_time', '') >= start_date]
    if end_date:
        videos = [v for v in videos if v.get('create_time', '') <= end_date]
    
    total = len(videos)
    start = (page - 1) * size
    end = start + size
    
    return jsonify({
        'data': videos[start:end],
        'total': total,
        'page': page,
        'size': size
    })


@app.route('/api/videos/<video_id>', methods=['GET'])
def get_video(video_id: str):
    """Get single video details."""
    video = next((v for v in data_cache['videos'] if v.get('video_id') == video_id), None)
    if not video:
        return jsonify({'error': 'Video not found'}), 404
    return jsonify({'data': video})


@app.route('/api/videos', methods=['POST'])
def create_video():
    """Create new video entry."""
    data = request.get_json()
    if not data:
        return jsonify({'error': 'Invalid data'}), 400
    
    video = {
        'video_id': f"vid_{int(datetime.now().timestamp())}",
        'title': data.get('title', ''),
        'creator_name': data.get('creator_name', ''),
        'play_count': data.get('play_count', 0),
        'like_count': data.get('like_count', 0),
        'comment_count': data.get('comment_count', 0),
        'share_count': data.get('share_count', 0),
        'status': data.get('status', 'draft'),
        'create_time': datetime.now().isoformat(),
        'update_time': datetime.now().isoformat()
    }
    
    data_cache['videos'].insert(0, video)
    save_all_data()
    return jsonify({'data': video, 'message': 'Video created'})


@app.route('/api/videos/<video_id>', methods=['PUT'])
def update_video(video_id: str):
    """Update video entry."""
    data = request.get_json()
    if not data:
        return jsonify({'error': 'Invalid data'}), 400
    
    video = next((v for v in data_cache['videos'] if v.get('video_id') == video_id), None)
    if not video:
        return jsonify({'error': 'Video not found'}), 404
    
    video.update({
        'title': data.get('title', video['title']),
        'creator_name': data.get('creator_name', video['creator_name']),
        'play_count': data.get('play_count', video['play_count']),
        'like_count': data.get('like_count', video['like_count']),
        'comment_count': data.get('comment_count', video['comment_count']),
        'share_count': data.get('share_count', video['share_count']),
        'status': data.get('status', video['status']),
        'update_time': datetime.now().isoformat()
    })
    
    save_all_data()
    return jsonify({'data': video, 'message': 'Video updated'})


@app.route('/api/videos/<video_id>', methods=['DELETE'])
def delete_video(video_id: str):
    """Delete video entry."""
    video = next((v for v in data_cache['videos'] if v.get('video_id') == video_id), None)
    if not video:
        return jsonify({'error': 'Video not found'}), 404
    
    data_cache['videos'] = [v for v in data_cache['videos'] if v.get('video_id') != video_id]
    save_all_data()
    return jsonify({'message': 'Video deleted'})


# --- Auth Management API ---
@app.route('/api/auth/status', methods=['GET'])
def get_auth_status():
    """Get authorization status."""
    return jsonify({'data': auth_config})


@app.route('/api/auth/login', methods=['GET'])
def auth_login():
    """Initiate OAuth login - redirect to Douyin auth page."""
    # In production, this would redirect to Douyin OAuth URL
    auth_url = f"https://open.douyin.com/platform/oauth/connect/?client_key={auth_config.get('douyin_app_id', '')}&response_type=code&redirect_uri={auth_config.get('redirect_uri', '')}&scope=video.list,video.create,creator.info"
    return jsonify({
        'auth_url': auth_url,
        'message': 'Redirect to Douyin OAuth'
    })


@app.route('/api/auth/callback', methods=['GET'])
def auth_callback():
    """OAuth callback handler."""
    code = request.args.get('code')
    error = request.args.get('error')
    
    if error:
        return jsonify({'error': error}), 400
    
    if not code:
        return jsonify({'error': 'Missing authorization code'}), 400
    
    # In production, exchange code for access token
    # For now, simulate successful auth
    auth_config.update({
        'authorized': True,
        'access_token': f"access_token_{int(datetime.now().timestamp())}",
        'refresh_token': f"refresh_token_{int(datetime.now().timestamp())}",
        'expires_at': int((datetime.now() + timedelta(days=30)).timestamp()),
        'scope': ['video.list', 'video.create', 'creator.info']
    })
    data_cache['auth'] = auth_config
    save_all_data()
    
    return jsonify({
        'message': 'Authorization successful',
        'data': auth_config
    })


@app.route('/api/auth/logout', methods=['POST'])
def auth_logout():
    """Revoke authorization."""
    auth_config.update({
        'authorized': False,
        'access_token': '',
        'refresh_token': '',
        'expires_at': 0,
        'scope': []
    })
    data_cache['auth'] = auth_config
    save_all_data()
    return jsonify({'message': 'Authorization revoked'})


@app.route('/api/auth/qr-code', methods=['GET'])
def get_auth_qr_code():
    """Get QR code for authorization."""
    # Return a placeholder QR code URL
    # In production, generate actual QR code for Douyin OAuth
    qr_data = f"douyin_oauth:{auth_config.get('douyin_app_id', '')}:{int(datetime.now().timestamp())}"
    import base64
    qr_base64 = base64.b64encode(qr_data.encode()).decode()
    return jsonify({
        'qr_code': f"data:image/png;base64,{qr_base64}",
        'message': 'Scan with Douyin app'
    })


# --- Account Management API ---
@app.route('/api/accounts', methods=['GET'])
def get_accounts():
    """Get account list with filtering."""
    page = int(request.args.get('page', 1))
    size = int(request.args.get('size', 20))
    keyword = request.args.get('keyword', '').lower()
    status_filter = request.args.get('status')
    
    accounts = data_cache['accounts']
    
    if keyword:
        accounts = [a for a in accounts if keyword in a.get('account_name', '').lower() or keyword in a.get('account_id', '').lower()]
    if status_filter:
        accounts = [a for a in accounts if a.get('status') == status_filter]
    
    total = len(accounts)
    start = (page - 1) * size
    end = start + size
    
    return jsonify({
        'data': accounts[start:end],
        'total': total,
        'page': page,
        'size': size
    })


@app.route('/api/accounts/<account_id>', methods=['GET'])
def get_account(account_id: str):
    """Get single account details."""
    account = next((a for a in data_cache['accounts'] if a.get('account_id') == account_id), None)
    if not account:
        return jsonify({'error': 'Account not found'}), 404
    return jsonify({'data': account})


@app.route('/api/accounts', methods=['POST'])
def create_account():
    """Create new account."""
    data = request.get_json()
    if not data:
        return jsonify({'error': 'Invalid data'}), 400
    
    account = {
        'account_id': f"acc_{int(datetime.now().timestamp())}",
        'account_name': data.get('account_name', ''),
        'account_type': data.get('account_type', 'personal'),
        'phone': data.get('phone', ''),
        'email': data.get('email', ''),
        'status': data.get('status', 'active'),
        'last_login': None,
        'create_time': datetime.now().isoformat(),
        'update_time': datetime.now().isoformat()
    }
    
    data_cache['accounts'].insert(0, account)
    save_all_data()
    return jsonify({'data': account, 'message': 'Account created'})


@app.route('/api/accounts/<account_id>', methods=['PUT'])
def update_account(account_id: str):
    """Update account."""
    data = request.get_json()
    if not data:
        return jsonify({'error': 'Invalid data'}), 400
    
    account = next((a for a in data_cache['accounts'] if a.get('account_id') == account_id), None)
    if not account:
        return jsonify({'error': 'Account not found'}), 404
    
    account.update({
        'account_name': data.get('account_name', account['account_name']),
        'account_type': data.get('account_type', account['account_type']),
        'phone': data.get('phone', account['phone']),
        'email': data.get('email', account['email']),
        'status': data.get('status', account['status']),
        'update_time': datetime.now().isoformat()
    })
    
    save_all_data()
    return jsonify({'data': account, 'message': 'Account updated'})


@app.route('/api/accounts/<account_id>', methods=['DELETE'])
def delete_account(account_id: str):
    """Delete account."""
    account = next((a for a in data_cache['accounts'] if a.get('account_id') == account_id), None)
    if not account:
        return jsonify({'error': 'Account not found'}), 404
    
    data_cache['accounts'] = [a for a in data_cache['accounts'] if a.get('account_id') != account_id]
    save_all_data()
    return jsonify({'message': 'Account deleted'})


# --- Compliance Management API ---
@app.route('/api/compliance', methods=['GET'])
def get_compliance():
    """Get compliance list with filtering."""
    page = int(request.args.get('page', 1))
    size = int(request.args.get('size', 20))
    keyword = request.args.get('keyword', '').lower()
    risk_filter = request.args.get('risk_level')
    status_filter = request.args.get('status')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    compliance = data_cache['compliance']
    
    if keyword:
        compliance = [c for c in compliance if keyword in c.get('product_name', '').lower() or keyword in c.get('product_id', '').lower()]
    if risk_filter:
        compliance = [c for c in compliance if c.get('risk_level') == risk_filter]
    if status_filter:
        compliance = [c for c in compliance if c.get('status') == status_filter]
    if start_date:
        compliance = [c for c in compliance if c.get('detected_at', '') >= start_date]
    if end_date:
        compliance = [c for c in compliance if c.get('detected_at', '') <= end_date]
    
    total = len(compliance)
    start = (page - 1) * size
    end = start + size
    
    return jsonify({
        'data': compliance[start:end],
        'total': total,
        'page': page,
        'size': size
    })


@app.route('/api/compliance/<item_id>/ignore', methods=['POST'])
def ignore_compliance(item_id: str):
    """Ignore compliance issue."""
    item = next((c for c in data_cache['compliance'] if c.get('product_id') == item_id), None)
    if not item:
        return jsonify({'error': 'Compliance item not found'}), 404
    
    item['status'] = 'ignored'
    item['ignored_at'] = datetime.now().isoformat()
    save_all_data()
    return jsonify({'data': item, 'message': 'Compliance issue ignored'})


@app.route('/api/compliance/<item_id>/take-down', methods=['POST'])
def take_down_compliance(item_id: str):
    """Take down product for compliance violation."""
    item = next((c for c in data_cache['compliance'] if c.get('product_id') == item_id), None)
    if not item:
        return jsonify({'error': 'Compliance item not found'}), 404
    
    item['status'] = 'resolved'
    item['resolved_at'] = datetime.now().isoformat()
    item['resolution'] = 'taken_down'
    save_all_data()
    return jsonify({'data': item, 'message': 'Product taken down'})


@ app.route('/api/compliance/<item_id>/restore', methods=['POST'])
def restore_compliance(item_id: str):
    """Restore compliance issue from ignored."""
    item = next((c for c in data_cache['compliance'] if c.get('product_id') == item_id), None)
    if not item:
        return jsonify({'error': 'Compliance item not found'}), 404
    
    item['status'] = 'pending'
    item['restored_at'] = datetime.now().isoformat()
    save_all_data()
    return jsonify({'data': item, 'message': 'Compliance issue restored'})


@app.route('/api/compliance/stats', methods=['GET'])
def get_compliance_stats_api():
    """Get compliance statistics for dashboard."""
    stats = get_compliance_stats()
    return jsonify({'data': stats})


@app.route('/api/compliance/check', methods=['POST'])
def trigger_compliance_check():
    """Trigger manual compliance check."""
    result = fetch_and_check_compliance()
    return jsonify({'data': result, 'message': 'Compliance check completed'})


@app.route('/api/compliance/export', methods=['GET'])
def export_compliance():
    """Export compliance report as CSV."""
    import csv
    import io
    
    compliance = data_cache['compliance']
    
    # Apply same filters as get_compliance
    keyword = request.args.get('keyword', '').lower()
    risk_filter = request.args.get('risk_level')
    status_filter = request.args.get('status')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    if keyword:
        compliance = [c for c in compliance if keyword in c.get('product_name', '').lower() or keyword in c.get('product_id', '').lower()]
    if risk_filter:
        compliance = [c for c in compliance if c.get('risk_level') == risk_filter]
    if status_filter:
        compliance = [c for c in compliance if c.get('status') == status_filter]
    if start_date:
        compliance = [c for c in compliance if c.get('detected_at', '') >= start_date]
    if end_date:
        compliance = [c for c in compliance if c.get('detected_at', '') <= end_date]
    
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Write header
    writer.writerow(['商品ID', '商品名称', '风险等级', '违规类型', '违规详情', '合规分数', '检测时间', '处理状态', '处理时间'])
    
    # Write data
    for c in compliance:
        writer.writerow([
            c.get('product_id', ''),
            c.get('product_name', ''),
            c.get('risk_level', ''),
            c.get('violation_type', ''),
            c.get('violation_detail', ''),
            c.get('compliance_score', ''),
            c.get('detected_at', ''),
            c.get('status', ''),
            c.get('ignored_at') or c.get('resolved_at') or c.get('restored_at') or ''
        ])
    
    output.seek(0)
    csv_data = output.getvalue()
    output.close()
    
    from flask import Response
    return Response(
        csv_data,
        mimetype='text/csv',
        headers={'Content-Disposition': f'attachment; filename=compliance_report_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'}
    )


# --- Compliance Rules Management API ---
@app.route('/api/compliance/rules', methods=['GET'])
def get_compliance_rules():
    """Get compliance rules list."""
    rules = data_cache['compliance_rules']
    return jsonify({'data': rules})


@app.route('/api/compliance/rules', methods=['POST'])
def create_compliance_rule():
    """Create new compliance rule."""
    new_rule = request.get_json()
    
    if not new_rule:
        return jsonify({'error': 'Invalid rule data'}), 400
    
    # Validate required fields
    required_fields = ['rule_name', 'rule_type', 'rule_content', 'severity', 'category']
    for field in required_fields:
        if field not in new_rule:
            return jsonify({'error': f'Missing required field: {field}'}), 400
    
    # Generate ID
    new_rule['id'] = f"rule_{int(datetime.now().timestamp())}"
    new_rule['created_at'] = datetime.now().isoformat()
    new_rule['updated_at'] = datetime.now().isoformat()
    new_rule['created_by'] = 'user'
    new_rule['is_active'] = new_rule.get('is_active', True)
    
    data_cache['compliance_rules'].append(new_rule)
    save_compliance_rules(data_cache['compliance_rules'])
    
    return jsonify({'data': new_rule, 'message': 'Rule created successfully'})


@app.route('/api/compliance/rules/<rule_id>', methods=['PUT'])
def update_compliance_rule(rule_id: str):
    """Update compliance rule."""
    rule_data = request.get_json()
    
    if not rule_data:
        return jsonify({'error': 'Invalid rule data'}), 400
    
    rule = next((r for r in data_cache['compliance_rules'] if r.get('id') == rule_id), None)
    if not rule:
        return jsonify({'error': 'Rule not found'}), 404
    
    # Update allowed fields
    allowed_fields = ['rule_name', 'rule_description', 'rule_type', 'rule_content', 'is_active', 'severity', 'category']
    for field in allowed_fields:
        if field in rule_data:
            rule[field] = rule_data[field]
    
    rule['updated_at'] = datetime.now().isoformat()
    save_compliance_rules(data_cache['compliance_rules'])
    
    return jsonify({'data': rule, 'message': 'Rule updated successfully'})


@app.route('/api/compliance/rules/<rule_id>', methods=['DELETE'])
def delete_compliance_rule(rule_id: str):
    """Delete compliance rule."""
    rule = next((r for r in data_cache['compliance_rules'] if r.get('id') == rule_id), None)
    if not rule:
        return jsonify({'error': 'Rule not found'}), 404
    
    data_cache['compliance_rules'] = [r for r in data_cache['compliance_rules'] if r.get('id') != rule_id]
    save_compliance_rules(data_cache['compliance_rules'])
    
    return jsonify({'message': 'Rule deleted successfully'})


@app.route('/api/compliance/rules/<rule_id>/history', methods=['GET'])
def get_compliance_rule_history(rule_id: str):
    """Get compliance rule change history from logs."""
    logs = data_cache['compliance_logs']
    rule_logs = [log for log in logs if log.get('rule_id') == rule_id]
    rule_logs.sort(key=lambda x: x.get('checked_at', ''), reverse=True)
    return jsonify({'data': rule_logs})


# --- Media Edit API ---
@app.route('/api/media/video-edit', methods=['GET'])
def get_video_edit_list():
    """Get video edit list."""
    page = int(request.args.get('page', 1))
    size = int(request.args.get('size', 20))
    status_filter = request.args.get('status')
    
    media = [m for m in data_cache['media'] if m.get('type') == 'video']
    
    if status_filter:
        media = [m for m in media if m.get('status') == status_filter]
    
    total = len(media)
    start = (page - 1) * size
    end = start + size
    
    return jsonify({
        'data': media[start:end],
        'total': total,
        'page': page,
        'size': size
    })


@app.route('/api/media/image-edit', methods=['GET'])
def get_image_edit_list():
    """Get image edit list."""
    page = int(request.args.get('page', 1))
    size = int(request.args.get('size', 20))
    status_filter = request.args.get('status')
    
    media = [m for m in data_cache['media'] if m.get('type') == 'image']
    
    if status_filter:
        media = [m for m in media if m.get('status') == status_filter]
    
    total = len(media)
    start = (page - 1) * size
    end = start + size
    
    return jsonify({
        'data': media[start:end],
        'total': total,
        'page': page,
        'size': size
    })


@app.route('/api/media', methods=['POST'])
def create_media():
    """Create media edit entry."""
    data = request.get_json()
    if not data:
        return jsonify({'error': 'Invalid data'}), 400
    
    media = {
        'media_id': f"med_{int(datetime.now().timestamp())}",
        'type': data.get('type', 'video'),
        'title': data.get('title', ''),
        'status': data.get('status', 'editing'),
        'source_url': data.get('source_url', ''),
        'output_url': data.get('output_url', ''),
        'create_time': datetime.now().isoformat(),
        'update_time': datetime.now().isoformat()
    }
    
    data_cache['media'].insert(0, media)
    save_all_data()
    return jsonify({'data': media, 'message': 'Media entry created'})


@app.route('/api/media/<media_id>', methods=['PUT'])
def update_media(media_id: str):
    """Update media edit entry."""
    data = request.get_json()
    if not data:
        return jsonify({'error': 'Invalid data'}), 400
    
    media = next((m for m in data_cache['media'] if m.get('media_id') == media_id), None)
    if not media:
        return jsonify({'error': 'Media not found'}), 404
    
    media.update({
        'title': data.get('title', media['title']),
        'status': data.get('status', media['status']),
        'source_url': data.get('source_url', media['source_url']),
        'output_url': data.get('output_url', media['output_url']),
        'update_time': datetime.now().isoformat()
    })
    
    save_all_data()
    return jsonify({'data': media, 'message': 'Media updated'})


# --- Extended Alert Config API (Douyin/Dian specific) ---
@app.route('/api/alerts/douyin/config', methods=['GET'])
def get_alert_douyin_config():
    """Get Douyin-specific alert configuration."""
    return jsonify({'data': alert_douyin_config})


@app.route('/api/alerts/douyin/config', methods=['POST'])
def update_alert_douyin_config():
    """Update Douyin-specific alert configuration."""
    global alert_douyin_config
    new_config = request.get_json()
    
    if not new_config:
        return jsonify({'error': 'Invalid config'}), 400
    
    allowed_fields = [
        'video_view_drop_threshold',
        'video_like_drop_threshold',
        'creator_follower_drop_threshold',
        'notification_email',
        'enabled'
    ]
    
    for key, value in new_config.items():
        if key in allowed_fields:
            alert_douyin_config[key] = value
    
    save_json_file(ALERT_DOUYIN_CONFIG_FILE, alert_douyin_config)
    return jsonify({'data': alert_douyin_config, 'message': 'Douyin alert config updated'})


@app.route('/api/alerts/dian/config', methods=['GET'])
def get_alert_dian_config():
    """Get Dian-specific alert configuration."""
    return jsonify({'data': alert_dian_config})


@app.route('/api/alerts/dian/config', methods=['POST'])
def update_alert_dian_config():
    """Update Dian-specific alert configuration."""
    global alert_dian_config
    new_config = request.get_json()
    
    if not new_config:
        return jsonify({'error': 'Invalid config'}), 400
    
    allowed_fields = [
        'product_sales_drop_threshold',
        'order_refund_rate_threshold',
        'compliance_risk_threshold',
        'notification_email',
        'enabled'
    ]
    
    for key, value in new_config.items():
        if key in allowed_fields:
            alert_dian_config[key] = value
    
    save_json_file(ALERT_DIAN_CONFIG_FILE, alert_dian_config)
    return jsonify({'data': alert_dian_config, 'message': 'Dian alert config updated'})


# Serve React frontend
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_frontend(path):
    """Serve React frontend for all non-API routes."""
    from pathlib import Path
    
    if path.startswith('api/'):
        return jsonify({'error': 'Not found'}), 404

    if path:
        static_path = Path(app.static_folder) / path
        if static_path.exists() and static_path.is_file():
            return send_from_directory(app.static_folder, path)

    # index.html is in frontend/build (parent of static_folder)
    index_dir = Path(app.static_folder).parent
    return send_from_directory(index_dir, 'index.html')


def create_app() -> Flask:
    """Application factory."""
    load_all_data()
    scheduler.start()
    logger.info("Application started")
    return app


if __name__ == '__main__':
    app = create_app()
    app.run(host='0.0.0.0', port=5000, debug=False)