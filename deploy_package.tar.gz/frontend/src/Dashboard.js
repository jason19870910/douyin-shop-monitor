import React, { useEffect, useState } from 'react';
import './Dashboard.css';

function Dashboard() {
  const [shopStats, setShopStats] = useState(null);
  const [orders, setOrders] = useState(null);
  const [creator, setCreator] = useState(null);

  const fetchData = async (endpoint, setter) => {
    try {
      const res = await fetch(endpoint);
      const json = await res.json();
      if (json.success) {
        setter(json.data);
      } else {
        console.error('API error', json);
      }
    } catch (e) {
      console.error('Fetch error', e);
    }
  };

  useEffect(() => {
    fetchData('/api/shop-stats', setShopStats);
    fetchData('/api/orders', setOrders);
    fetchData('/api/creator', setCreator);
  }, []);

  const handleRefresh = () => {
    fetchData('/api/refresh', () => {});
    // re-fetch all data after manual refresh
    fetchData('/api/shop-stats', setShopStats);
    fetchData('/api/orders', setOrders);
    fetchData('/api/creator', setCreator);
  };

  return (
    <div className="dashboard">
      <h1>DouDian 监控面板</h1>
      <button onClick={handleRefresh}>刷新数据</button>
      <section>
        <h2>商品统计</h2>
        {shopStats ? (
          <ul>
            {Object.entries(shopStats).map(([key, value]) => (
              <li key={key}>{key}: {value}</li>
            ))}
          </ul>
        ) : '加载中...'}
      </section>
      <section>
        <h2>订单看板</h2>
        {orders ? (
          <pre>{JSON.stringify(orders, null, 2)}</pre>
        ) : '加载中...'}
      </section>
      <section>
        <h2>创作者数据</h2>
        {creator ? (
          <ul>
            {Object.entries(creator).map(([key, value]) => (
              <li key={key}>{key}: {value}</li>
            ))}
          </ul>
        ) : '加载中...'}
      </section>
    </div>
  );
}

export default Dashboard;
